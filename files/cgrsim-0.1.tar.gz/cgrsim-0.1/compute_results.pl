#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use Cwd qw[abs_path];
use List::Util qw[min max];

use lib dirname($0);
use gene_models;
use configdata;

my @usage;
push @usage, "Usage: ".basename($0)." [options]\n";
push @usage, "Analyze nfuse results for complex fusions.\n";
push @usage, "  -h, --help      Displays this information\n";
push @usage, "  -c, --config    Configuration Filename\n";
push @usage, "  -o, --output    nFuse Output Directory\n";

my $help;
my $config_filename;
my $output_directory;

GetOptions
(
	'help'        => \$help,
	'config=s'    => \$config_filename,
	'output=s'    => \$output_directory,
);

not defined $help or die @usage;
defined $config_filename or die @usage;
defined $output_directory or die @usage;

my $config = configdata->new();
$config->read($config_filename);

# Config values
my $path_sequences_fasta = $config->get_value("path_sequences_fasta");
my $path_breakpoints_filename = $config->get_value("path_breakpoints_filename");
my $path_fusion_sequence_fasta = $config->get_value("path_fusion_sequence_fasta");
my $ccbr_sequences_fasta = $config->get_value("ccbr_sequences_fasta");
my $ccbr_breakpoints_filename = $config->get_value("ccbr_breakpoints_filename");
my $ccbr_fusion_sequence_fasta = $config->get_value("ccbr_fusion_sequence_fasta");
my $breakpoint_match_distance = $config->get_value("breakpoint_match_distance");

my $path_results = $output_directory."/dna.path.results.tsv";
my $ccbr_results = $output_directory."/dna.cycle.results.tsv";

my %results_breakpoints;
read_results_breakpoints($path_results, \%results_breakpoints);
read_results_breakpoints($ccbr_results, \%results_breakpoints);

my %sim_breakpoints;
read_sim_breakpoints("path", $path_breakpoints_filename, \%sim_breakpoints);
read_sim_breakpoints("ccbr", $ccbr_breakpoints_filename, \%sim_breakpoints);

my %results_to_sim;
foreach my $result_id (keys %results_breakpoints)
{
	foreach my $sim_id (keys %sim_breakpoints)
	{
		my $match = 0;
		$match = 1 if close_enough($results_breakpoints{$result_id}->[0], $sim_breakpoints{$sim_id}->[0]) and close_enough($results_breakpoints{$result_id}->[1], $sim_breakpoints{$sim_id}->[1]);
		$match = 1 if close_enough($results_breakpoints{$result_id}->[0], $sim_breakpoints{$sim_id}->[1]) and close_enough($results_breakpoints{$result_id}->[1], $sim_breakpoints{$sim_id}->[0]);
		
		if ($match)
		{
			die if defined $results_to_sim{$result_id};
			$results_to_sim{$result_id} = $sim_id;
		}
	}
}

my %results_paths;
my %sim_paths;
read_results_cgrs("path", $path_results, \%results_paths);
read_sim_cgrs("path", $path_breakpoints_filename, \%sim_paths);

my %results_ccbrs;
my %sim_ccbrs;
read_results_cgrs("cycle", $ccbr_results, \%results_ccbrs);
read_sim_cgrs("ccbr", $ccbr_breakpoints_filename, \%sim_ccbrs);

compare_path_results(\%results_to_sim, \%results_paths, \%sim_paths);
compare_ccbr_results(\%results_to_sim, \%results_ccbrs, \%sim_ccbrs);

sub compare_path_results
{
	my $results_to_sim_ref = shift;
	my $results_ref = shift;
	my $sim_ref = shift;
	
	foreach my $result_id (keys %{$results_ref})
	{
		my @remap_breakpoints;
		foreach my $result_breakpoint (@{$results_ref->{$result_id}})
		{
			if (defined $results_to_sim_ref->{$result_breakpoint})
			{
				push @remap_breakpoints, $results_to_sim_ref->{$result_breakpoint};
			}
			else
			{
				@remap_breakpoints = ();
				last;
			}
		}

		next if scalar @remap_breakpoints == 0;

		my $result_key_forward = join ",", @remap_breakpoints;
		my $result_key_reverse = join ",", reverse @remap_breakpoints;
		
		foreach my $sim_id (keys %{$sim_ref})
		{
			my @sim_breakpoints = @{$sim_ref->{$sim_id}};
			my $sim_key = join ",", @sim_breakpoints;
			
			if ($result_key_forward eq $sim_key or $result_key_reverse eq $sim_key)
			{
				print "path\t$result_id\t$sim_id\n";
			}
		}
	}
}

sub compare_ccbr_results
{
	my $results_to_sim_ref = shift;
	my $results_ref = shift;
	my $sim_ref = shift;
	
	foreach my $result_id (keys %{$results_ref})
	{
		my @remap_breakpoints;
		foreach my $result_breakpoint (@{$results_ref->{$result_id}})
		{
			if (defined $results_to_sim_ref->{$result_breakpoint})
			{
				push @remap_breakpoints, $results_to_sim_ref->{$result_breakpoint};
			}
			else
			{
				@remap_breakpoints = ();
				last;
			}
		}

		next if scalar @remap_breakpoints == 0;

		my $result_key_forward = join ",", @remap_breakpoints;
		
		my $first_result_id = shift @remap_breakpoints;
		my $result_key_reverse = join ",", ($first_result_id, reverse(@remap_breakpoints));
		
		foreach my $sim_id (keys %{$sim_ref})
		{
			my @sim_breakpoints = @{$sim_ref->{$sim_id}};
			my $sim_key = join ",", @sim_breakpoints;
			
			if ($result_key_forward eq $sim_key or $result_key_reverse eq $sim_key)
			{
				print "ccbr\t$result_id\t$sim_id\n";
			}
		}
	}
}

sub read_sim_cgrs
{
	my $cgr_type = shift;
	my $sim_filename = shift;
	my $cgrs_ref = shift;
	
	open SIM, $sim_filename or die "Error: simulation file $sim_filename not found\n";
	while (<SIM>)
	{
		chomp;
		my @fields = split /\t/;
		
		my $cgr_id = $fields[0];
		my $breakpoint_id = $cgr_type."-".$fields[1];
		my $side = $fields[2];

		next if $side == 1;
		
		push @{$cgrs_ref->{$cgr_id}}, $breakpoint_id;
	}
	close SIM;
}

sub read_results_cgrs
{
	my $cgr_type = shift;
	my $results_filename = shift;
	my $cgrs_ref = shift;
	
	my $found_header = 0;
	my %ind;
	open RES, $results_filename or die "Error: results file $results_filename not found\n";
	while (<RES>)
	{
		chomp;
		my @fields = split /\t/;
	
		if (not $found_header)
		{
			foreach my $field_index (0..$#fields)
			{
				$ind{$fields[$field_index]} = $field_index;
			}
	
			$found_header = 1;
	
			next;
		}
	
		if ($found_header and $fields[0] eq "cluster_id")
		{
			next;
		}
	
		my $cgr_id = $fields[$ind{$cgr_type."_id"}];
		my $cluster_id = $fields[$ind{cluster_id}];
		
		push @{$cgrs_ref->{$cgr_id}}, $cluster_id;
	}
	close RES;
}

sub read_sim_breakpoints
{
	my $cgr_type = shift;
	my $sim_filename = shift;
	my $breakpoints_ref = shift;
	
	open SIM, $sim_filename or die "Error: simulation file $sim_filename not found\n";
	while (<SIM>)
	{
		chomp;
		my @fields = split /\t/;
		
		my $breakpoint_id = $cgr_type."-".$fields[1];
		my $side = $fields[2];
		my $chr = $fields[3];
		my $str = $fields[4];
		my $pos = $fields[5];
		
		$breakpoints_ref->{$breakpoint_id} = [[], []] if not defined $breakpoints_ref->{$breakpoint_id};
		$breakpoints_ref->{$breakpoint_id}[$side] = [$chr, $str, $pos];
	}
	close SIM;
}

sub read_results_breakpoints
{
	my $results_filename = shift;
	my $breakpoints_ref = shift;
	
	my $found_header = 0;
	my %ind;
	open RES, $results_filename or die "Error: results file $results_filename not found\n";
	while (<RES>)
	{
		chomp;
		my @fields = split /\t/;
	
		if (not $found_header)
		{
			foreach my $field_index (0..$#fields)
			{
				$ind{$fields[$field_index]} = $field_index;
			}
	
			$found_header = 1;
	
			next;
		}
	
		if ($found_header and $fields[0] eq "cluster_id")
		{
			next;
		}
	
		my $cluster_id = $fields[$ind{cluster_id}];
		my $chr1 = $fields[$ind{gene_chromosome1}];
		my $chr2 = $fields[$ind{gene_chromosome2}];
		my $str1 = $fields[$ind{genomic_strand1}];
		my $str2 = $fields[$ind{genomic_strand2}];
		my $pos1 = $fields[$ind{genomic_break_pos1}];
		my $pos2 = $fields[$ind{genomic_break_pos2}];
		
		$breakpoints_ref->{$cluster_id} = [[$chr1, $str1, $pos1], [$chr2, $str2, $pos2]];
	}
	close RES;
}

sub close_enough
{
	my $breakpoint1 = shift;
	my $breakpoint2 = shift;

	if ($breakpoint1->[0] ne $breakpoint2->[0] or $breakpoint1->[1] ne $breakpoint2->[1])
	{
		return 0;
	}

	if (abs($breakpoint1->[2] - $breakpoint2->[2]) > $breakpoint_match_distance)
	{
		return 0;
	}

	return 1;
}

