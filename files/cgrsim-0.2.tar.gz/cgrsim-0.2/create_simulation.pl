#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use Cwd qw[abs_path];
use List::Util qw[min max];

use lib dirname($0);
use gene_models;
use configdata;

my @usage;
push @usage, "Usage: ".basename($0)." [options]\n";
push @usage, "Create complex fusions.\n";
push @usage, "  -h, --help      Displays this information\n";
push @usage, "  -c, --config    Configuration Filename\n";

my $help;
my $config_filename;

GetOptions
(
	'help'        => \$help,
	'config=s'    => \$config_filename,
);

not defined $help or die @usage;
defined $config_filename or die @usage;

my $config = configdata->new();
$config->read($config_filename);

# General
my $simulation_dir = $config->get_value("simulation_dir");
my $gene_models_filename = $config->get_value("gene_models");
my $genome_fasta = $config->get_value("genome_fasta");
my $cdna_fasta = $config->get_value("cdna_fasta");
my $min_transcript_length = $config->get_value("min_transcript_length");
my $min_transcript_partner_length = $config->get_value("min_transcript_partner_length");
my $min_distance_telomere = $config->get_value("min_distance_telomere");
my $breakpoint_adjacent_length = $config->get_value("breakpoint_adjacent_length");
my %chromosomes = $config->get_hash("chromosomes");
my $dwgsim_seed = $config->get_value("dwgsim_seed");
my $path_seed = $config->get_value("path_seed");
my $ccbr_seed = $config->get_value("ccbr_seed");

# DNA sequencing simulation
my $dna_seq_dir = $config->get_value("dna_seq_dir");
my $min_breakpoint_coverage = $config->get_value("min_breakpoint_coverage");
my $max_breakpoint_coverage = $config->get_value("max_breakpoint_coverage");
my $wgss_fragment_mean = $config->get_value("wgss_fragment_mean");
my $wgss_fragment_stddev = $config->get_value("wgss_fragment_stddev");
my $wgss_read_length = $config->get_value("wgss_read_length");
my $wgss_coverage = $config->get_value("wgss_coverage");

# RNA sequence simulation
my $rna_seq_dir = $config->get_value("rna_seq_dir");
my $min_fusion_coverage = $config->get_value("min_fusion_coverage");
my $max_fusion_coverage = $config->get_value("max_fusion_coverage");
my $rnaseq_fragment_mean = $config->get_value("rnaseq_fragment_mean");
my $rnaseq_fragment_stddev = $config->get_value("rnaseq_fragment_stddev");
my $rnaseq_read_length = $config->get_value("rnaseq_read_length");
my $rnaseq_expressed_probability = $config->get_value("rnaseq_expressed_probability");
my $rnaseq_min_coverage = $config->get_value("rnaseq_min_coverage");
my $rnaseq_max_coverage = $config->get_value("rnaseq_max_coverage");

# Path simulation
my %path_sim_info;
$path_sim_info{easy}{count} = $config->get_value("easy_fusion_count");
$path_sim_info{easy}{min_shards} = $config->get_value("easy_fusion_min_shards");
$path_sim_info{easy}{max_shards} = $config->get_value("easy_fusion_max_shards");
$path_sim_info{easy}{min_shard_length} = $config->get_value("easy_fusion_min_shard_length");
$path_sim_info{easy}{max_shard_length} = $config->get_value("easy_fusion_max_shard_length");

$path_sim_info{medium}{count} = $config->get_value("medium_fusion_count");
$path_sim_info{medium}{min_shards} = $config->get_value("medium_fusion_min_shards");
$path_sim_info{medium}{max_shards} = $config->get_value("medium_fusion_max_shards");
$path_sim_info{medium}{min_shard_length} = $config->get_value("medium_fusion_min_shard_length");
$path_sim_info{medium}{max_shard_length} = $config->get_value("medium_fusion_max_shard_length");

$path_sim_info{hard}{count} = $config->get_value("hard_fusion_count");
$path_sim_info{hard}{min_shards} = $config->get_value("hard_fusion_min_shards");
$path_sim_info{hard}{max_shards} = $config->get_value("hard_fusion_max_shards");
$path_sim_info{hard}{min_shard_length} = $config->get_value("hard_fusion_min_shard_length");
$path_sim_info{hard}{max_shard_length} = $config->get_value("hard_fusion_max_shard_length");

# CCBR simulation
my %ccbr_sim_info;
$ccbr_sim_info{easy}{count} = $config->get_value("easy_ccbr_count");
$ccbr_sim_info{easy}{min_breakpoints} = $config->get_value("easy_ccbr_min_breakpoints");
$ccbr_sim_info{easy}{max_breakpoints} = $config->get_value("easy_ccbr_max_breakpoints");
$ccbr_sim_info{easy}{max_lossgain_length} = $config->get_value("easy_ccbr_max_lossgain_length");

$ccbr_sim_info{medium}{count} = $config->get_value("medium_ccbr_count");
$ccbr_sim_info{medium}{min_breakpoints} = $config->get_value("medium_ccbr_min_breakpoints");
$ccbr_sim_info{medium}{max_breakpoints} = $config->get_value("medium_ccbr_max_breakpoints");
$ccbr_sim_info{medium}{max_lossgain_length} = $config->get_value("medium_ccbr_max_lossgain_length");

$ccbr_sim_info{hard}{count} = $config->get_value("hard_ccbr_count");
$ccbr_sim_info{hard}{min_breakpoints} = $config->get_value("hard_ccbr_min_breakpoints");
$ccbr_sim_info{hard}{max_breakpoints} = $config->get_value("hard_ccbr_max_breakpoints");
$ccbr_sim_info{hard}{max_lossgain_length} = $config->get_value("hard_ccbr_max_lossgain_length");

my @chromosome_list = keys %chromosomes;

my $gene_models = gene_models->new($gene_models_filename);

my %genome = read_fasta($genome_fasta);

my %transcripts = read_fasta($cdna_fasta);

my @gene_ids = keys %{$gene_models->{genes}};

mkdir $simulation_dir if not -d $simulation_dir;

###
# Simulate paths
###

print "Simulating path fusions\n";

srand($path_seed);

my $path_fusion_id = 0;
my $path_breakpoint_id = 0;

my $path_sequences_fasta = $config->get_value("path_sequences_fasta");
my $path_breakpoints_filename = $config->get_value("path_breakpoints_filename");
my $path_fusion_sequence_fasta = $config->get_value("path_fusion_sequence_fasta");

open PSQ, ">".$path_sequences_fasta or die "Error: Unable to write to $path_sequences_fasta: $!\n";
open PBK, ">".$path_breakpoints_filename or die "Error: Unable to write to $path_breakpoints_filename: $!\n";
open PFS, ">".$path_fusion_sequence_fasta or die "Error: Unable to write to $path_fusion_sequence_fasta: $!\n";

# Simulate easy fusions
simulate_path_fusion_set($path_sim_info{easy});
simulate_path_fusion_set($path_sim_info{medium});
simulate_path_fusion_set($path_sim_info{hard});

close PSQ;
close PBK;
close PFS;


###
# Simulate CCBRs
###

print "Simulating ccbr fusions\n";

srand($ccbr_seed);

my $ccbr_fusion_id = 0;
my $ccbr_breakpoint_id = 0;

my $ccbr_sequences_fasta = $config->get_value("ccbr_sequences_fasta");
my $ccbr_breakpoints_filename = $config->get_value("ccbr_breakpoints_filename");
my $ccbr_fusion_sequence_fasta = $config->get_value("ccbr_fusion_sequence_fasta");

open CSQ, ">".$ccbr_sequences_fasta or die "Error: Unable to write to $ccbr_sequences_fasta: $!\n";
open CBK, ">".$ccbr_breakpoints_filename or die "Error: Unable to write to $ccbr_breakpoints_filename: $!\n";
open CFS, ">".$ccbr_fusion_sequence_fasta or die "Error: Unable to write to $ccbr_fusion_sequence_fasta: $!\n";

# Simulate easy fusions
simulate_ccbr_fusion_set($ccbr_sim_info{easy});
simulate_ccbr_fusion_set($ccbr_sim_info{medium});
simulate_ccbr_fusion_set($ccbr_sim_info{hard});

close CSQ;
close CBK;
close CFS;


### 
# Simulate Sequencing
###

system "mkdir -p $dna_seq_dir" if not -d $dna_seq_dir;
system "mkdir -p $rna_seq_dir" if not -d $rna_seq_dir;

random_coverage_simulate("path", $path_sequences_fasta, $dna_seq_dir, $wgss_fragment_mean, $wgss_fragment_stddev, $wgss_read_length, 1.0, $min_breakpoint_coverage, $max_breakpoint_coverage, 0, 0);
random_coverage_simulate("ccbr", $ccbr_sequences_fasta, $dna_seq_dir, $wgss_fragment_mean, $wgss_fragment_stddev, $wgss_read_length, 1.0, $min_breakpoint_coverage, $max_breakpoint_coverage, 0, 0);

random_coverage_simulate("path", $path_fusion_sequence_fasta, $rna_seq_dir, $rnaseq_fragment_mean, $rnaseq_fragment_stddev, $rnaseq_read_length, 1.0, $min_fusion_coverage, $max_fusion_coverage, 0, 0);
random_coverage_simulate("ccbr", $ccbr_fusion_sequence_fasta, $rna_seq_dir, $rnaseq_fragment_mean, $rnaseq_fragment_stddev, $rnaseq_read_length, 1.0, $min_fusion_coverage, $max_fusion_coverage, 0, 0);

random_coverage_simulate("aaaa", $cdna_fasta, $rna_seq_dir, $rnaseq_fragment_mean, $rnaseq_fragment_stddev, $rnaseq_read_length, $rnaseq_expressed_probability, $rnaseq_min_coverage, $rnaseq_max_coverage, 1, 1);

fixed_coverage_simulate("aaaa", $genome_fasta, $dna_seq_dir, $wgss_fragment_mean, $wgss_fragment_stddev, $wgss_read_length, $wgss_coverage, 1, 1);


sub simulate_path_fusion_set
{
	my $info_ref = shift;
	
	my $count = 0;
	while ($count < $info_ref->{count})
	{
		my $num_shards = rand_range($info_ref->{min_shards}, $info_ref->{max_shards});
		
		my %fusion_info = simulate_path_fusion($num_shards, $info_ref->{min_shard_length}, $info_ref->{max_shard_length});
		
		print PSQ ">".$path_fusion_id."\n".$fusion_info{path_sequence}."\n";
		
		print PFS ">".$path_fusion_id."\n".$fusion_info{fusion_sequence}."\n";
		
		foreach my $breakpoint (@{$fusion_info{path_breakpoints}})
		{
			foreach my $breakpoint_end (0..1)
			{
				print PBK $path_fusion_id."\t".$path_breakpoint_id."\t".$breakpoint_end."\t".$breakpoint->[$breakpoint_end][0]."\t".$breakpoint->[$breakpoint_end][1]."\t".$breakpoint->[$breakpoint_end][2]."\n";
			}
			
			$path_breakpoint_id++;
		}
		
		$path_fusion_id++;
		
		$count++;
		
		print ".";
	}
	
	print "\n";
}

sub simulate_path_fusion
{
	my $num_shards = shift;
	my $min_shard_length = shift;
	my $max_shard_length = shift;
	
	while (1)
	{
		# Store fusion info in a hash
		my %info;
		
		# Select 2 random genes
		my $gene_index_1 = rand_range(0,$#gene_ids);
		my $gene_id_1 = $gene_ids[$gene_index_1];
		
		my $gene_index_2 = rand_range(0,$#gene_ids);
		my $gene_id_2 = $gene_ids[$gene_index_2];
		
		# Select a random position in a random intron
		my ($transcript_id_1, $genomic_position_1, $fiveprime_1, $threeprime_1) = select_intron_breakpoint($gene_id_1);
		my ($transcript_id_2, $genomic_position_2, $fiveprime_2, $threeprime_2) = select_intron_breakpoint($gene_id_2);
		
		# Ensure the preceding call succeeded 
		next if not defined $transcript_id_1;
		next if not defined $transcript_id_2;
		
		# Find chromosomes of the genes
		my $chromosome_1 = $gene_models->calc_genomic_chromosome($transcript_id_1);
		my $chromosome_2 = $gene_models->calc_genomic_chromosome($transcript_id_2);
		
		# Ensure the genes are on acceptable chromosomes
		next unless defined $chromosomes{$chromosome_1};
		next unless defined $chromosomes{$chromosome_2};
		
		# Retrieve transcript sequences
		my $transcript_sequence_1 = get_transcript_sequence($transcript_id_1);
		my $transcript_sequence_2 = get_transcript_sequence($transcript_id_2);
		next if not defined $transcript_sequence_1;
		next if not defined $transcript_sequence_2;
		
		# Canonical splicing
		my $transcript_position_1 = $fiveprime_1;
		my $transcript_position_2 = $threeprime_2;
		
		# Create partner transcripts
		my $transcript_subseq_1 = substr $transcript_sequence_1, 0, $transcript_position_1;
		my $transcript_subseq_2 = substr $transcript_sequence_2, $transcript_position_2 - 1;
		
		# Constrain length each partner contributes
		next if length($transcript_subseq_1) < $min_transcript_partner_length;
		next if length($transcript_subseq_2) < $min_transcript_partner_length;
		
		# Full fusion transcript sequence
		my $transcript_sequence = $transcript_subseq_1.$transcript_subseq_2;
		
		# Constrain length of full fusion transcript
		next unless length($transcript_sequence) >= $min_transcript_length;
		
		# Find strand of breakpoint
		my $genomic_strand_1 = $gene_models->calc_genomic_strand($transcript_id_1, "+");
		my $genomic_strand_2 = $gene_models->calc_genomic_strand($transcript_id_2, "-");
		
		# Find genomic sequence on either side of breakpoint
		my $genomic_sequence_1 = create_breakpoint_sequence($chromosome_1, $genomic_strand_1, $genomic_position_1);
		my $genomic_sequence_2 = create_breakpoint_sequence($chromosome_2, $genomic_strand_2, $genomic_position_2);
		
		# Create genomic shards
		my @shards;
		while (scalar @shards < $num_shards)
		{
			my $shard_chromosome = $chromosome_list[rand_range(0,$#chromosome_list)];
			my $shard_strand = ("+","-")[rand_range(0,1)];
			my $shard_length = rand_range($min_shard_length, $max_shard_length);
			my $shard_start = rand_range($min_distance_telomere, length($genome{$shard_chromosome}) - $shard_length - $min_distance_telomere);
			my $shard_end = $shard_start + $shard_length - 1;
			
			my $shard_sequence = get_genome_sequence($shard_chromosome, $shard_start, $shard_end);
			$shard_sequence = revcomp($shard_sequence) if $shard_strand eq "-";
			
			push @shards, [$shard_chromosome, $shard_strand, $shard_start, $shard_end, $shard_sequence];
		}
		
		# Create genomic sequence and list of breakpoints
		my $genomic_sequence = $genomic_sequence_1;
		my @genomic_breakpoints = ([[$chromosome_1, $genomic_strand_1, $genomic_position_1], undef]);
		foreach my $shard (@shards)
		{
			$genomic_sequence .= $shard->[4];
			
			if ($shard->[1] eq "+")
			{
				$genomic_breakpoints[$#genomic_breakpoints][1] = [$shard->[0], "-", $shard->[2]];
				push @genomic_breakpoints, [[$shard->[0], "+", $shard->[3]], undef]
			}
			else
			{
				$genomic_breakpoints[$#genomic_breakpoints][1] = [$shard->[0], "+", $shard->[3]];
				push @genomic_breakpoints, [[$shard->[0], "-", $shard->[2]], undef]
			}
		}
		$genomic_sequence .= revcomp($genomic_sequence_2);
		$genomic_breakpoints[$#genomic_breakpoints][1] = [$chromosome_2, $genomic_strand_2, $genomic_position_2];
		
		# Reject if there are more than 10 Ns
		next if $genomic_sequence =~ /NNNNNNNNNN/;
		
		$info{path_breakpoints} = [@genomic_breakpoints];
		$info{path_sequence} = $genomic_sequence;
		$info{fusion_sequence} = $transcript_sequence;
		
		return %info;
	}
}

sub simulate_ccbr_fusion_set
{
	my $info_ref = shift;
	
	my $count = 0;
	while ($count < $info_ref->{count})
	{
		my $num_breakpoints = rand_range($info_ref->{min_breakpoints}, $info_ref->{max_breakpoints});
		
		my %fusion_info = simulate_ccbr_fusion($num_breakpoints, $info_ref->{max_lossgain_length});
		
		print CFS ">".$ccbr_fusion_id."\n".$fusion_info{fusion_sequence}."\n";
		
		foreach my $breakpoint_index (0..$#{$fusion_info{cycle_breakpoints}})
		{
			my $breakpoint = $fusion_info{cycle_breakpoints}->[$breakpoint_index];
			my $breakpoint_sequence = $fusion_info{cycle_sequences}->[$breakpoint_index];
			
			print CSQ ">".$ccbr_breakpoint_id."\n".$breakpoint_sequence."\n";
			
			foreach my $breakpoint_end (0..1)
			{
				print CBK $ccbr_fusion_id."\t".$ccbr_breakpoint_id."\t".$breakpoint_end."\t".$breakpoint->[$breakpoint_end][0]."\t".$breakpoint->[$breakpoint_end][1]."\t".$breakpoint->[$breakpoint_end][2]."\n";
			}
			
			$ccbr_breakpoint_id++;
		}
		
		$ccbr_fusion_id++;
		
		$count++;
		
		print ".";
	}
	
	print "\n";
}

sub simulate_ccbr_fusion
{
	my $num_breakpoints = shift;
	my $max_lossgain_length = shift;
	
	while (1)
	{
		# Store fusion info in a hash
		my %info;
		
		# Select 2 random genes
		my $gene_index_1 = rand_range(0,$#gene_ids);
		my $gene_id_1 = $gene_ids[$gene_index_1];
		
		my $gene_index_2 = rand_range(0,$#gene_ids);
		my $gene_id_2 = $gene_ids[$gene_index_2];
		
		# Select a random position in a random intron
		my ($transcript_id_1, $genomic_position_1, $fiveprime_1, $threeprime_1) = select_intron_breakpoint($gene_id_1);
		my ($transcript_id_2, $genomic_position_2, $fiveprime_2, $threeprime_2) = select_intron_breakpoint($gene_id_2);
		
		# Ensure the preceding call succeeded 
		next if not defined $transcript_id_1;
		next if not defined $transcript_id_2;
		
		# Find chromosomes of the genes
		my $chromosome_1 = $gene_models->calc_genomic_chromosome($transcript_id_1);
		my $chromosome_2 = $gene_models->calc_genomic_chromosome($transcript_id_2);
		
		# Ensure the genes are on acceptable chromosomes
		next unless defined $chromosomes{$chromosome_1};
		next unless defined $chromosomes{$chromosome_2};
		
		# Retrieve transcript sequences
		my $transcript_sequence_1 = get_transcript_sequence($transcript_id_1);
		my $transcript_sequence_2 = get_transcript_sequence($transcript_id_2);
		next if not defined $transcript_sequence_1;
		next if not defined $transcript_sequence_2;
		
		# Canonical splicing
		my $transcript_position_1 = $fiveprime_1;
		my $transcript_position_2 = $threeprime_2;
		
		# Create partner transcripts
		my $transcript_subseq_1 = substr $transcript_sequence_1, 0, $transcript_position_1;
		my $transcript_subseq_2 = substr $transcript_sequence_2, $transcript_position_2 - 1;
		
		# Constrain length each partner contributes
		next if length($transcript_subseq_1) < $min_transcript_partner_length;
		next if length($transcript_subseq_2) < $min_transcript_partner_length;
		
		# Full fusion transcript sequence
		my $transcript_sequence = $transcript_subseq_1.$transcript_subseq_2;
		
		# Constrain length of full fusion transcript
		next unless length($transcript_sequence) >= $min_transcript_length;
		
		# Find strand of breakpoint
		my $genomic_strand_1 = $gene_models->calc_genomic_strand($transcript_id_1, "+");
		my $genomic_strand_2 = $gene_models->calc_genomic_strand($transcript_id_2, "-");
		
		# Create list of breakpoints
		my @breakpoints = ([[$chromosome_1, $genomic_strand_1, $genomic_position_1], [$chromosome_2, $genomic_strand_2, $genomic_position_2]]);
		while (scalar @breakpoints < $num_breakpoints)
		{
			push @breakpoints, [[random_adjacent($max_lossgain_length,$breakpoints[$#breakpoints][1])],[undef,undef,undef]];
			
			if (scalar @breakpoints == $num_breakpoints)
			{
				$breakpoints[$#breakpoints][1] = [random_adjacent($max_lossgain_length,$breakpoints[0][0])];
			}
			else
			{
				my $next_chromosome = $chromosome_list[rand_range(0,$#chromosome_list)];
				my $next_strand = ("+","-")[rand_range(0,1)];
				my $next_position = rand_range($min_distance_telomere, length($genome{$next_chromosome}) - $min_distance_telomere);
				
				$breakpoints[$#breakpoints][1] = [$next_chromosome, $next_strand, $next_position];
			}
		}
		
		# Create list of breakpoint sequences
		# Check for Ns
		my @breakpoint_sequences;
		my $found_ns = 0;
		foreach my $breakpoint (@breakpoints)
		{
			my $breakpoint_sequence_1 = create_breakpoint_sequence(@{$breakpoint->[0]});
			my $breakpoint_sequence_2 = create_breakpoint_sequence(@{$breakpoint->[1]});
			
			my $breakpoint_sequence = $breakpoint_sequence_1.revcomp($breakpoint_sequence_2);
			
			if ($breakpoint_sequence =~ /NNNNNNNNNN/)
			{
				$found_ns = 1;
				last;
			}
			
			push @breakpoint_sequences, $breakpoint_sequence;
		}
		
		next if $found_ns;
		
		$info{cycle_breakpoints} = [@breakpoints];
		$info{cycle_sequences} = [@breakpoint_sequences];
		$info{fusion_sequence} = $transcript_sequence;
		
		return %info;
	}
}

sub random_adjacent
{
	my $max_lossgain_length = shift;
	my $break_ref = shift;
	
	my $direction = rand_range(0,1) * 2 - 1;
	my $position = $break_ref->[2] + $direction * rand_range(0,$max_lossgain_length);
	my $strand = ($break_ref->[1] eq "+") ? "-" : "+";
	
	return ($break_ref->[0], $strand, $position);
}

sub random_coverage_simulate
{
	my $name = shift;
	my $fasta = shift;
	my $seq_dir = shift;
	my $fragment_mean = shift;
	my $fragment_stddev = shift;
	my $read_length = shift;
	my $expressed_probability = shift;
	my $min_coverage = shift;
	my $max_coverage = shift;
	my $diploid = shift;
	my $randomreads = shift;
	
	my %sequences = read_fasta($fasta);
	
	foreach my $id (sort keys(%sequences))
	{
		if (length($sequences{$id}) < $fragment_mean + 3 * $fragment_stddev)
		{
			next;
		}
		
		if ($expressed_probability < 1.0 and $expressed_probability < rand(1.0))
		{
			next;
		}
		
		my %single_sequence;
		$single_sequence{$id} = $sequences{$id};
		
		my $temp_seq_fasta = $simulation_dir."/tmp.seq.fa";
		write_fasta($temp_seq_fasta, \%single_sequence);
		
		my $coverage = rand_range($min_coverage, $max_coverage);
		my $read_count = int($coverage * length($sequences{$id}) / $fragment_mean);
		
		$id =~ s/\|/_/g;
		
		my $reads_prefix = $seq_dir."/".$name.".".$id;
		
		my $haploid_flag = ($diploid) ? "" : "-H";
		my $randomreads_option = ($randomreads) ? "" : "-y 0";
		
		$dwgsim_seed++;
		print "dwgsim -z $dwgsim_seed -d $fragment_mean -s $fragment_stddev -N $read_count -1 $read_length -2 $read_length $haploid_flag $randomreads_option $temp_seq_fasta $reads_prefix\n";
		die unless 0 == system "dwgsim -z $dwgsim_seed -d $fragment_mean -s $fragment_stddev -N $read_count -1 $read_length -2 $read_length $haploid_flag $randomreads_option $temp_seq_fasta $reads_prefix";
	}
}

sub fixed_coverage_simulate
{
	my $name = shift;
	my $fasta = shift;
	my $seq_dir = shift;
	my $fragment_mean = shift;
	my $fragment_stddev = shift;
	my $read_length = shift;
	my $coverage = shift;
	my $diploid = shift;
	my $randomreads = shift;
	
	my $reads_prefix = $seq_dir."/".$name;
	
	my $sequences_size = seq_size($fasta);
	
	my $read_count = int($coverage * $sequences_size / $fragment_mean);
	
	my $haploid_flag = ($diploid) ? "" : "-H";
	my $randomreads_option = ($randomreads) ? "" : "-y 0";
	
	$dwgsim_seed++;
	print "dwgsim -z $dwgsim_seed -d $fragment_mean -s $fragment_stddev -N $read_count -1 $read_length -2 $read_length $haploid_flag $randomreads_option $fasta $reads_prefix\n";
	die unless 0 == system "dwgsim -z $dwgsim_seed -d $fragment_mean -s $fragment_stddev -N $read_count -1 $read_length -2 $read_length $haploid_flag $randomreads_option $fasta $reads_prefix";
}

sub select_intron_breakpoint
{
	my $gene_id = shift;
	
	my @transcript_ids = keys %{$gene_models->{genes}{$gene_id}{transcripts}};
	my $transcript_index = rand_range(0,$#transcript_ids);
	my $transcript_id = $transcript_ids[$transcript_index];
	
	my @exons = @{$gene_models->{transcripts}{$transcript_id}{exons}};
	
	return if scalar @exons < 2;
	
	my $intron_index = rand_range(0,$#exons-1);
	my $intron_start = $exons[$intron_index]->[1] + 1;
	my $intron_end = $exons[$intron_index+1]->[0] - 1;
	
	my $genomic_position = rand_range($intron_start, $intron_end);
	
	my $fiveprime = $gene_models->calc_transcript_position($transcript_id, $exons[$intron_index]->[1]);
	my $threeprime = $gene_models->calc_transcript_position($transcript_id, $exons[$intron_index+1]->[0]);
	
	die unless $gene_models->calc_genomic_position($transcript_id, $fiveprime) == $exons[$intron_index]->[1];
	die unless $gene_models->calc_genomic_position($transcript_id, $threeprime) == $exons[$intron_index+1]->[0];
	
	if ($gene_models->{transcripts}{$transcript_id}{strand} eq "-")
	{
		($fiveprime,$threeprime) = ($threeprime,$fiveprime);
	}
	
	return ($transcript_id, $genomic_position, $fiveprime, $threeprime);
}

sub get_transcript_sequence
{
	my $transcript_id = shift;
	
	return $transcripts{$transcript_id};
}

sub get_genome_sequence
{
	my $chromosome = shift;
	my $start = shift;
	my $end = shift;
	
	return substr($genome{$chromosome}, $start - 1, $end - $start + 1)
}

sub create_breakpoint_sequence
{
	my $chromosome = shift;
	my $strand = shift;
	my $position = shift;
	
	if ($strand eq "+")
	{
		my $seq = get_genome_sequence($chromosome, $position - $breakpoint_adjacent_length + 1, $position);
		
		return $seq;
	}
	elsif ($strand eq "-")
	{
		my $seq = get_genome_sequence($chromosome, $position, $position + $breakpoint_adjacent_length - 1);
		$seq = revcomp($seq);
		
		return $seq;
	}
	else
	{
		die;
	}
}

sub revcomp
{
	my $sequence = shift;
	my $revcomp = reverse($sequence);
	$revcomp =~ tr/ACGTacgt/TGCAtgca/;
	return $revcomp;
}

sub rand_range
{
	my $start = shift;
	my $end = shift;
	
	return $start + int(rand($end - $start + 1));
}

sub read_fasta
{
	my $fasta = shift;
	
	my $current_id;
	my $current_sequence;
	
	my %sequences;
	
	open FA, $fasta or die "Error: Unable to open $fasta, $!\n";
	while (<FA>)
	{
		chomp;
		
		if (/^>(.*)/)
		{
			my $id = $1;
			
			if (defined $current_id)
			{
				$sequences{$current_id} = $current_sequence;
			}
			
			$current_id = $id;
			$current_sequence = "";
		}
		else
		{
			$current_sequence .= $_;
		}
	}
	close FA;
	
	if (defined $current_id)
	{
		$sequences{$current_id} = $current_sequence;
	}
	
	return %sequences;
}

sub write_fasta
{
	my $fasta = shift;
	my $sequences_ref = shift;
	
	open FA, ">".$fasta or die;
	foreach my $id (keys %{$sequences_ref})
	{
		print FA ">".$id."\n".$sequences_ref->{$id}."\n";
	}
	close FA;
}

sub seq_size
{
	my $fasta = shift;
	
	my $filesize = -s $fasta;
	
	return $filesize;
}

