/*
 *  ReweightSetCover.h
 *  tools
 *
 *  Created by Andrew McPherson on 10-09-02.
 *
 */

#ifndef REWEIGHTSETCOVER_H_
#define REWEIGHTSETCOVER_H_

#include "Common.h"

#include <vector>
#include <boost/bimap/bimap.hpp>
#include <boost/bimap/vector_of.hpp>
#include <boost/bimap/multiset_of.hpp>

using namespace boost;
using namespace boost::bimaps;
using namespace std;

struct PairInfo
{
	pair<double,double> weight;
	pair<int,int> size;
};

template <typename TEfficiencyCompareType>
class ReweightSetCover
{
public:
	ReweightSetCover();
	ReweightSetCover(double w1, double w2, double w3, double w4);
	
	double Solve(const IntegerVecMap& dnaClusters, const IntegerVecMap& rnaClusters, 
				 const IntegerVecMap& dnaRnaOverlap, const IntegerVecMap& rnaDnaOverlap,
				 IntegerVecMap& dnaSolutionClusters, IntegerVecMap& rnaSolutionClusters);
	
private:
	double CalculateDNAClusterWeight(bool hasRNAReads, bool rnaClusterInSolution);
	double CalculateRNAClusterWeight(bool hasDNAReads, bool dnaClusterInSolution);
	PairInfo CalculatePairInfo(int clusterPairIndex);	
	void Reweight(int clusterIndex, const IntegerVecMap& clusters, IntegerVecMap& fragmentsToClusters,
				  IntegerVecMap& clustersToClusterPairs, IntegerSet& assignedFragments, 
				  IntegerMap& clusterSize, IntegerVecMap& solutionClusters);
	
	typedef bimap<vector_of<int>,multiset_of<PairInfo,TEfficiencyCompareType> > DoubleBimap;
	
	double mW1;
	double mW2;
	double mW3;
	double mW4;
	
	IntegerSet mDNAClusterInSolution;
	IntegerSet mRNAClusterInSolution;
	IntegerMap mDNAClusterSize;
	IntegerMap mRNAClusterSize;
	IntegerPairVec mClusterPairs;
	DoubleBimap mClusterPairInfoMap;
};

class EfficiencyLessThan_Sum
{
public:
	bool operator()(const PairInfo& a, const PairInfo& b)
	{
		double efficiencyA = (a.size.first + a.size.second) / (double)(a.weight.first + a.weight.second);
		double efficiencyB = (b.size.first + b.size.second) / (double)(b.weight.first + b.weight.second);
		
		return efficiencyA < efficiencyB;
	}
};

class EfficiencyLessThan_TieBreaking
{
public:
	bool operator()(const PairInfo& a, const PairInfo& b)
	{
		double dnaEfficiencyA = a.size.first / (double)a.weight.first;
		double rnaEfficiencyA = a.size.second / (double)a.weight.second;
		double dnaEfficiencyB = b.size.first / (double)b.weight.first;
		double rnaEfficiencyB = b.size.second / (double)b.weight.second;

		if (max(dnaEfficiencyA,rnaEfficiencyA) < max(dnaEfficiencyB,rnaEfficiencyB))
		{
			return true;
		}
		else if (max(dnaEfficiencyA,rnaEfficiencyA) > max(dnaEfficiencyB,rnaEfficiencyB))
		{
			return false;
		}
		
		return (min(dnaEfficiencyA,rnaEfficiencyA) < min(dnaEfficiencyB,rnaEfficiencyB));
	}
};

typedef ReweightSetCover<EfficiencyLessThan_Sum> ReweightSetCover_Sum;
typedef ReweightSetCover<EfficiencyLessThan_TieBreaking> ReweightSetCover_TieBreaking;

#endif
