/*
 *  SimpleAligner.cpp
 *
 *  Created by Andrew McPherson on 05/09/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#include "SimpleAligner.h"
#include "DebugCheck.h"

#include <iostream>
#include <list>

using namespace std;


SimpleAligner::SimpleAligner(int matchScore, int misMatchScore, int gapScore)
: mMatchScore(matchScore), mMisMatchScore(misMatchScore), mGapScore(gapScore)
{
}

int SimpleAligner::Align(const string& reference, const string& sequence)
{
	int matrixLength = reference.size() + 1;
	int matrixHeight = sequence.size() + 1;
	
	if (matrixLength != mCurrent.size())
	{
		mCurrent.resize(matrixLength);
		mPrevious.resize(matrixLength);
	}
	
	int overallMaxScore = 0;
	
	for (int j = 0; j < matrixHeight; j++)
	{
		int seqPos = j - 1;
		
		for (int i = 0; i < matrixLength; i++) 
		{
			int refPos = i - 1;
			
			if (j == 0)
			{
				mCurrent[i] = 0;
			}
			else if (i == 0)
			{
				mCurrent[i] = mPrevious[i] + mGapScore;
			}
			else
			{
				int matchScore = mPrevious[i-1] + ((reference[refPos] == sequence[seqPos]) ? mMatchScore : mMisMatchScore);
				int gapRefScore = mCurrent[i-1] + mGapScore;
				int gapReadScore = mPrevious[i] + mGapScore;
				int maxScore = max(matchScore,max(gapRefScore,gapReadScore));
				
				overallMaxScore = max(overallMaxScore, maxScore);
				
				mCurrent[i] = maxScore;
			}
		}

		swap(mCurrent, mPrevious);
	}
	
	return overallMaxScore;
}

