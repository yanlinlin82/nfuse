/*
 *  calcspandist.cpp
 *
 *  Created by Andrew McPherson on 17/08/11.
 *
 */

#include "AlignmentIndex.h"
#include "Common.h"
#include "DebugCheck.h"
#include "Parsers.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/unordered_set.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

using namespace boost;
using namespace std;

double CalculateLength(CompAlignVec& pair);
void FindSpanning(const AlignmentIndex& concordant, const string& refName, int position, int maxFragmentLength, CompAlignTable& spanning);

int main(int argc, char* argv[])
{
	string concordantBamFilename;
	int numSamples;
	int maxFragmentLength;
	string ignoreList;
	
	try
	{
		TCLAP::CmdLine cmd("Calculate spanning distribution");
		TCLAP::ValueArg<string> concordantBamFilenameArg("c","conc","Concordant Alignments Bam Filename",true,"","string",cmd);
		TCLAP::ValueArg<int> numSamplesArg("n","numsamples","Number of Samples",true,0,"integer",cmd);
		TCLAP::ValueArg<int> maxFragmentLengthArg("m","maxfrag","Maximum Fragment Length",true,0,"integer",cmd);
		TCLAP::ValueArg<string> ignoreListArg("i","ignore","Reference Sequences to Ignore (comma separated)",false,"","string",cmd);
		cmd.parse(argc,argv);

		concordantBamFilename = concordantBamFilenameArg.getValue();
		numSamples = numSamplesArg.getValue();
		maxFragmentLength = maxFragmentLengthArg.getValue();
		ignoreList = ignoreListArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "Error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	unordered_set<string> ignoreReferences;
	if (!ignoreList.empty())
	{
		vector<string> ignoreListFields;
		split(ignoreListFields, ignoreList, is_any_of(","));
		
		for (vector<string>::const_iterator fieldIter = ignoreListFields.begin(); fieldIter != ignoreListFields.end(); fieldIter++)
		{
			ignoreReferences.insert(*fieldIter);
		}
	}
	
	AlignmentIndex concordant;
	concordant.Open(concordantBamFilename);
	
	// Initialize RNG for predictability
	srand(1);
	
	StringVec refNames;
	concordant.GetReferenceNames(refNames);
	
	int samples = 0;
	while (samples < numSamples)
	{
		int refNameIndex = rand() % refNames.size();
		const string& refName = refNames[refNameIndex];
		
		if (ignoreReferences.find(refName) != ignoreReferences.end())
		{
			continue;
		}
		
		int refLength = concordant.GetReferenceLength(refName);
		int position = rand() % refLength + 1;
		
		CompAlignTable spanning;
		FindSpanning(concordant, refName, position, maxFragmentLength, spanning);
		
		cout << spanning.size() << endl;
		
		samples++;
	}
}

double CalculateLength(CompAlignVec& pair)
{
	if (pair.size() != 2)
	{
		cerr << "Error: Invalid call to CalculateLength" << endl;
		exit(1);
	}

	return pair[1].region.end - pair[0].region.start + 1;
}

void FindSpanning(const AlignmentIndex& concordant, const string& refName, int position, int maxFragmentLength, CompAlignTable& spanning)
{
	NameIndex referenceNames;

	unordered_set<int> fragments;
	unordered_map<int,CompactAlignment> paired[2];

	CompAlignVec upstream;
	concordant.Find(refName, PlusStrand, position - maxFragmentLength, position, referenceNames, upstream);
	
	for (CompAlignVecConstIter alignIter = upstream.begin(); alignIter != upstream.end(); alignIter++)
	{
		if (alignIter->region.end < position)
		{
			paired[0][alignIter->readID.fragmentIndex] = *alignIter;
			fragments.insert(alignIter->readID.fragmentIndex);
		}
	}
	
	CompAlignVec downstream;
	concordant.Find(refName, MinusStrand, position, position + maxFragmentLength, referenceNames, downstream);
	
	for (CompAlignVecConstIter alignIter = downstream.begin(); alignIter != downstream.end(); alignIter++)
	{
		if (alignIter->region.start > position)
		{
			paired[1][alignIter->readID.fragmentIndex] = *alignIter;
			fragments.insert(alignIter->readID.fragmentIndex);
		}
	}
	
	for (unordered_set<int>::const_iterator fragmentIter = fragments.begin(); fragmentIter != fragments.end(); fragmentIter++)
	{
		int fragmentIndex = *fragmentIter;
		
		if (paired[0].find(fragmentIndex) != paired[0].end() && paired[1].find(fragmentIndex) != paired[1].end() && 
		    paired[0].find(fragmentIndex)->second.readID.readEnd != paired[1].find(fragmentIndex)->second.readID.readEnd)
		{
			spanning.push_back(CompAlignVec());
			spanning.back().push_back(paired[0].find(fragmentIndex)->second);
			spanning.back().push_back(paired[1].find(fragmentIndex)->second);
		}
	}
}

