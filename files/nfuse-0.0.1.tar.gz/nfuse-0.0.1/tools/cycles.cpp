/*
 *  cyclone.cpp
 */

#include "Common.h"
#include "DebugCheck.h"
#include "Parsers.h"
#include "Indexer.h"

#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <tclap/CmdLine.h>
#include <boost/algorithm/string.hpp>
#include <boost/bimap/bimap.hpp>
#include <boost/bimap/vector_of.hpp>
#include <boost/bimap/multiset_of.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/unordered_set.hpp>

using namespace boost;
using namespace boost::bimaps;
using namespace std;



struct RefBinPacked
{
	RefBinPacked() {}
	RefBinPacked(const RefStrand& refStrand, int bin) : referenceIndex(refStrand.referenceIndex), strand(refStrand.strand), bin(bin)
	{
		if (refStrand.referenceIndex >= (1<<18))
		{
			cout << refStrand.referenceIndex << endl;
			cout << (1<<18) << endl;
			cerr << "Packing failed, too many reference sequences" << endl;
			exit(1);
		}
		
		if (bin >= (1<<13))
		{
			cout << bin << endl;
			cout << (1<<13) << endl;
			cerr << "Packing failed, chromosome too large" << endl;
			exit(1);
		}
	}
	
	union
	{
		struct
		{
			unsigned int referenceIndex : 18;
			unsigned int strand : 1;
			unsigned int bin : 13;
		};
		
		unsigned int id;
	};
	
	bool operator<(const RefBinPacked& other) const
	{
		return id < other.id;
	}
};

inline bool operator==(const RefBinPacked& rb1, const RefBinPacked& rb2)
{
	return rb1.id == rb2.id;
}

inline size_t hash_value(const RefBinPacked& rb)
{
	size_t seed = 0;
	hash_combine(seed, rb.id);
	return seed;
}

unsigned int OtherStrand(const RefBinPacked& rb)
{
	RefBinPacked other = rb;
	other.strand = OtherStrand(rb.strand);
	
	return other.id;
}

class Binning
{
public:
	Binning(int binLength, int regionExtend) : mBinLength(binLength), mRegionExtend(regionExtend)
	{}
	
	void GetBins(const Region& region, IntegerVec& bins) const
	{
		int startBin = (region.start - mRegionExtend) / mBinLength;
		int endBin = (region.end + mRegionExtend) / mBinLength;
		
		for (int bin = startBin; bin <= endBin; bin++)
		{
			bins.push_back(bin);
		}
	}
	
	int CalcBinRelativePos(int bin, int pos) const
	{
		return pos - bin * mBinLength + mBinLength / 2;
	}
	
	int CalcAbsolutePos(int bin, int pos) const
	{
		return pos + bin * mBinLength - mBinLength / 2;
	}
	
private:
	int mBinLength;
	int mRegionExtend;
};

class RegionBins
{
public:
	void Add(int binLength, int id, const Region& region)
	{
	    int index = (int)mRegions.size();
	    
	    mRegions.push_back(region);
	    mIDs.push_back(id);
	    
	    int startBin = region.start / binLength;
	    int endBin = region.end / binLength;		
	    for (int bin = startBin; bin <= endBin; bin++)
	    {
			if (mLookup.size() <= bin)
			{
				mLookup.resize(bin + 1);
			}
			
	        mLookup[bin].push_back(index);
	    }
	}
	
	void FindOverlapping(int binLength, const Region& region, IntegerVec& ids)
	{
	    unordered_set<int> indices;
	    
	    int startBin = region.start / binLength;
	    int endBin = region.end / binLength;		
	    for (int bin = startBin; bin <= endBin; bin++)
	    {
			if (mLookup.size() <= bin)
			{
				continue;
			}
			
	        indices.insert(mLookup[bin].begin(), mLookup[bin].end());
	    }
	    
	    for (unordered_set<int>::const_iterator iter = indices.begin(); iter != indices.end(); iter++)
	    {
	        if (Overlap(region, mRegions[*iter]))
	        {
	            ids.push_back(mIDs[*iter]);
	        }
	    }
	}
	
private:
	IntegerVec mIDs;
	RegionVec mRegions;
	IntegerTable mLookup;
};

typedef vector<RegionBins> RegionBinsVec;
typedef vector<RegionBinsVec> RegionBinsTable;

class LocationBins
{
public:
	explicit LocationBins(int binLength) : mBinLength(binLength)
	{
	}
	
	void Add(int id, const CompactLocation& location)
	{
		if (mRegionBins.size() <= location.refStrand.referenceIndex)
		{
			mRegionBins.resize(location.refStrand.referenceIndex + 1);
		}
		
		mRegionBins[location.refStrand.referenceIndex].resize(2);
		
		mRegionBins[location.refStrand.referenceIndex][location.refStrand.strand].Add(mBinLength, id, location.region);
	}
	
	void FindOverlapping(const CompactLocation& location, IntegerVec& ids)
	{
		if (mRegionBins.size() <= location.refStrand.referenceIndex)
		{
			return;
		}
		
		if (mRegionBins[location.refStrand.referenceIndex].size() != 2)
		{
			return;
		}
		
		mRegionBins[location.refStrand.referenceIndex][location.refStrand.strand].FindOverlapping(mBinLength, location.region, ids);
	}
	
private:
	
	int mBinLength;
	RegionBinsTable mRegionBins;
};

double CalculateMidpointDistance(const Region& region1, const Region& region2)
{
	return abs(region1.start + region1.end - region2.start - region2.end) / 2;
}

bool Overlap(const CompactLocation& location1, const CompactLocation& location2)
{
	if (location1.refStrand.id != location2.refStrand.id)
	{
		return false;
	}
	
	return Overlap(location1.region, location2.region);
}

typedef unordered_map<int,IntegerSet> EdgeSet;

void CreateBinnedEdges(const CompactLocationMap& clusters, const Binning& binning, EdgeSet& edges)
{
	for (CompactLocationMapConstIter locationIter = clusters.begin(); locationIter != clusters.end(); locationIter++)
	{
		ClusterEndID clusterEndID;
		clusterEndID.id = locationIter->first;
		
		ClusterEndID otherEndID;
		otherEndID.id = locationIter->first;
		otherEndID.clusterEnd = OtherClusterEnd(clusterEndID.clusterEnd);
		
		const CompactLocation& clusterEnd = locationIter->second;
		const CompactLocation& otherClusterEnd = clusters.find(otherEndID.id)->second;
		
		IntegerVec clusterBins;
		binning.GetBins(clusterEnd.region, clusterBins);
		
		IntegerVec otherClusterBins;
		binning.GetBins(otherClusterEnd.region, otherClusterBins);
		
		for (IntegerVecConstIter clusterBinIter = clusterBins.begin(); clusterBinIter != clusterBins.end(); clusterBinIter++)
		{
			RefBinPacked clusterRefBin(clusterEnd.refStrand, *clusterBinIter);
			
			for (IntegerVecConstIter otherClusterBinIter = otherClusterBins.begin(); otherClusterBinIter != otherClusterBins.end(); otherClusterBinIter++)
			{
				RefBinPacked otherClusterRefBin(otherClusterEnd.refStrand, *otherClusterBinIter);
				otherClusterRefBin.strand = OtherStrand(otherClusterRefBin.strand);
				
				edges[clusterRefBin.id].insert(otherClusterRefBin.id);
				edges[otherClusterRefBin.id].insert(clusterRefBin.id);
			}
		}
	}
}

void FindKNeighbours(const EdgeSet& edges, int vertex, int k, IntegerSet& kNeighbours)
{
	kNeighbours.insert(vertex);
	
	deque<int> visit;
	unordered_map<int,int> depth;
	
	visit.push_back(vertex);
	depth[vertex] = 0;

	while (!visit.empty())
	{
		int next = visit.front();
		visit.pop_front();
				
		const IntegerSet& adjacent = edges.find(next)->second;
		for (IntegerSetConstIter adjIter = adjacent.begin(); adjIter != adjacent.end(); adjIter++)
		{
			if (depth.find(*adjIter) == depth.end())
			{
				kNeighbours.insert(*adjIter);
				
				int adjDepth = depth[next] + 1;
				
				depth[*adjIter] = adjDepth;
				
				if (adjDepth < k)
				{
					visit.push_back(vertex);
				}
			}
		}
	}
}

void CreateInduced(const EdgeSet& edges, IntegerSet& vertices, EdgeSet& induced)
{
	for (EdgeSet::const_iterator vertexIter = edges.begin(); vertexIter != edges.end(); vertexIter++)
	{
		int vertex = vertexIter->first;
		const IntegerSet& adjacent = vertexIter->second;
		
		if (vertices.find(vertex) != vertices.end())
		{
			EdgeSet::iterator inducedVertexIter = induced.insert(make_pair(vertex, IntegerSet())).first;
			
			for (IntegerSetConstIter adjIter = adjacent.begin(); adjIter != adjacent.end(); adjIter++)
			{
				if (vertices.find(*adjIter) != adjacent.end())
				{
					inducedVertexIter->second.insert(*adjIter);
				}
			}
		}
	}
}

void FindBiconnected(const EdgeSet& edges, int vertex, IntegerSet& biconnected)
{
	unordered_map<int,int> depth;
	unordered_map<int,int> lowPoint;

	vector<int> currentVertex;
	vector<IntegerSet::const_iterator> currentNeighbour;
	vector<IntegerSet::const_iterator> endNeighbour;
	IntegerTable children;
	IntegerVec parent;
	IntegerSet visited;
	
	currentVertex.push_back(vertex);
	currentNeighbour.push_back(edges.find(vertex)->second.begin());
	endNeighbour.push_back(edges.find(vertex)->second.end());
	children.push_back(IntegerVec());
	visited.insert(vertex);
	
	while (!currentVertex.empty())
	{
		if (currentNeighbour.back() == endNeighbour.back())
		{
			int vertexLowPoint = currentVertex.size() - 1;
			
			const IntegerSet& adjacent = edges.find(currentVertex.back())->second;
			for (IntegerSetConstIter adjIter = adjacent.begin(); adjIter != adjacent.end(); adjIter++)
			{
				if (parent.empty() || *adjIter != parent.back())
				{
					vertexLowPoint = min(vertexLowPoint, depth[*adjIter]);
				}
			}
			
			const IntegerVec& vertexChildren = children.back();
			for (IntegerVecConstIter childIter = vertexChildren.begin(); childIter != vertexChildren.end(); childIter++)
			{
				vertexLowPoint = min(vertexLowPoint, lowPoint[*childIter]);
			}
			
			lowPoint[currentVertex.back()] = vertexLowPoint;
			
			cout << "visit: " << currentVertex.back() << "\t";
			cout << "depth: " << depth[currentVertex.back()] << "\t";
			cout << "lowPoint: " << lowPoint[currentVertex.back()] << "\n";
			
			if (!parent.empty())
			{
				parent.pop_back();
			}
			
			currentVertex.pop_back();
			currentNeighbour.pop_back();
			endNeighbour.pop_back();
			children.pop_back();
			
			if (!currentNeighbour.empty())
			{
				currentNeighbour.back()++;
			}
		}
		else
		{
			int nextVertex = *currentNeighbour.back();
			
			if (visited.find(nextVertex) != visited.end())
			{
				currentNeighbour.back()++;
				continue;
			}
			
			depth[nextVertex] = currentVertex.size();
			
			children.back().push_back(nextVertex);
			parent.push_back(currentVertex.back());
			
			currentVertex.push_back(nextVertex);
			currentNeighbour.push_back(edges.find(nextVertex)->second.begin());
			endNeighbour.push_back(edges.find(nextVertex)->second.end());
			children.push_back(IntegerVec());
			visited.insert(nextVertex);
		}
	}
	
	vector<int> visit;

	visit.push_back(vertex);
	biconnected.insert(vertex);
	
	while (!visit.empty())
	{
		int next = visit.back();
		visit.pop_back();
		
		const IntegerSet& adjacent = edges.find(next)->second;
		for (IntegerSetConstIter adjIter = adjacent.begin(); adjIter != adjacent.end(); adjIter++)
		{
			if (biconnected.find(*adjIter) != biconnected.end())
			{
				continue;
			}
			
			DebugCheck(depth[next] != depth[*adjIter]);
			
			int x = *adjIter;
			int a = depth[next];
			int b = depth[*adjIter];
			int c = lowPoint[*adjIter];
			
			if ((depth[next] < depth[*adjIter] && lowPoint[*adjIter] < depth[*adjIter]) || (depth[next] > depth[*adjIter] && lowPoint[*adjIter] > depth[*adjIter]))
			{
				visit.push_back(*adjIter);
				biconnected.insert(*adjIter);
			}
		}
	}
}

int main(int argc, char* argv[])
{
	string clustersFilename;
	string probsFilename;
	int singleClusterID;
	string listOfClusterIDsFilename;
	int maxDeletion;
	int maxPathEdges;
	double distanceLambda;
	double minProb;
	double threshold;
	
	try
	{
		TCLAP::CmdLine cmd("Set cover for maximum parsimony");
		TCLAP::ValueArg<string> clustersFilenameArg("c","clusters","Clusters Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> probsFilenameArg("p","probs","Cluster Probabilities Filename",true,"","string",cmd);
		TCLAP::ValueArg<int> singleClusterIDArg("s","startid","Starting Cluster ID",false,-1,"integer",cmd);
		TCLAP::ValueArg<string> listOfClusterIDsFilenameArg("l","listofids","List of Starting Cluster IDs",false,"","string",cmd);
		TCLAP::ValueArg<int> maxDeletionArg("d","delmax","Maximum Deletion Size",false,5000,"integer",cmd);
		TCLAP::ValueArg<int> maxPathEdgesArg("e","edgemax","Maximum Path Edges",false,8,"integer",cmd);
		TCLAP::ValueArg<double> distanceLambdaArg("y","lambda","Distance Falloff Parameter Lambda",false,2000.0,"float",cmd);
		TCLAP::ValueArg<double> minProbArg("m","minprob","Minimum Probability",false,1e-12,"float",cmd);
		TCLAP::ValueArg<double> thresholdArg("t","threshold","Threshold Cluster Probability",false,1e-10,"float",cmd);
		cmd.parse(argc,argv);
		
		clustersFilename = clustersFilenameArg.getValue();
		probsFilename = probsFilenameArg.getValue();
		singleClusterID = singleClusterIDArg.getValue();
		listOfClusterIDsFilename = listOfClusterIDsFilenameArg.getValue();
		maxDeletion = maxDeletionArg.getValue();
		maxPathEdges = maxPathEdgesArg.getValue();
		distanceLambda = distanceLambdaArg.getValue();
		minProb = minProbArg.getValue();
		threshold = thresholdArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	IntegerVec startClustersIDs;
	
	if (singleClusterID != -1)
	{
		startClustersIDs.push_back(singleClusterID);
	}
	else if (listOfClusterIDsFilename != "")
	{
		ifstream listOfClusterIDsFile(listOfClusterIDsFilename.c_str());
		CheckFile(listOfClusterIDsFile, listOfClusterIDsFilename);
		
		// Parse file contents
		string line;
		int lineNumber = 0;
		while (getline(listOfClusterIDsFile, line))
		{
			lineNumber++;
			
			if (line.length() == 0)
			{
				cerr << "Error: Empty clusters line " << lineNumber << " of " << listOfClusterIDsFilename << endl;
				exit(1);
			}
			
			int clusterID = lexical_cast<int>(line);
			
			startClustersIDs.push_back(clusterID);
		}
		
		listOfClusterIDsFile.close();
	}
	
	int binLength = 2000;
	
	double minScore = log(minProb);
	
	cerr << "Reading DNA clusters" << endl;
	
	CompactLocationVecMap dnaClusters;
	NameIndex references;
	ReadClusters(clustersFilename, dnaClusters, references);
	
	DoubleMap dnaClusterProb;
	ReadDoubleMap(probsFilename, dnaClusterProb);
	
	for (DoubleMapConstIter dnaClusterIter = dnaClusterProb.begin(); dnaClusterIter != dnaClusterProb.end(); dnaClusterIter++)
	{
		if (dnaClusterIter->second < threshold)
		{
			dnaClusters.erase(dnaClusterIter->first);
		}
	}
	
	if (startClustersIDs.empty())
	{
		for (DoubleMapConstIter dnaClusterIter = dnaClusterProb.begin(); dnaClusterIter != dnaClusterProb.end(); dnaClusterIter++)
		{
			if (dnaClusterIter->second > 0.1)
			{
				startClustersIDs.push_back(dnaClusterIter->first);
			}
		}
	}
	
	cerr << "Binning clusters" << endl;
	
	LocationBins dnaBinLookup(binLength);
	for (CompactLocationVecMapConstIter dnaClusterIter = dnaClusters.begin(); dnaClusterIter != dnaClusters.end(); dnaClusterIter++)
	{
		DebugCheck(dnaClusterIter->second.size() == 2);
		
		for (int dnaClusterEnd = 0; dnaClusterEnd <= 1; dnaClusterEnd++)
		{
			ClusterEndID dnaClusterEndID;
			dnaClusterEndID.clusterID = dnaClusterIter->first;
			dnaClusterEndID.clusterEnd = dnaClusterEnd;
			
			dnaBinLookup.Add(dnaClusterEndID.id, dnaClusterIter->second[dnaClusterEnd]);
		}
	}

	cerr << "Starting search on " << startClustersIDs.size() << " clusters" << endl;
	
	for (IntegerVecConstIter clusterIDIter = startClustersIDs.begin(); clusterIDIter != startClustersIDs.end(); clusterIDIter++)
	{
		int clusterID = *clusterIDIter;

		if (dnaClusters.find(clusterID) == dnaClusters.end())
		{
			continue;
		}
		
		int visitCount = 0;
		int touchCount = 0;
		
		ClusterEndID startClusterID;
		startClusterID.clusterID = clusterID;
		startClusterID.clusterEnd = 0;
		
		CompactLocation startLocation = dnaClusters[startClusterID.clusterID][startClusterID.clusterEnd];
		
		cerr << "Starting DFS for cluster " << clusterID << " ... ";
		cerr.flush();
		
		vector<pair<double,unsigned int> > toVisit;
		IntegerSet visited;
		
		unordered_map<unsigned int,double> toScore;
		unordered_map<unsigned int,unsigned int> toNumEdges;
		unordered_map<unsigned int,unsigned int> fromIDs;
		
		toVisit.push_back(make_pair(log(dnaClusterProb[startClusterID.clusterID]), startClusterID.id));
		push_heap(toVisit.begin(), toVisit.end());
		
		toNumEdges[startClusterID.id] = 0;
		toScore[startClusterID.id] = 0;
		
		while (!toVisit.empty())
		{
			ClusterEndID nextClusterEndID;
			pop_heap(toVisit.begin(), toVisit.end());
			nextClusterEndID.id = toVisit.back().second;
			toVisit.pop_back();
			
			visitCount++;
			
			if (nextClusterEndID.id == startClusterID.id && toScore[startClusterID.id] != 0)
			{
				break;
			}
			
			if (visited.find(nextClusterEndID.id) != visited.end())
			{
				continue;
			}
			
			CompactLocation location = dnaClusters[nextClusterEndID.clusterID][nextClusterEndID.clusterEnd];
			location.refStrand.strand = OtherStrand(location.refStrand.strand);
			location.region.start -= maxDeletion;
			location.region.end += maxDeletion;
			
			IntegerVec overlapClusterEndIDs;
			dnaBinLookup.FindOverlapping(location, overlapClusterEndIDs);
			
			for (IntegerVecConstIter idIter = overlapClusterEndIDs.begin(); idIter != overlapClusterEndIDs.end(); idIter++)
			{
				ClusterEndID overlapClusterEndID;
				overlapClusterEndID.id = *idIter;
				
				ClusterEndID otherClusterEndID = overlapClusterEndID;
				otherClusterEndID.clusterEnd = OtherClusterEnd(otherClusterEndID.clusterEnd);
				
				touchCount++;
				
				if (visited.find(otherClusterEndID.id) != visited.end() && otherClusterEndID.id != startClusterID.id)
				{
					continue;
				}
				
				if (otherClusterEndID.clusterID == nextClusterEndID.clusterID)
				{
					continue;
				}
				
				CompactLocation overlapLocation = dnaClusters[overlapClusterEndID.clusterID][overlapClusterEndID.clusterEnd];
				
				double distance = CalculateMidpointDistance(location.region, overlapLocation.region);
				double distanceScore = -distance / distanceLambda;
				double clusterScore = log(dnaClusterProb[overlapClusterEndID.clusterID]);
				double edgeScore = distanceScore + clusterScore;
				
				double pathScore = edgeScore + toScore[nextClusterEndID.id];
				
				if (pathScore >= minScore && (toScore.find(otherClusterEndID.id) == toScore.end() || pathScore > toScore[otherClusterEndID.id] || otherClusterEndID.id == startClusterID.id))
				{
					fromIDs[otherClusterEndID.id] = nextClusterEndID.id;
					toNumEdges[otherClusterEndID.id] = toNumEdges[nextClusterEndID.id] + 1;
					toScore[otherClusterEndID.id] = pathScore;
					
					if (toNumEdges[nextClusterEndID.id] + 1 < maxPathEdges)
					{
						toVisit.push_back(make_pair(pathScore, otherClusterEndID.id));
						push_heap(toVisit.begin(), toVisit.end());
					}
				}
			}
			
			visited.insert(nextClusterEndID.id);
		}
		
		cerr << "touched " << touchCount << " visited " << visitCount << " ";
		
		if (fromIDs.find(startClusterID.id) != fromIDs.end())
		{
			ClusterEndID traverseClusterID;
			
			cout << toScore[startClusterID.id] << "\t";

			cout << startClusterID.clusterID << "\t";			
			traverseClusterID.id = fromIDs[startClusterID.id];
			
			while (fromIDs.find(traverseClusterID.id) != fromIDs.end() && traverseClusterID.id != startClusterID.id)
			{
				cout << traverseClusterID.clusterID << "\t";			
				traverseClusterID.id = fromIDs[traverseClusterID.id];
			}
			cout << endl;
			
			cerr << "Found Cycle" << endl;
		}
		else
		{
			cerr << "No Cycle" << endl;
		}
	}
}


