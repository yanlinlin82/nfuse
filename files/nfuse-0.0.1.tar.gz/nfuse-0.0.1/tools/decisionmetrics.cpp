/*
 *  overlapclusters.cpp
 *  tools
 *
 *  Created by Andrew McPherson on 10-08-11.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */


#include "CompactBreakRegion.h"
#include "DebugCheck.h"
#include "Matrix.h"
#include "Parsers.h"

#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/unordered_set.hpp>
#include <boost/unordered_map.hpp>

using namespace boost;
using namespace std;


void ReadClusterIDs(const string& clustersFilename, IntegerVec& clusterIDs)
{
	// Open clusters file
	ifstream clustersFile(clustersFilename.c_str());
	if (!clustersFile)
	{
		cerr << "Error: unable to read from clusters file " << clustersFilename << endl;		
		exit(1);
	}
	
	unordered_set<int> uniqueClusterIDs;
	
	// Parse file contents
	string line;
	int lineNumber = 0;
	while (getline(clustersFile, line))
	{
		lineNumber++;
		
		if (line.length() == 0)
		{
			cerr << "Error: Empty clusters line " << lineNumber << " of " << clustersFilename << endl;
			exit(1);
		}
		
		vector<string> clusterFields;
		split(clusterFields, line, is_any_of("\t"));
		if (clusterFields.size() < 1)
		{
			cerr << "Error: Format error for clusters line " << lineNumber << " of " << clustersFilename << endl;
			exit(1);
		}
		
		int clusterID = lexical_cast<int>(clusterFields[0]);		
		if (clusterID < 0)
		{
			cerr << "Error: Invalid cluster ID for line " << lineNumber << " of " << clustersFilename << endl;
			exit(1);
		}
		
		uniqueClusterIDs.insert(clusterID);
	}
	
	clustersFile.close();

	clusterIDs = IntegerVec(uniqueClusterIDs.begin(), uniqueClusterIDs.end());
}

void Sort(IntegerTable& clusters)
{
	for (IntegerTableIter clusterIter = clusters.begin(); clusterIter != clusters.end(); clusterIter++)
	{
		sort(clusterIter->begin(), clusterIter->end());
	}
}

template<typename TIterator1, typename TIterator2>
bool intersects(TIterator1 first1, TIterator1 last1, TIterator2 first2, TIterator2 last2)
{
	while (first1 != last1 && first2 != last2)
	{
		if (*first1 < *first2)
		{
			++first1;
		}
		else if (*first2 < *first1)
		{
			++first2;
		}
		else
		{
			return true;
		}
	}
	
	return false;
}

bool Overlap(const CompactLocation& r1, const CompactLocation& r2)
{
	return (r1.refStrand.id == r2.refStrand.id && !(r1.region.end < r2.region.start || r2.region.end < r1.region.start));
}

bool Overlap(const CompactLocationVec& breaks1, const CompactLocationVec& breaks2)
{
	DebugCheck(breaks1.size() == 2 && breaks2.size() == 2);

	Matrix<int> overlap(2,2);
	overlap.Clear(0);

	for (int breakIndex1 = 0; breakIndex1 <= 1; breakIndex1++)
	{
		for (int breakIndex2 = 0; breakIndex2 <= 1; breakIndex2++)
		{
			if (Overlap(breaks1[breakIndex1], breaks2[breakIndex2]))
			{
				overlap(breakIndex1,breakIndex2) = 1;
			}
		}
	}
	
	return overlap(0,0) && overlap(1,1) || overlap(0,1) && overlap(1,0);
}

int CalculateNumDisjointComponents(const IntegerVec& clusterIDs, const CompactLocationTable& breakRegionPairs)
{
	if (clusterIDs.empty())
	{
		return 0;
	}
	
	unordered_map<int,IntegerVec> overlapGraph;
	for (IntegerVecConstIter clusterIDIter1 = clusterIDs.begin(); clusterIDIter1 != clusterIDs.end(); clusterIDIter1++)
	{
		for (IntegerVecConstIter clusterIDIter2 = clusterIDs.begin(); clusterIDIter2 != clusterIDs.end(); clusterIDIter2++)
		{
			if (Overlap(breakRegionPairs[*clusterIDIter1], breakRegionPairs[*clusterIDIter2]))
			{
				overlapGraph[*clusterIDIter1].push_back(*clusterIDIter2);
			}
		}
	}
	
	int componentCount = 0;
	
	IntegerVec searchStack;
	while (!overlapGraph.empty())
	{
		if (searchStack.empty())
		{
			searchStack.push_back(overlapGraph.begin()->first);
			componentCount++;
		}
		
		int currentElement = searchStack.back();
		searchStack.pop_back();
		
		if (overlapGraph.find(currentElement) != overlapGraph.end())
		{
			searchStack.insert(searchStack.end(), overlapGraph[currentElement].begin(), overlapGraph[currentElement].end());
			overlapGraph.erase(currentElement);
		}
	}
	
	return componentCount;
}

void BreakRegionPairs(const BrRegVec& breakRegions, CompactLocationTable& breakRegionPairs)
{
	for (BrRegVecConstIter brRegIter = breakRegions.begin(); brRegIter != breakRegions.end(); brRegIter++)
	{
		CompactLocation brLoc;
		brLoc.refStrand = brRegIter->refStrand;
		brLoc.region.start = brRegIter->start;
		brLoc.region.end = brRegIter->end;
		
		breakRegionPairs.resize(brRegIter->clustEnd.clusterID + 1);
		breakRegionPairs[brRegIter->clustEnd.clusterID].push_back(brLoc);
	}
}

int main(int argc, char* argv[])
{
	string breakRegionsFilename;
	string selectClustersFilename;
	string allClustersFilename;
	string decisionsFilename;
	
	try
	{
		TCLAP::CmdLine cmd("Overlap between break regions tool");
		TCLAP::ValueArg<string> breakRegionsFilenameArg("b","breaks","Input Breakpoint Regions Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> selectClustersFilenameArg("s","select","Input Selected Clusters Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> allClustersFilenameArg("a","all","Input All Clusters Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> decisionsFilenameArg("d","decisions","Output Decision Metrics Filename",true,"","string",cmd);
		cmd.parse(argc,argv);
		
		breakRegionsFilename = breakRegionsFilenameArg.getValue();
		selectClustersFilename = selectClustersFilenameArg.getValue();
		allClustersFilename = allClustersFilenameArg.getValue();
		decisionsFilename = decisionsFilenameArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	if (sizeof(long) != 8)
	{
		cerr << "Error: sizeof(long) != 8" << endl;		
		exit(1);
	}
	
	cout << "Reading break regions" << endl;
	
	BrRegVec breakRegions;
	NameIndex referenceNames;
	ReadBreakRegions(breakRegionsFilename, referenceNames, breakRegions);

	cout << "Resorting break regions" << endl;
	
	CompactLocationTable breakRegionPairs;
	BreakRegionPairs(breakRegions, breakRegionPairs);

	cout << "Reading selected clusters" << endl;
	
	IntegerVec selectClusterIDs;
	ReadClusterIDs(selectClustersFilename, selectClusterIDs);
	
	cout << "Reading all clusters" << endl;
	
	IntegerTable allClusters;	
	ReadClusters(allClustersFilename, allClusters);
	
	cout << "Sorting all clusters" << endl;
	
	Sort(allClusters);
	
	// Open decision metrics file
	ofstream decisionsFile(decisionsFilename.c_str());
	if (!decisionsFile)
	{
		cerr << "Error: unable to write to decisions file " << decisionsFilename << endl;		
		exit(1);
	}

	cout << "Finding number of overlap components for read set equivalent clusters" << endl;
	
	for (IntegerVecConstIter clusterIDIter = selectClusterIDs.begin(); clusterIDIter != selectClusterIDs.end(); clusterIDIter++)
	{
		int clusterIndex1 = *clusterIDIter;
		const IntegerVec& cluster1 = allClusters[clusterIndex1];
		
		IntegerVec readSetEquivalent;
		for (int clusterIndex2 = 0; clusterIndex2 < allClusters.size(); clusterIndex2++)
		{
			const IntegerVec& cluster2 = allClusters[clusterIndex2];
			
			bool eq = cluster1.size() == cluster2.size() && equal(cluster1.begin(), cluster1.end(), cluster2.begin());
			bool incl = includes(cluster1.begin(), cluster1.end(), cluster2.begin(), cluster2.end());
			bool olap = intersects(cluster1.begin(), cluster1.end(), cluster2.begin(), cluster2.end());
			if (eq || !incl && olap)
			{
				readSetEquivalent.push_back(clusterIndex2);
			}
		}
		
		int numDisjointComponents = CalculateNumDisjointComponents(readSetEquivalent,breakRegionPairs);
				
		decisionsFile << clusterIndex1 << "\t" << numDisjointComponents << endl;
	}
	
	decisionsFile.close();
}

