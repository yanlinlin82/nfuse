/*
 *  matealignnull.cpp
 *
 *  Created by Andrew McPherson on 28/09/09.
 *
 */

#include "Common.h"
#include "DebugCheck.h"
#include "Indexer.h"
#include "ReadStream.h"
#include "Sequences.h"
#include "SimpleAligner.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

using namespace boost;
using namespace std;


int main(int argc, char* argv[])
{
	int matchScore;
	int misMatchScore;
	int gapScore;
	int numSamples;
	int searchLength;
	int readLength;
	string referenceFasta;
	
	try
	{
		TCLAP::CmdLine cmd("Mate Realignment Null Distribution");
		TCLAP::ValueArg<int> matchScoreArg("m","match","Match Score",true,0,"int",cmd);
		TCLAP::ValueArg<int> misMatchScoreArg("x","mismatch","Mismatch Score",true,0,"int",cmd);
		TCLAP::ValueArg<int> gapScoreArg("g","gap","Gap Score",true,0,"int",cmd);
		TCLAP::ValueArg<int> numSamplesArg("n","numsamples","Number of Samples",true,0,"integer",cmd);
		TCLAP::ValueArg<int> searchLengthArg("s","searchlength","Search Length",true,-1,"integer",cmd);
		TCLAP::ValueArg<int> readLengthArg("r","readlength","Read Length",true,-1,"integer",cmd);
		TCLAP::ValueArg<string> referenceFastaArg("f","fasta","Reference Sequences Fasta",true,"","string",cmd);
		cmd.parse(argc,argv);
		
		matchScore = matchScoreArg.getValue();
		misMatchScore = misMatchScoreArg.getValue();
		gapScore = gapScoreArg.getValue();
		numSamples = numSamplesArg.getValue();
		searchLength = searchLengthArg.getValue();
		readLength = readLengthArg.getValue();
		referenceFasta = referenceFastaArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
		
	cerr << "Read reference fasta" << endl;
	
	Sequences referenceSequences;
	referenceSequences.Read(referenceFasta);
	
	SimpleAligner aligner(matchScore, misMatchScore, gapScore);
	
	// Initialize RNG for predictability
	srand(1);
		
	int samples = 0;
	while (samples < numSamples)
	{
		string referenceSequence;
		referenceSequences.GetRandomSequence(searchLength, referenceSequence);
		
		string readSequence;
		referenceSequences.GetRandomSequence(readLength, readSequence);
		
		int score = aligner.Align(referenceSequence, readSequence);
		int maxScore = readSequence.size() * matchScore;
		double percent = (double) score / (double) maxScore;
		
		cout << percent << endl;

		samples++;
	}
}

