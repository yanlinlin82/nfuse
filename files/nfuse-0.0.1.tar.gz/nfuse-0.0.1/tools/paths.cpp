/*
 *  cyclone.cpp
 */

#include "Common.h"
#include "DebugCheck.h"
#include "Parsers.h"
#include "Indexer.h"

#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <tclap/CmdLine.h>
#include <boost/algorithm/string.hpp>
#include <boost/bimap/bimap.hpp>
#include <boost/bimap/vector_of.hpp>
#include <boost/bimap/multiset_of.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/unordered_set.hpp>

using namespace boost;
using namespace boost::bimaps;
using namespace std;



struct RefBinPacked
{
	RefBinPacked() {}
	RefBinPacked(const RefStrand& refStrand, int bin) : referenceIndex(refStrand.referenceIndex), strand(refStrand.strand), bin(bin)
	{
		if (refStrand.referenceIndex >= (1<<18))
		{
			cout << refStrand.referenceIndex << endl;
			cout << (1<<18) << endl;
			cerr << "Packing failed, too many reference sequences" << endl;
			exit(1);
		}
		
		if (bin >= (1<<13))
		{
			cout << bin << endl;
			cout << (1<<13) << endl;
			cerr << "Packing failed, chromosome too large" << endl;
			exit(1);
		}
	}
	
	union
	{
		struct
		{
			unsigned int referenceIndex : 18;
			unsigned int strand : 1;
			unsigned int bin : 13;
		};
		
		unsigned int id;
	};
	
	bool operator<(const RefBinPacked& other) const
	{
		return id < other.id;
	}
};

inline bool operator==(const RefBinPacked& rb1, const RefBinPacked& rb2)
{
	return rb1.id == rb2.id;
}

inline size_t hash_value(const RefBinPacked& rb)
{
	size_t seed = 0;
	hash_combine(seed, rb.id);
	return seed;
}

unsigned int OtherStrand(const RefBinPacked& rb)
{
	RefBinPacked other = rb;
	other.strand = OtherStrand(rb.strand);
	
	return other.id;
}

class Binning
{
public:
	Binning(int binLength, int regionExtend) : mBinLength(binLength), mRegionExtend(regionExtend)
	{}
	
	void GetBins(const Region& region, IntegerVec& bins) const
	{
		int startBin = (region.start - mRegionExtend) / mBinLength;
		int endBin = (region.end + mRegionExtend) / mBinLength;
		
		for (int bin = startBin; bin <= endBin; bin++)
		{
			bins.push_back(bin);
		}
	}
	
	int CalcBinRelativePos(int bin, int pos) const
	{
		return pos - bin * mBinLength + mBinLength / 2;
	}
	
	int CalcAbsolutePos(int bin, int pos) const
	{
		return pos + bin * mBinLength - mBinLength / 2;
	}
	
private:
	int mBinLength;
	int mRegionExtend;
};

class RegionBins
{
public:
	void Add(int binLength, int id, const Region& region)
	{
	    int index = (int)mRegions.size();
	    
	    mRegions.push_back(region);
	    mIDs.push_back(id);
	    
	    int startBin = region.start / binLength;
	    int endBin = region.end / binLength;		
	    for (int bin = startBin; bin <= endBin; bin++)
	    {
			if (mLookup.size() <= bin)
			{
				mLookup.resize(bin + 1);
			}
			
	        mLookup[bin].push_back(index);
	    }
	}
	
	void FindOverlapping(int binLength, const Region& region, IntegerVec& ids)
	{
	    unordered_set<int> indices;
	    
	    int startBin = region.start / binLength;
	    int endBin = region.end / binLength;		
	    for (int bin = startBin; bin <= endBin; bin++)
	    {
			if (mLookup.size() <= bin)
			{
				continue;
			}
			
	        indices.insert(mLookup[bin].begin(), mLookup[bin].end());
	    }
	    
	    for (unordered_set<int>::const_iterator iter = indices.begin(); iter != indices.end(); iter++)
	    {
	        if (Overlap(region, mRegions[*iter]))
	        {
	            ids.push_back(mIDs[*iter]);
	        }
	    }
	}
	
private:
	IntegerVec mIDs;
	RegionVec mRegions;
	IntegerTable mLookup;
};

typedef vector<RegionBins> RegionBinsVec;
typedef vector<RegionBinsVec> RegionBinsTable;

class LocationBins
{
public:
	explicit LocationBins(int binLength) : mBinLength(binLength)
	{
	}
	
	void Add(int id, const CompactLocation& location)
	{
		if (mRegionBins.size() <= location.refStrand.referenceIndex)
		{
			mRegionBins.resize(location.refStrand.referenceIndex + 1);
		}
		
		mRegionBins[location.refStrand.referenceIndex].resize(2);
		
		mRegionBins[location.refStrand.referenceIndex][location.refStrand.strand].Add(mBinLength, id, location.region);
	}
	
	void FindOverlapping(const CompactLocation& location, IntegerVec& ids)
	{
		if (mRegionBins.size() <= location.refStrand.referenceIndex)
		{
			return;
		}
		
		if (mRegionBins[location.refStrand.referenceIndex].size() != 2)
		{
			return;
		}
		
		mRegionBins[location.refStrand.referenceIndex][location.refStrand.strand].FindOverlapping(mBinLength, location.region, ids);
	}
	
private:
	
	int mBinLength;
	RegionBinsTable mRegionBins;
};

double CalculateMidpointDistance(const Region& region1, const Region& region2)
{
	return abs(region1.start + region1.end - region2.start - region2.end) / 2;
}

double CalculateIntronic(const CompactLocation& rna, const CompactLocation& dna)
{
	if (rna.refStrand.strand == PlusStrand)
	{
		return dna.region.end - rna.region.start;
	}
	else
	{
		return rna.region.end - dna.region.start;
	}
}

bool Overlap(const CompactLocation& location1, const CompactLocation& location2)
{
	if (location1.refStrand.id != location2.refStrand.id)
	{
		return false;
	}
	
	return Overlap(location1.region, location2.region);
}

typedef unordered_map<int,IntegerSet> EdgeSet;

void CreateBinnedEdges(const CompactLocationMap& clusters, const Binning& binning, EdgeSet& edges)
{
	for (CompactLocationMapConstIter locationIter = clusters.begin(); locationIter != clusters.end(); locationIter++)
	{
		ClusterEndID clusterEndID;
		clusterEndID.id = locationIter->first;
		
		ClusterEndID otherEndID;
		otherEndID.id = locationIter->first;
		otherEndID.clusterEnd = OtherClusterEnd(clusterEndID.clusterEnd);
		
		const CompactLocation& clusterEnd = locationIter->second;
		const CompactLocation& otherClusterEnd = clusters.find(otherEndID.id)->second;
		
		IntegerVec clusterBins;
		binning.GetBins(clusterEnd.region, clusterBins);
		
		IntegerVec otherClusterBins;
		binning.GetBins(otherClusterEnd.region, otherClusterBins);
		
		for (IntegerVecConstIter clusterBinIter = clusterBins.begin(); clusterBinIter != clusterBins.end(); clusterBinIter++)
		{
			RefBinPacked clusterRefBin(clusterEnd.refStrand, *clusterBinIter);
			
			for (IntegerVecConstIter otherClusterBinIter = otherClusterBins.begin(); otherClusterBinIter != otherClusterBins.end(); otherClusterBinIter++)
			{
				RefBinPacked otherClusterRefBin(otherClusterEnd.refStrand, *otherClusterBinIter);
				otherClusterRefBin.strand = OtherStrand(otherClusterRefBin.strand);
				
				edges[clusterRefBin.id].insert(otherClusterRefBin.id);
				edges[otherClusterRefBin.id].insert(clusterRefBin.id);
			}
		}
	}
}

void FindKNeighbours(const EdgeSet& edges, int vertex, int k, IntegerSet& kNeighbours)
{
	kNeighbours.insert(vertex);
	
	deque<int> visit;
	unordered_map<int,int> depth;
	
	visit.push_back(vertex);
	depth[vertex] = 0;

	while (!visit.empty())
	{
		int next = visit.front();
		visit.pop_front();
				
		const IntegerSet& adjacent = edges.find(next)->second;
		for (IntegerSetConstIter adjIter = adjacent.begin(); adjIter != adjacent.end(); adjIter++)
		{
			if (depth.find(*adjIter) == depth.end())
			{
				kNeighbours.insert(*adjIter);
				
				int adjDepth = depth[next] + 1;
				
				depth[*adjIter] = adjDepth;
				
				if (adjDepth < k)
				{
					visit.push_back(vertex);
				}
			}
		}
	}
}

void CreateInduced(const EdgeSet& edges, IntegerSet& vertices, EdgeSet& induced)
{
	for (EdgeSet::const_iterator vertexIter = edges.begin(); vertexIter != edges.end(); vertexIter++)
	{
		int vertex = vertexIter->first;
		const IntegerSet& adjacent = vertexIter->second;
		
		if (vertices.find(vertex) != vertices.end())
		{
			EdgeSet::iterator inducedVertexIter = induced.insert(make_pair(vertex, IntegerSet())).first;
			
			for (IntegerSetConstIter adjIter = adjacent.begin(); adjIter != adjacent.end(); adjIter++)
			{
				if (vertices.find(*adjIter) != adjacent.end())
				{
					inducedVertexIter->second.insert(*adjIter);
				}
			}
		}
	}
}

void FindBiconnected(const EdgeSet& edges, int vertex, IntegerSet& biconnected)
{
	unordered_map<int,int> depth;
	unordered_map<int,int> lowPoint;

	vector<int> currentVertex;
	vector<IntegerSet::const_iterator> currentNeighbour;
	vector<IntegerSet::const_iterator> endNeighbour;
	IntegerTable children;
	IntegerVec parent;
	IntegerSet visited;
	
	currentVertex.push_back(vertex);
	currentNeighbour.push_back(edges.find(vertex)->second.begin());
	endNeighbour.push_back(edges.find(vertex)->second.end());
	children.push_back(IntegerVec());
	visited.insert(vertex);
	
	while (!currentVertex.empty())
	{
		if (currentNeighbour.back() == endNeighbour.back())
		{
			int vertexLowPoint = currentVertex.size() - 1;
			
			const IntegerSet& adjacent = edges.find(currentVertex.back())->second;
			for (IntegerSetConstIter adjIter = adjacent.begin(); adjIter != adjacent.end(); adjIter++)
			{
				if (parent.empty() || *adjIter != parent.back())
				{
					vertexLowPoint = min(vertexLowPoint, depth[*adjIter]);
				}
			}
			
			const IntegerVec& vertexChildren = children.back();
			for (IntegerVecConstIter childIter = vertexChildren.begin(); childIter != vertexChildren.end(); childIter++)
			{
				vertexLowPoint = min(vertexLowPoint, lowPoint[*childIter]);
			}
			
			lowPoint[currentVertex.back()] = vertexLowPoint;
			
			cout << "visit: " << currentVertex.back() << "\t";
			cout << "depth: " << depth[currentVertex.back()] << "\t";
			cout << "lowPoint: " << lowPoint[currentVertex.back()] << "\n";
			
			if (!parent.empty())
			{
				parent.pop_back();
			}
			
			currentVertex.pop_back();
			currentNeighbour.pop_back();
			endNeighbour.pop_back();
			children.pop_back();
			
			if (!currentNeighbour.empty())
			{
				currentNeighbour.back()++;
			}
		}
		else
		{
			int nextVertex = *currentNeighbour.back();
			
			if (visited.find(nextVertex) != visited.end())
			{
				currentNeighbour.back()++;
				continue;
			}
			
			depth[nextVertex] = currentVertex.size();
			
			children.back().push_back(nextVertex);
			parent.push_back(currentVertex.back());
			
			currentVertex.push_back(nextVertex);
			currentNeighbour.push_back(edges.find(nextVertex)->second.begin());
			endNeighbour.push_back(edges.find(nextVertex)->second.end());
			children.push_back(IntegerVec());
			visited.insert(nextVertex);
		}
	}
	
	vector<int> visit;

	visit.push_back(vertex);
	biconnected.insert(vertex);
	
	while (!visit.empty())
	{
		int next = visit.back();
		visit.pop_back();
		
		const IntegerSet& adjacent = edges.find(next)->second;
		for (IntegerSetConstIter adjIter = adjacent.begin(); adjIter != adjacent.end(); adjIter++)
		{
			if (biconnected.find(*adjIter) != biconnected.end())
			{
				continue;
			}
			
			DebugCheck(depth[next] != depth[*adjIter]);
			
			int x = *adjIter;
			int a = depth[next];
			int b = depth[*adjIter];
			int c = lowPoint[*adjIter];
			
			if ((depth[next] < depth[*adjIter] && lowPoint[*adjIter] < depth[*adjIter]) || (depth[next] > depth[*adjIter] && lowPoint[*adjIter] > depth[*adjIter]))
			{
				visit.push_back(*adjIter);
				biconnected.insert(*adjIter);
			}
		}
	}
}

int main(int argc, char* argv[])
{
	string dnaClustersFilename;
	string dnaProbsFilename;
	string rnaBreakpointsFilename;
	int maxPathEdges;
	double minProb;
	int  maxPartIntron;
	double intronLengthLambda;
	double threshold;
	
	try
	{
		TCLAP::CmdLine cmd("DNA paths between RNA-Seq breakpoints");
		TCLAP::ValueArg<string> dnaClustersFilenameArg("d","dna","DNA Clusters Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> dnaProbsFilenameArg("p","probs","DNA Cluster Probabilities Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> rnaBreakpointsFilenameArg("r","rna","RNA-Seq Breakpoints Filename",true,"","string",cmd);
		TCLAP::ValueArg<int> maxPathEdgesArg("e","edgemax","Maximum Path Edges",false,8,"integer",cmd);
		TCLAP::ValueArg<double> minProbArg("m","minprob","Minimum Probability",false,1e-12,"float",cmd);
		TCLAP::ValueArg<int> maxPartIntronArg("i","maxintron","Maximum Intron Fragment",false,60000,"integer",cmd);
		TCLAP::ValueArg<double> intronLengthLambdaArg("y","lambda","Distance Falloff Parameter Lambda",false,20000,"float",cmd);
		TCLAP::ValueArg<double> thresholdArg("t","threshold","Threshold Cluster Probability",false,1e-10,"float",cmd);
		cmd.parse(argc,argv);
		
		dnaClustersFilename = dnaClustersFilenameArg.getValue();
		dnaProbsFilename = dnaProbsFilenameArg.getValue();
		rnaBreakpointsFilename = rnaBreakpointsFilenameArg.getValue();
		maxPathEdges = maxPathEdgesArg.getValue();
		minProb = minProbArg.getValue();
		maxPartIntron = maxPartIntronArg.getValue();
		intronLengthLambda = intronLengthLambdaArg.getValue();
		threshold = thresholdArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	int binLength = 2000;
	
	double minScore = log(minProb);
	
	cerr << "Reading DNA clusters" << endl;
	
	CompactLocationVecMap dnaClusters;
	NameIndex references;
	ReadClusters(dnaClustersFilename, dnaClusters, references);
	
	cerr << "Reading DNA cluster probabilities" << endl;
	
	DoubleMap dnaClusterProb;
	ReadDoubleMap(dnaProbsFilename, dnaClusterProb);

	for (DoubleMapConstIter dnaClusterIter = dnaClusterProb.begin(); dnaClusterIter != dnaClusterProb.end(); dnaClusterIter++)
	{
		if (dnaClusterIter->second < threshold)
		{
			dnaClusters.erase(dnaClusterIter->first);
		}
	}
	
	cerr << "Reading RNA breakpoints" << endl;
	
	LocationVecMap rnaBreakpoints;
	ReadAlignRegionPairs(rnaBreakpointsFilename, rnaBreakpoints);
	
	cerr << "Binning clusters" << endl;
	
	LocationBins dnaBinLookup(binLength);
	for (CompactLocationVecMapConstIter dnaClusterIter = dnaClusters.begin(); dnaClusterIter != dnaClusters.end(); dnaClusterIter++)
	{
		DebugCheck(dnaClusterIter->second.size() == 2);
		
		for (int dnaClusterEnd = 0; dnaClusterEnd <= 1; dnaClusterEnd++)
		{
			ClusterEndID dnaClusterEndID;
			dnaClusterEndID.clusterID = dnaClusterIter->first;
			dnaClusterEndID.clusterEnd = dnaClusterEnd;
			
			dnaBinLookup.Add(dnaClusterEndID.id, dnaClusterIter->second[dnaClusterEnd]);
		}
	}
	
	for (LocationVecMapConstIter rnaBreakpointIter = rnaBreakpoints.begin(); rnaBreakpointIter != rnaBreakpoints.end(); rnaBreakpointIter++)
	{
		cerr << "RNA cluster " << rnaBreakpointIter->first << endl;
		
		CompactLocation startLocation;
		startLocation.refStrand.referenceIndex = references.Index(rnaBreakpointIter->second[0].refName);
		startLocation.refStrand.strand = rnaBreakpointIter->second[0].strand;
		startLocation.region.start = rnaBreakpointIter->second[0].start;
		startLocation.region.end = rnaBreakpointIter->second[0].end;
		
		CompactLocation endLocation;
		endLocation.refStrand.referenceIndex = references.Index(rnaBreakpointIter->second[1].refName);
		endLocation.refStrand.strand = rnaBreakpointIter->second[1].strand;
		endLocation.region.start = rnaBreakpointIter->second[1].start;
		endLocation.region.end = rnaBreakpointIter->second[1].end;
		
		IntegerVec startClusterIDs;
		dnaBinLookup.FindOverlapping(startLocation, startClusterIDs);
		
		vector<pair<double,unsigned int> > toVisit;
		IntegerSet visited;
		
		unordered_map<unsigned int,double> toScore;
		unordered_map<unsigned int,unsigned int> toNumEdges;
		unordered_map<unsigned int,unsigned int> fromIDs;
		
		for (IntegerVecConstIter startClusterIDIter = startClusterIDs.begin(); startClusterIDIter != startClusterIDs.end(); startClusterIDIter++)
		{
			ClusterEndID startClusterID;
			startClusterID.id = *startClusterIDIter;
			
			double intronicLength = CalculateIntronic(startLocation, dnaClusters[startClusterID.clusterID][startClusterID.clusterEnd]);
			double intronicScore = -intronicLength / intronLengthLambda;
			double clusterScore = log(dnaClusterProb[startClusterID.clusterID]);
			double edgeScore = intronicScore + clusterScore;
			
			ClusterEndID startClusterOtherEndID;
			startClusterOtherEndID.id = *startClusterIDIter;
			startClusterOtherEndID.clusterEnd = OtherClusterEnd(startClusterOtherEndID.clusterEnd);
			
			toNumEdges[startClusterOtherEndID.id] = 1;
			toScore[startClusterOtherEndID.id] = edgeScore;

			toVisit.push_back(make_pair(edgeScore, startClusterOtherEndID.id));
			push_heap(toVisit.begin(), toVisit.end());
		}
		
		bool foundCompletePath = false;
		unsigned int finalClusterID;
		double completePathScore;
		
		while (!toVisit.empty())
		{
			ClusterEndID nextClusterEndID;
			pop_heap(toVisit.begin(), toVisit.end());
			double nextClusterPathScore = toVisit.back().first;
			nextClusterEndID.id = toVisit.back().second;
			toVisit.pop_back();
			
			if (visited.find(nextClusterEndID.id) != visited.end())
			{
				continue;
			}
			
			if (foundCompletePath && completePathScore > nextClusterPathScore)
			{
				break;
			}
			
			if (Overlap(endLocation, dnaClusters[nextClusterEndID.clusterID][nextClusterEndID.clusterEnd]))
			{
				double intronicLength = CalculateIntronic(endLocation, dnaClusters[nextClusterEndID.clusterID][nextClusterEndID.clusterEnd]);
				double intronicScore = -intronicLength / intronLengthLambda;
				
				double pathScore = intronicScore + toScore[nextClusterEndID.id];
				
				if (!foundCompletePath || pathScore > completePathScore)
				{
					foundCompletePath = true;
					finalClusterID = nextClusterEndID.id;
					completePathScore = pathScore;
				}
			}
			
			CompactLocation location = dnaClusters[nextClusterEndID.clusterID][nextClusterEndID.clusterEnd];
			location.refStrand.strand = OtherStrand(location.refStrand.strand);
			location.region.start -= maxPartIntron;
			location.region.end += maxPartIntron;
			
			IntegerVec overlapClusterEndIDs;
			dnaBinLookup.FindOverlapping(location, overlapClusterEndIDs);
			
			for (IntegerVecConstIter idIter = overlapClusterEndIDs.begin(); idIter != overlapClusterEndIDs.end(); idIter++)
			{
				ClusterEndID overlapClusterEndID;
				overlapClusterEndID.id = *idIter;
				
				ClusterEndID otherClusterEndID = overlapClusterEndID;
				otherClusterEndID.clusterEnd = OtherClusterEnd(otherClusterEndID.clusterEnd);
				
				if (visited.find(otherClusterEndID.id) != visited.end())
				{
					continue;
				}
				
				if (otherClusterEndID.clusterID == nextClusterEndID.clusterID)
				{
					continue;
				}
				
				CompactLocation overlapLocation = dnaClusters[overlapClusterEndID.clusterID][overlapClusterEndID.clusterEnd];
				
				double intronicLength = CalculateMidpointDistance(location.region, overlapLocation.region);
				double intronicScore = -intronicLength / intronLengthLambda;
				double clusterScore = log(dnaClusterProb[overlapClusterEndID.clusterID]);
				double edgeScore = intronicScore + clusterScore;
				
				double pathScore = edgeScore + toScore[nextClusterEndID.id];
				
				if (pathScore >= minScore && (toScore.find(otherClusterEndID.id) == toScore.end() || pathScore > toScore[otherClusterEndID.id]))
				{
					fromIDs[otherClusterEndID.id] = nextClusterEndID.id;
					toNumEdges[otherClusterEndID.id] = toNumEdges[nextClusterEndID.id] + 1;
					toScore[otherClusterEndID.id] = pathScore;
					
					if (toNumEdges[nextClusterEndID.id] + 1 < maxPathEdges)
					{
						toVisit.push_back(make_pair(pathScore, otherClusterEndID.id));
						push_heap(toVisit.begin(), toVisit.end());
					}
				}
			}
			
			visited.insert(nextClusterEndID.id);
		}
		
		if (foundCompletePath)
		{
			cout << toScore[finalClusterID] << "\t";
			
			cout << rnaBreakpointIter->first << "\t";
			
			ClusterEndID traverseClusterID;
			traverseClusterID.id = finalClusterID;
			cout << traverseClusterID.clusterID << "\t";
			
			while (fromIDs.find(traverseClusterID.id) != fromIDs.end())
			{
				traverseClusterID.id = fromIDs[traverseClusterID.id];
				cout << traverseClusterID.clusterID << "\t";
			}
			
			cout << endl;
			
			cerr << "Found Path" << endl;
		}
		else
		{
			cerr << "No Path" << endl;
		}
	}
}


