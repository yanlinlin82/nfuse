/*
 *  rankclusters.cpp
 *
 *  Created by Andrew McPherson
 *
 */

#include "Common.h"
#include "DebugCheck.h"
#include "Sequences.h"
#include "SimpleAligner.h"
#include "Parsers.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/math/distributions/lognormal.hpp>

using namespace boost;
using namespace boost::math;
using namespace std;


void ReadClusterSizesAndMappings(const string& clustersFilename, IntegerMap& clusterSizeDist, IntegerMap& numMappings)
{
	ifstream clustersFile(clustersFilename.c_str());
	CheckFile(clustersFile, clustersFilename);
	
	ClusterReader clusterReader(clustersFile);
	
	int clusterID;
	LocationVec clusterLocations(2);
	IntegerVec fragmentIndices;
	while (clusterReader.Next(clusterID, clusterLocations, fragmentIndices))
	{
		clusterSizeDist.insert(make_pair(fragmentIndices.size(), 0));
		clusterSizeDist.find(fragmentIndices.size())->second++;

		for (IntegerVecConstIter fragIter = fragmentIndices.begin(); fragIter != fragmentIndices.end(); fragIter++)
		{
			numMappings.insert(make_pair(*fragIter, 0));
			numMappings.find(*fragIter)->second++;
		}
	}
}

void CalculateLogNormalParameters(const DoubleVec& samples, double& mean, double& variance)
{
	double lognSum = 0.0;
	double lognSumSq = 0.0;
	double numClusters = 0.0;
	
	for (DoubleVecConstIter sampleIter = samples.begin(); sampleIter != samples.end(); sampleIter++)
	{
		if (*sampleIter < 1.0)
		{
			continue;
		}
		
		double logn = log(*sampleIter);
		double lognSq = logn * logn;
		
		lognSum += logn;
		lognSumSq += lognSq;
		numClusters++;
	}
	
	mean = lognSum / numClusters;
	variance = lognSumSq / numClusters - mean * mean;	
}

void CalculateClusterSizeProbability(double mean1, double variance1, const IntegerMap& clusterSizeDist, DoubleMap& clusterSizeProb)
{
	double lognSum = 0.0;
	double lognSumSq = 0.0;
	double numClusters = 0.0;
	
	for (IntegerMapConstIter sizeIter = clusterSizeDist.begin(); sizeIter != clusterSizeDist.end(); sizeIter++)
	{
		double logn = log(sizeIter->first);
		double lognSq = logn * logn;
		
		lognSum += logn * sizeIter->second;
		lognSumSq += lognSq * sizeIter->second;
		numClusters += sizeIter->second;
	}
	
	double mean0 = lognSum / numClusters;
	double variance0 = lognSumSq / numClusters - mean0 * mean0;
	
	boost::math::lognormal_distribution<double> dist0(mean0, pow(variance0, 0.5));
	boost::math::lognormal_distribution<double> dist1(mean1, pow(variance1, 0.5));
	
	double pi = 0.0;
	double newPi = 0.5;
	while (abs(pi - newPi) > 0.000001)
	{
		pi = newPi;
		
		double respSum = 0.0;
		for (IntegerMapConstIter sizeIter = clusterSizeDist.begin(); sizeIter != clusterSizeDist.end(); sizeIter++)
		{
			double n = (double)sizeIter->first;
			
			double resp = pdf(dist1, n) * pi / (pdf(dist1, n) * pi + pdf(dist0, n) * (1.0 - pi));
			
			clusterSizeProb[sizeIter->first] = resp;
			
			respSum += resp * sizeIter->second;
		}
		
		newPi = respSum / numClusters;
	}
}


int main(int argc, char* argv[])
{
	string concordantSamplesFilename;
	string clustersFilename;
	string mateAlignProbFilename;
	
	try
	{
		TCLAP::CmdLine cmd("Cluster ranking tool");
		TCLAP::ValueArg<string> concordantSamplesFilenameArg("s","samples","Samples of Number of Concordant Spanning Reads",true,"","string",cmd);
		TCLAP::ValueArg<string> clustersFilenameArg("c","clusters","Clusters Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> mateAlignProbFilenameArg("a","alignprob","Fragment Mate Alignment Probability Filename",true,"","string",cmd);
		cmd.parse(argc,argv);
		
		concordantSamplesFilename = concordantSamplesFilenameArg.getValue();
		clustersFilename = clustersFilenameArg.getValue();
		mateAlignProbFilename = mateAlignProbFilenameArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	cerr << "Estimating true class log-normal distribution parameters" << endl;
	
	DoubleVec concordantSamples;
	ReadDoubleVec(concordantSamplesFilename, concordantSamples);
	
	double mean1;
	double variance1;
	CalculateLogNormalParameters(concordantSamples, mean1, variance1);
	
	cerr << "Reading cluster sizes and mappings" << endl;
	
	IntegerMap clusterSizeDist;
	IntegerMap numMappings;
	ReadClusterSizesAndMappings(clustersFilename, clusterSizeDist, numMappings);
	
	cerr << "Calculating true class probability for each cluster size" << endl;
	
	DoubleMap clusterSizeProbability;
	CalculateClusterSizeProbability(mean1, variance1, clusterSizeDist, clusterSizeProbability);
	
	cerr << "Reading mate alignment probabilities" << endl;
	
	DoubleMap mateAlignProbability;
	ReadDoubleMap(mateAlignProbFilename, mateAlignProbability);
	
	ifstream clustersFile(clustersFilename.c_str());
	CheckFile(clustersFile, clustersFilename);
	
	cerr << "Calculating cluster probability" << endl;
	
	ClusterReader clusterReader(clustersFile);
	int clusterID;
	LocationVec clusterLocations(2);
	IntegerVec fragmentIndices;
	while (clusterReader.Next(clusterID, clusterLocations, fragmentIndices))
	{
		DoubleVec fragmentProbability;
		for (IntegerVecConstIter fragIter = fragmentIndices.begin(); fragIter != fragmentIndices.end(); fragIter++)
		{
			fragmentProbability.push_back(mateAlignProbability[*fragIter] / (double)numMappings[*fragIter]);
		}

		DoubleVec previousRow;
		previousRow.push_back(1.0 - fragmentProbability[0]);
		previousRow.push_back(fragmentProbability[0]);
		
		for (int l = 1; l < fragmentIndices.size(); l++)
		{
			DoubleVec nextRow;
			
			double prob0 = previousRow[0] * (1 - fragmentProbability[l]);
			nextRow.push_back(prob0);
			
			for (int k = 1; k <= l; k++)
			{
				double prob = previousRow[k-1] * fragmentProbability[l] + previousRow[k] * (1 - fragmentProbability[l]);
				nextRow.push_back(prob);
			}
			
			double prob = previousRow[l] * fragmentProbability[l];
			nextRow.push_back(prob);
			
			swap(nextRow, previousRow);
		}
		
		DebugCheck(previousRow.size() == fragmentIndices.size() + 1);
		
		double clusterProb = 0.0;
		for (int n = 1; n <= fragmentIndices.size(); n++)
		{
			clusterProb += previousRow[n] * clusterSizeProbability[n];
		}
		
		cout << clusterID << "\t" << clusterProb << endl;
	}
}

