/*
 *  rankmatealign.cpp
 *
 *  Created by Andrew McPherson
 *
 */

#include "Common.h"
#include "DebugCheck.h"
#include "Parsers.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

using namespace boost;
using namespace std;


class Histogram
{
public:
	Histogram() : mStart(0.0), mEnd(1.0), mNumBins(10.0), mTotalCounts(0.0)
	{
		InitializeBins();
	}
	
	Histogram(double start, double end, int numBins) : mStart(start), mEnd(end), mNumBins(numBins), mTotalCounts(0.0)
	{
		InitializeBins();
	}
	
	void AddValues(const DoubleVec& values)
	{
		for (DoubleVecConstIter valueIter = values.begin(); valueIter != values.end(); valueIter++)
		{
			mCounts[CalculateBin(*valueIter)]++;
			mTotalCounts++;
		}
	}
	
	double Probability(double value)
	{
		return mCounts[CalculateBin(value)] / mTotalCounts;
	}
	
private:
	void InitializeBins()
	{
		for (int bin = 0; bin < mNumBins; bin++)
		{
			mCounts[bin] = 0.0;
		}
	}
	
	int CalculateBin(double value)
	{
		double normalized = (value - mStart) / (mEnd - mStart);
		int bin = max(0, max((int)floor(normalized * mNumBins), (int)mCounts.size() - 1));
		return bin;
	}
	
	double mStart;
	double mEnd;
	double mNumBins;
	unordered_map<int,double> mCounts;
	double mTotalCounts;
};

double Sum(const DoubleVec& values)
{
	double sum = 0.0;
	for (DoubleVecConstIter valueIter = values.begin(); valueIter != values.end(); valueIter++)
	{
		sum += *valueIter;
	}
	return sum;
}

int main(int argc, char* argv[])
{
	string nullSampleFilenames;
	string mateAlignFilename;
	double hardThreshold;
	
	try
	{
		TCLAP::CmdLine cmd("Mate alignment ranking tool");
		TCLAP::ValueArg<string> nullSampleFilenamesArg("n","nullsample","List of Null Distribution Sample Filenames readlength1:filename1,readlength2,filename2,...",true,"","string",cmd);
		TCLAP::ValueArg<string> mateAlignFilenameArg("m","matealign","Mate Alignment Filename",true,"","string",cmd);
		TCLAP::ValueArg<double> hardThresholdArg("t","threshold","Hard Threshold on Mate Alignment",false,0.95,"float",cmd);
		cmd.parse(argc,argv);
		
		nullSampleFilenames = nullSampleFilenamesArg.getValue();
		mateAlignFilename = mateAlignFilenameArg.getValue();
		hardThreshold = hardThresholdArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	cerr << "Creating histograms" << endl;
	
	double minMateAlign = 0.0;
	double maxMateAlign = 1.0;
	int numNullHistBins = 50;
	unordered_map<int,Histogram> nullHistograms;
	
	vector<string> sampleList;
	split(sampleList, nullSampleFilenames, is_any_of(","));
	for (vector<string>::const_iterator sampleIter = sampleList.begin(); sampleIter != sampleList.end(); sampleIter++)
	{
		vector<string> sampleFields;
		split(sampleFields, *sampleIter, is_any_of(":"));
		
		if (sampleFields.size() != 2)
		{
			cerr << "Error: Unable to interpret null sample filenames argument" << endl;
			exit(1);
		}
		
		int readLength = lexical_cast<int>(sampleFields[0]);
		const string& samplesFilename = sampleFields[1];
		
		cerr << "Creating histogram for read length " << readLength << endl;
		
		DoubleVec samples;
		ReadDoubleVec(samplesFilename, samples);
		
		nullHistograms[readLength] = Histogram(minMateAlign, maxMateAlign, numNullHistBins);
		nullHistograms[readLength].AddValues(samples);
	}
	
	cerr << "Reading mate align scores" << endl;
	
	IntegerVec fragmentIndices;
	DoubleVec mateAlignScores;
	IntegerVec readLengths;
	IntegerSet allReadLengths;
	ReadMateAlign(mateAlignFilename, fragmentIndices, mateAlignScores, readLengths, allReadLengths);
	
	for (IntegerSetConstIter readLengthIter = allReadLengths.begin(); readLengthIter != allReadLengths.end(); readLengthIter++)
	{
		if (nullHistograms.find(*readLengthIter) == nullHistograms.end())
		{
			cerr << "Error: no null distribution for read length of " << *readLengthIter << endl;
			exit(1);
		}
	}
	
	cerr << "Filtering based on hard threshold" << endl;
	
	IntegerVec fragmentIndicesFiltered;
	DoubleVec mateAlignScoresFiltered;
	IntegerVec readLengthsFiltered;
	for (int mateAlignIndex = 0; mateAlignIndex < mateAlignScores.size(); mateAlignIndex++)
	{
		if (mateAlignScores[mateAlignIndex] >= hardThreshold)
		{
			cout << fragmentIndices[mateAlignIndex] << "\t" << "0" << endl;
		}
		else
		{
			fragmentIndicesFiltered.push_back(fragmentIndices[mateAlignIndex]);
			mateAlignScoresFiltered.push_back(mateAlignScores[mateAlignIndex]);
			readLengthsFiltered.push_back(readLengths[mateAlignIndex]);
		}
	}
	swap(fragmentIndices, fragmentIndicesFiltered);
	swap(mateAlignScores, mateAlignScoresFiltered);
	swap(readLengths, readLengthsFiltered);
	
	cerr << "Initializing EM" << endl;
	
	DoubleVec nullProb;
	DoubleVec responsibility;
	for (int mateAlignIndex = 0; mateAlignIndex < mateAlignScores.size(); mateAlignIndex++)
	{
		nullProb.push_back(nullHistograms[readLengths[mateAlignIndex]].Probability(mateAlignScores[mateAlignIndex]));
		responsibility.push_back(mateAlignScores[mateAlignIndex] < 0.8 ? 1.0 : 0.0);
	}
	
	for (int iteration = 1; iteration <= 10; iteration++)
	{
		cerr << "EM Iteration " << iteration << endl;
		
		double sumResp = Sum(responsibility);
		double numValues = (double)responsibility.size();
		
		double pi = sumResp / numValues;
		
		double lambdaNumer = (numValues - sumResp);
		double lambdaDenom = 0.0;
		for (int mateAlignIndex = 0; mateAlignIndex < mateAlignScores.size(); mateAlignIndex++)
		{
			lambdaDenom += (1 - responsibility[mateAlignIndex]) * (hardThreshold - mateAlignScores[mateAlignIndex]);
		}
		
		double lambda = lambdaNumer / lambdaDenom;
		
		for (int mateAlignIndex = 0; mateAlignIndex < mateAlignScores.size(); mateAlignIndex++)
		{
			responsibility[mateAlignIndex] = nullProb[mateAlignIndex] * pi / (nullProb[mateAlignIndex] * pi + lambda * exp(-lambda * (hardThreshold - mateAlignScores[mateAlignIndex])) * (1 - pi));
		}
	}
	
	for (int mateAlignIndex = 0; mateAlignIndex < mateAlignScores.size(); mateAlignIndex++)
	{
		cout << fragmentIndices[mateAlignIndex] << "\t" << responsibility[mateAlignIndex] << endl;
	}
}

