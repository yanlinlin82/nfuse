args = commandArgs(TRUE)

#args = c("dna.align.scores.short","true.samples.short","test")

all_alignment_scores = read.table(args[1],col.names=c("aligned_length","scores"))
all_true_scores = read.table(args[2],col.names=c("aligned_length","scores"))

cl_aligned_lengths = c()
cl_scores = c()
cl_prob = c()

for (aligned_length in unique(all_alignment_scores$aligned_length)) {
	print(aligned_length)
	
	align_scores = all_alignment_scores$scores[all_alignment_scores$aligned_length == aligned_length]
	true_scores = all_true_scores$scores[all_true_scores$aligned_length == aligned_length]
	
	true_scores = sample(true_scores,length(align_scores),replace=T)
	
	alls = c(align_scores,true_scores)
	allv = c(rep(0,length(align_scores)),rep(1,length(true_scores)))

	logr = glm(allv ~ alls, family=binomial("logit"))

	cval = sum(predict(logr,newdata=data.frame(alls=true_scores),type="response"))/length(true_scores)
	
	unique_align_scores = unique(align_scores)

	clamp01 = function(x) return(max(0,min(1,x)))
	prob = sapply(predict(logr,newdata=data.frame(alls=unique_align_scores),type="response") / cval, clamp01)
	
	cl_aligned_lengths = c(cl_aligned_lengths, rep(aligned_length,length(unique_align_scores)))
	cl_scores = c(cl_scores, unique_align_scores)
	cl_prob = c(cl_prob, prob)
}

sizeprob = data.frame(aligned_length=cl_aligned_lengths,score=cl_scores,probability=cl_prob)

write.table(sizeprob, file=args[3], quote=F, sep="\t", eol="\n", row.names=F, col.names=F)

