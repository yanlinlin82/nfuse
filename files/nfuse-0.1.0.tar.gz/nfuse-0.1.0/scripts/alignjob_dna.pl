#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use lib dirname($0);
use configdata;
use cmdrunner;

my $main_pid = $$;

my @usage;
push @usage, "Usage: ".basename($0)." [options]\n";
push @usage, "Run the alignment pipeline for fusions.\n";
push @usage, "  -h, --help      Displays this information\n";
push @usage, "  -c, --config    Configuration Filename\n";
push @usage, "  -l, --local     Job Local Directory\n";
push @usage, "  -o, --output    Output Directory\n";
push @usage, "  -n, --name      Library Name\n";
push @usage, "  -j, --job       Job Name\n";
push @usage, "  -p, --prefix    Prefix of Job Input/Output\n";

my $help;
my $config_filename;
my $local_directory;
my $output_directory;
my $library_name;
my $job_name;
my $job_prefix;

GetOptions
(
	'help'        => \$help,
	'config=s'    => \$config_filename,
	'local=s'     => \$local_directory,
	'output=s'    => \$output_directory,
	'name=s'      => \$library_name,
	'job=s'       => \$job_name,
	'prefix=s'    => \$job_prefix,
);

not defined $help or die @usage;

defined $config_filename or die @usage;
defined $local_directory or die @usage;
defined $output_directory or die @usage;
defined $library_name or die @usage;
defined $job_name or die @usage;
defined $job_prefix or die @usage;

print "Starting alignjob $job_name\n";

my $config = configdata->new();
$config->read($config_filename);

# Config values
my $gene_models              = $config->get_value("gene_models");
my $genome_fasta             = $config->get_value("genome_fasta");
my $satellite_regions        = $config->get_value("satellite_regions");
my $scripts_directory        = $config->get_value("scripts_directory");
my $tools_directory          = $config->get_value("tools_directory");
my $bowtie2_bin              = $config->get_value("bowtie2_bin");
my $bowtie2_options          = $config->get_value("bowtie2_options");
my $samtools_bin             = $config->get_value("samtools_bin");
my $discord_read_trim        = $config->get_value("dna_discord_read_trim");
my $max_alignments           = $config->get_value("dna_max_alignments");
my $max_fragment_length      = $config->get_value("dna_max_fragment_length");
my $concordant_length        = $config->get_value("dna_concordant_length");
my $max_align_score_diff     = $config->get_value("dna_max_align_score_diff");
my $matealign_search_length  = $config->get_value("matealign_search_length");
my $matealign_match          = $config->get_value("matealign_match");
my $matealign_mismatch       = $config->get_value("matealign_mismatch");
my $matealign_gap            = $config->get_value("matealign_gap");
my $remove_job_temp_files    = $config->get_value("remove_job_temp_files");
my $mt_chromosome            = $config->get_value("mt_chromosome");
my $spandist_num_samples     = $config->get_value("spandist_num_samples");
my $python_bin               = $config->get_value("python_bin");

my $read_stats_script = "$scripts_directory/read_stats.pl";
my $filter_sam_readids_script = "$scripts_directory/filter_sam_readids.pl";
my $filter_sam_end_script = "$scripts_directory/filter_sam_end.pl";
my $filter_sam_concordant_script = "$scripts_directory/filter_sam_concordant.pl";
my $filter_sam_mapped_script = "$scripts_directory/filter_sam_mapped.pl";
my $filter_sam_mismatches_script = "$scripts_directory/filter_sam_mismatches.pl";
my $filter_regions_script = "$scripts_directory/filter_regions.pl";
my $filter_sam_multimapped_script = "$scripts_directory/filter_sam_multimapped.pl";
my $sam_readids_command = "$scripts_directory/sam_readids.pl";
my $find_concordant_readids_script = "$scripts_directory/find_concordant_readids.pl";
my $filter_sam_genes_script = "$scripts_directory/filter_sam_genes.pl";
my $sam_readids_script = "$scripts_directory/sam_readids.pl";
my $filter_fastq_script = "$scripts_directory/filter_fastq.pl";
my $trim_fastq_script = "$scripts_directory/trim_fastq.pl";
my $intersect_script = "$scripts_directory/intersect.pl";
my $disjoint_script = "$scripts_directory/disjoint.pl";
my $matealign_bin = "$tools_directory/matealign";
my $realign_bin = "$tools_directory/realign";
my $calcspandist_bin = "$tools_directory/calcspandist";
my $create_discordant_fastq_script = "$scripts_directory/create_discordant_fastq.py";
my $divide_chr_pairs_script = "$scripts_directory/divide_chr_pairs.pl";
my $calc_sam_local_script = "$scripts_directory/calc_sam_local.pl";
my $filter_suboptimal_alignments_script = "$scripts_directory/filter_suboptimal_alignments.pl";
my $filterreads_bin = "$tools_directory/filterreads";
my $filter_unmatched_script = "$scripts_directory/filter_unmatched.pl";
my $sample_fastq_script = "$scripts_directory/sample_fastq.pl";

my $local_prefix = $local_directory."/".$library_name.".".$job_name;

# List of local files to remove on control-c
my @local_filenames;

# Cleanup method to remove files
sub cleanup
{
	return if scalar @local_filenames == 0;
	print "Cleaning Up\n";
	if (lc($remove_job_temp_files) eq "yes")
	{
		unlink @local_filenames;
	}
}

# Cleanup when dieing
# Ensure we are passing the correct return code
# Ensure this END block gets called from the main thread/process only
END
{
	my $retcode = $?;
	if ($$ == $main_pid)
	{
		cleanup();
	}
	$? = $retcode;
}

# SIGINT handler
sub inthandler
{
	die "Interrupted\n";
}

$SIG{'INT'} = 'inthandler';

sub get_local_filename
{
	my $suffix = shift;
	my $local_filename = $local_prefix.".".$suffix;
	push @local_filenames, $local_filename;
	return $local_filename;
}

my $log_directory = $output_directory."/log";
my $log_prefix = $log_directory."/".$job_name;

mkdir $log_directory if not -e $log_directory;

my $runner = cmdrunner->new();
$runner->name("alignjob.$job_name");
$runner->prefix($log_prefix);
$runner->submitter("direct");

my $reads_end_1_fastq = $job_prefix.".1.fastq";
my $reads_end_2_fastq = $job_prefix.".2.fastq";

-e $reads_end_1_fastq or die "Error: Unable to find fastq file $reads_end_1_fastq\n";
-e $reads_end_2_fastq or die "Error: Unable to find fastq file $reads_end_2_fastq\n";

# Products of the alignment process
my $spanning_alignments = $job_prefix.".spanning.alignments";
my $spanning_filelist = $job_prefix.".spanning.filelist";
my $spanning_matealign = $job_prefix.".spanning.matealign";
my $concordant_stats = $job_prefix.".concordant.stats";
my $concordant_depthsamples = $job_prefix.".concordant.depthsamples";

my $max_bowtie2_alignments = $max_alignments + 1;

print "Finding concordant alignments to the reference\n";
my $concordant_sam = get_local_filename("concordant.sam");
$runner->run("$bowtie2_bin --no-mixed --no-discordant -X $max_fragment_length $bowtie2_options -x $genome_fasta -1 #<1 -2 #<2 -S #>1", [$reads_end_1_fastq, $reads_end_2_fastq], [$concordant_sam]);

print "Read Stats from concordant alignments\n";
$runner->run("$read_stats_script < #<1 > #>1", [$concordant_sam], [$concordant_stats]);

print "Sampling spanning read distribution from concordant alignments\n";
$runner->run("$calcspandist_bin -f $genome_fasta.fai -i $mt_chromosome -t $discord_read_trim -n $spandist_num_samples -a #<1 > #>1", [$concordant_sam], [$concordant_depthsamples]);

print "Filtering concordant reads\n";
my $filter_reads_fastq = get_local_filename("filter.fastq");
$runner->run("$python_bin $create_discordant_fastq_script #<1 #<2 #<3 > #>1", [$concordant_sam, $reads_end_1_fastq, $reads_end_2_fastq], [$filter_reads_fastq]);

print "Finding alignments to the reference\n";
$runner->run("$bowtie2_bin --sam-nohead --very-sensitive-local -k $max_bowtie2_alignments $bowtie2_options -x $genome_fasta -U #<1 | $filter_suboptimal_alignments_script $max_alignments $max_align_score_diff | $calc_sam_local_script | $filterreads_bin -n 2 -a - -r $satellite_regions | $filter_unmatched_script > #>1", [$filter_reads_fastq], [$spanning_alignments]);

print "Finding mate alignments to the reference\n";
$runner->run("$matealign_bin -s #<1 -r $genome_fasta -a #<2 -l $matealign_search_length -m $matealign_match -x $matealign_mismatch -g $matealign_gap > #>1", [$filter_reads_fastq,$spanning_alignments], [$spanning_matealign]);

print "Dividing sam output files\n";
my $spanning_align_prefix = $job_prefix.".spanning/";
mkdir $spanning_align_prefix if not -d $spanning_align_prefix;
$runner->run("$divide_chr_pairs_script -p $spanning_align_prefix -m $mt_chromosome < #<1 > #>1", [$spanning_alignments], [$spanning_filelist]);

print "Finished Alignments\n";

