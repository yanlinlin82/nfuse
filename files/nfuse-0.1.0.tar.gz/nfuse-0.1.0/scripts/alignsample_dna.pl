#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use lib dirname($0);
use configdata;
use cmdrunner;

my $main_pid = $$;

my @usage;
push @usage, "Usage: ".basename($0)." [options]\n";
push @usage, "Run the alignment pipeline for fusions.\n";
push @usage, "  -h, --help      Displays this information\n";
push @usage, "  -c, --config    Configuration Filename\n";
push @usage, "  -l, --local     Job Local Directory\n";
push @usage, "  -o, --output    Output Directory\n";
push @usage, "  -n, --name      Library Name\n";
push @usage, "  -j, --job       Job Name\n";
push @usage, "  -p, --prefix    Prefix of Job Input/Output\n";

my $help;
my $config_filename;
my $local_directory;
my $output_directory;
my $library_name;
my $job_name;
my $job_prefix;

GetOptions
(
	'help'        => \$help,
	'config=s'    => \$config_filename,
	'local=s'     => \$local_directory,
	'output=s'    => \$output_directory,
	'name=s'      => \$library_name,
	'job=s'       => \$job_name,
	'prefix=s'    => \$job_prefix,
);

not defined $help or die @usage;

defined $config_filename or die @usage;
defined $local_directory or die @usage;
defined $output_directory or die @usage;
defined $library_name or die @usage;
defined $job_name or die @usage;
defined $job_prefix or die @usage;

print "Starting alignjob $job_name\n";

my $config = configdata->new();
$config->read($config_filename);

# Config values
my $genome_fasta             = $config->get_value("genome_fasta");
my $scripts_directory        = $config->get_value("scripts_directory");
my $tools_directory          = $config->get_value("tools_directory");
my $bowtie2_bin              = $config->get_value("bowtie2_bin");
my $bowtie2_options          = $config->get_value("bowtie2_options");
my $max_fragment_length      = $config->get_value("dna_max_fragment_length");
my $matealign_search_length  = $config->get_value("matealign_search_length");
my $remove_job_temp_files    = $config->get_value("remove_job_temp_files");

my $matealigntrue_bin = "$tools_directory/matealigntrue";
my $matealignnull_bin = "$tools_directory/matealignnull";

my $local_prefix = $local_directory."/".$library_name.".".$job_name;

# List of local files to remove on control-c
my @local_filenames;

# Cleanup method to remove files
sub cleanup
{
	return if scalar @local_filenames == 0;
	print "Cleaning Up\n";
	if (lc($remove_job_temp_files) eq "yes")
	{
		unlink @local_filenames;
	}
}

# Cleanup when dieing
# Ensure we are passing the correct return code
# Ensure this END block gets called from the main thread/process only
END
{
	my $retcode = $?;
	if ($$ == $main_pid)
	{
		cleanup();
	}
	$? = $retcode;
}

# SIGINT handler
sub inthandler
{
	die "Interrupted\n";
}

$SIG{'INT'} = 'inthandler';

sub get_local_filename
{
	my $suffix = shift;
	my $local_filename = $local_prefix.".".$suffix;
	push @local_filenames, $local_filename;
	return $local_filename;
}

my $log_directory = $output_directory."/log";
my $log_prefix = $log_directory."/".$job_name;

mkdir $log_directory if not -e $log_directory;

my $runner = cmdrunner->new();
$runner->name("alignjob.$job_name");
$runner->prefix($log_prefix);
$runner->submitter("direct");

my $reads_end_1_fastq = $job_prefix.".1.fastq";
my $reads_end_2_fastq = $job_prefix.".2.fastq";

-e $reads_end_1_fastq or die "Error: Unable to find fastq file $reads_end_1_fastq\n";
-e $reads_end_2_fastq or die "Error: Unable to find fastq file $reads_end_2_fastq\n";

# Products of the alignment process
my $true_align_samples = $job_prefix.".true.align.samples";
my $null_align_samples = $job_prefix.".null.align.samples";

print "Sampling true alignment scores\n";
$runner->run("$bowtie2_bin --no-mixed --no-discordant -X $max_fragment_length $bowtie2_options -x $genome_fasta -1 #<1 -2 #<2 | $matealigntrue_bin -r $genome_fasta -a - > #>1", [$reads_end_1_fastq, $reads_end_2_fastq], [$true_align_samples]);

print "Sampling null alignment scores\n";
$runner->run("cat #<1 #<2 | $matealignnull_bin -r $genome_fasta -l $matealign_search_length > #>1", [$reads_end_1_fastq, $reads_end_2_fastq], [$null_align_samples]);

print "Finished Alignments\n";

