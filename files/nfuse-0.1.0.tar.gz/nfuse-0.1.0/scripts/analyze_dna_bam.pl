#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use Cwd qw[abs_path];
use File::Spec;

use lib dirname($0);
use configdata;
use cmdrunner;

my @usage;
push @usage, "Usage: ".basename($0)." [options]\n";
push @usage, "Run the analysis pipeline for fusions.\n";
push @usage, "  -h, --help      Displays this information\n";
push @usage, "  -c, --config    Configuration Filename\n";
push @usage, "  -d, --dna       DNA bam filename\n";
push @usage, "  -o, --output    Output Directory\n";
push @usage, "  -n, --name      Library Name\n";
push @usage, "  -l, --local     Job Local Directory (default: Output Directory)\n";
push @usage, "  -s, --submit    Submitter Type (default: direct)\n";
push @usage, "  -p, --parallel  Maximum Number of Parallel Jobs (default: 1)\n";

my $help;
my $config_filename;
my $dna_bam_filename;
my $output_directory;
my $library_name;
my $joblocal_directory;
my $submitter_type;
my $max_parallel;

GetOptions
(
	'help'        => \$help,
	'config=s'    => \$config_filename,
	'dna=s'       => \$dna_bam_filename,
	'output=s'    => \$output_directory,
	'name=s'      => \$library_name,
	'local=s'     => \$joblocal_directory,
	'submit=s'    => \$submitter_type,
	'parallel=s'  => \$max_parallel,
);

not defined $help or die "@usage";

defined $config_filename or die @usage;
defined $output_directory or die @usage;

mkdir $output_directory if not -d $output_directory;

-d $output_directory or die "Error: unable to make output directory $output_directory\n";
-e $config_filename or die "Error: unable to find config file $config_filename\n";

$output_directory = abs_path($output_directory);
$config_filename = abs_path($config_filename);

# Guess library name
if (not defined $library_name)
{
	$library_name = "";
	my @output_splitdir = File::Spec->splitdir($output_directory);
	while ($library_name eq "" and scalar @output_splitdir > 0)
	{
		$library_name = pop(@output_splitdir);
	}
	defined $library_name or die "Error: Unable to infer library name from output director $output_directory\n";
}

# Job local directory defaults to temp subdirectory of output directory
if (not defined $joblocal_directory)
{
	$joblocal_directory = $output_directory."/tmp";
	mkdir $joblocal_directory if not -d $joblocal_directory;
}

# Submitter type defaults to direct
if (not defined $submitter_type)
{
	$submitter_type = "direct";
}

# Max parallel defaults to 1 for direct submitter
if (not defined $max_parallel)
{
	if ($submitter_type eq "direct")
	{
		$max_parallel = 1;
	}
	else
	{
		$max_parallel = 200;
	}
}

my $config = configdata->new();
$config->read($config_filename);

# Config values
my $gene_models              = $config->get_value("gene_models");
my $genome_fasta             = $config->get_value("genome_fasta");
my $chromosome_prefix        = $config->get_value("chromosome_prefix");
my $scripts_directory        = $config->get_value("scripts_directory");
my $tools_directory          = $config->get_value("tools_directory");
my $samtools_bin             = $config->get_value("samtools_bin");
my $reads_per_job            = $config->get_value("reads_per_job");
my $rna_min_spanning_reads   = $config->get_value("rna_min_spanning_reads");
my $dna_min_spanning_reads   = $config->get_value("dna_min_spanning_reads");
my $rna_reference_fasta      = $config->get_value("rna_reference_fasta");
my $dna_reference_fasta      = $config->get_value("dna_reference_fasta");
my $rna_reference_regions    = $config->get_value("rna_reference_regions");
my $max_intron_length        = $config->get_value("max_intron_length");
my %chromosomes              = $config->get_hash("chromosomes");
my $mt_chromosome            = $config->get_value("mt_chromosome");
my $dna_concordant_length    = $config->get_value("dna_concordant_length");
my $rna_concordant_length    = $config->get_value("rna_concordant_length");
my $dna_max_fragment_length  = $config->get_value("dna_max_fragment_length");
my $matealign_search_length  = $config->get_value("matealign_search_length");
my $null_connect_samples     = $config->get_value("null_connect_samples");
my $breakpoints_per_job      = $config->get_value("breakpoints_per_job");
my $cdna_fasta               = $config->get_value("cdna_fasta");
my $cdna_chromosomes         = $config->get_value("cdna_chromosomes");
my $exons_fasta              = $config->get_value("exons_fasta");
my $cds_fasta                = $config->get_value("cds_fasta");
my $est_fasta                = $config->get_value("est_fasta");
my @est_split_fastas         = $config->get_list("est_split_fasta");
my $repeats_regions          = $config->get_value("repeats_regions");
my $blat_bin                 = $config->get_value("blat_bin");
my $rscript_bin              = $config->get_value("rscript_bin");
my $python_bin               = $config->get_value("python_bin");
my $rna_discord_read_trim    = $config->get_value("rna_discord_read_trim");
my $remove_job_files         = $config->get_value("remove_job_files");
my $cluster_prob_threshold   = $config->get_value("cluster_prob_threshold");
my $discord_read_trim        = $config->get_value("dna_discord_read_trim");
my $spandist_num_samples     = $config->get_value("spandist_num_samples");
my $cycles_lambda            = $config->get_value("cycles_lambda");
my $cycles_visitmax          = $config->get_value("cycles_visitmax");
my $paths_lambdafwd          = $config->get_value("paths_lambdafwd");
my $paths_lambdarev          = $config->get_value("paths_lambdarev");
my $paths_visitmax           = $config->get_value("paths_visitmax");
my $remap_end_adjust         = $config->get_value("remap_end_adjust");
my $gmap_bin                 = $config->get_value("gmap_bin");
my $gmap_index_directory     = $config->get_value("gmap_index_directory");
my $bowtie2_bin              = $config->get_value("bowtie2_bin");
my $bowtie2_options          = $config->get_value("bowtie2_options");

sub verify_file_exists
{
	my $filename = shift;
	
	if (not -e $filename)
	{
		die "Error: Required file $filename does not exist\n";
	}
}

sub verify_directory_exists
{
	my $filename = shift;
	
	if (not -e $filename)
	{
		die "Error: Required directory $filename does not exist\n";
	}
}

# Ensure required directories and files exist
verify_directory_exists($scripts_directory);
verify_directory_exists($output_directory);

# Script and binary paths
my $retrieve_sam_fastq_script = "$scripts_directory/retrieve_sam_fastq.pl";
my $alignjob_rna_script = "$scripts_directory/alignjob_rna.pl";
my $alignjob_dna_script = "$scripts_directory/alignjob_dna.pl";
my $samtools_merge_script = "$scripts_directory/samtools_merge.pl";
my $read_stats_script = "$scripts_directory/read_stats.pl";
my $merge_read_stats_script = "$scripts_directory/merge_read_stats.pl";
my $merge_cov_samples_script = "$scripts_directory/merge_cov_samples.pl";
my $merge_clusters_script = "$scripts_directory/merge_clusters.pl";
my $unify_clusters_script = "$scripts_directory/unify_clusters.pl";
my $clustermatepairs_bin = "$tools_directory/clustermatepairs";
my $segregate_mitochondrial_script = "$scripts_directory/segregate_mitochondrial.pl";
my $overlap_clusters_bin = "$tools_directory/overlapclusters";
my $identify_readthroughs_script = "$scripts_directory/identify_readthroughs.pl";
my $create_support_script = "$scripts_directory/create_support.pl";
my $presetcover_bin = "$tools_directory/presetcover";
my $setcover_bin = "$tools_directory/setcover";
my $connectivity_bin = "$tools_directory/connectivity";
my $decisionmetrics_bin = "$tools_directory/decisionmetrics";
my $initsplitalign_bin = "$tools_directory/initsplitalign";
my $split_candidate_reads_script = "$scripts_directory/split_candidate_reads.pl";
my $dosplitalign_bin = "$tools_directory/dosplitalign";
my $evalsplitalign_bin = "$tools_directory/evalsplitalign";
my $calc_span_stats_script = "$scripts_directory/calc_span_stats.pl";
my $coallate_script = "$scripts_directory/coallate.pl";
my $get_fusion_sequences_script = "$scripts_directory/get_fusion_sequences.pl";
my $get_fusion_sequence_script = "$scripts_directory/get_fusion_sequence.py";
my $annotate_dna_script = "$scripts_directory/annotate_fusions_dna.pl";
my $annotate_rna_script = "$scripts_directory/annotate_fusions_rna.pl";
my $calc_break_regions_script = "$scripts_directory/calc_break_regions.pl";
my $calc_align_regions_script = "$scripts_directory/calc_align_regions.pl";
my $remap_regions_to_genome_script = "$scripts_directory/remap_regions_to_genome.pl";
my $filter_column_script = "$scripts_directory/filter_column.pl";
my $filter_corroboration_script = "$scripts_directory/filter_corroboration.pl";
my $select_breakpoint_clusters_script = "$scripts_directory/select_breakpoint_clusters.pl";
my $filter_repeat_clusters_script = "$scripts_directory/filter_repeat_clusters.pl";
my $filter_readthrough_clusters_script = "$scripts_directory/filter_readthrough_clusters.pl";
my $filter_sam_concordant_script = "$scripts_directory/filter_sam_concordant.pl";
my $filter_sam_unmatched_script = "$scripts_directory/filter_sam_unmatched.pl";
my $localalign_bin = "$tools_directory/localalign";
my $remove_duplicates_script = "$scripts_directory/remove_duplicates.pl";
my $create_read_fasta_script = "$scripts_directory/create_read_fasta.pl";
my $make_fasta_script = "$scripts_directory/make_fasta.pl";
my $split_fasta_script = "$scripts_directory/split_fasta.pl";
my $split_fastq_script = "$scripts_directory/split_fastq.pl";
my $sample_fastq_script = "$scripts_directory/sample_fastq.pl";
my $get_align_regions_script = "$scripts_directory/get_align_regions.pl";
my $merge_depthsamples_script = "$scripts_directory/merge_depthsamples.py";
my $evaluate_fraglength_rscript = "$rscript_bin $scripts_directory/evaluate_fraglength_mean.R";
my $evaluate_split_rscript = "$rscript_bin $scripts_directory/evaluate_split.R";
my $fit_negative_binomial_rscript = "$rscript_bin $scripts_directory/fit_negative_binomial.R";
my $calccov_bin = "$tools_directory/calccov";
my $rankalign_bin = "$tools_directory/rankalign";
my $rankmatealign_bin = "$tools_directory/rankmatealign";
my $rankclusters_bin = "$tools_directory/rankclusters";
my $filter_clusters_script = "$scripts_directory/filter_clusters.pl";
my $count_cluster_reads_script = "$scripts_directory/count_cluster_reads.pl";
my $prep_local_alignment_seqs_script = "$scripts_directory/prep_local_alignment_seqs.pl";
my $get_path_breakpoints_script = "$scripts_directory/get_path_breakpoints.pl";
my $create_corroboration_script = "$scripts_directory/create_corroboration.pl";
my $cycles_bin = "$tools_directory/cycles";
my $paths_bin = "$tools_directory/paths";
my $matealigntrue_bin = "$tools_directory/matealigntrue";
my $matealignnull_bin = "$tools_directory/matealignnull";
my $filter_sam_mapped_script = "$scripts_directory/filter_sam_mapped.pl";
my $extract_alignment_scores_script = "$scripts_directory/extract_alignment_scores.pl";
my $align_prob_rscript = "$rscript_bin $scripts_directory/align_prob.R";
my $calc_fragment_align_prob_script = "$scripts_directory/calc_fragment_align_prob.pl";
my $calc_cluster_connect_prob_script = "$scripts_directory/calc_cluster_connect_prob.pl";
my $cluster_size_prob_rscript = "$rscript_bin $scripts_directory/cluster_size_prob.R";
my $clusterconnectivity_bin = "$tools_directory/clusterconnectivity";
my $connect_prob_rscript = "$rscript_bin $scripts_directory/connect_prob.R";
my $calcspandist_bin = "$tools_directory/calcspandist";


if (defined $dna_bam_filename)
{
	-e $dna_bam_filename or die "Error: Unable to find source bam $dna_bam_filename\n";
	$dna_bam_filename = abs_path($dna_bam_filename);
}

$output_directory = abs_path($output_directory);

my $jobs_directory = abs_path($output_directory."/jobs");

mkdir $jobs_directory if not -e $jobs_directory;

my $log_directory = $output_directory."/log";
my $log_prefix = $log_directory."/analysis";

mkdir $log_directory if not -e $log_directory;

my $runner = cmdrunner->new();
$runner->name("analyze");
$runner->prefix($log_prefix);
$runner->maxparallel($max_parallel);
$runner->submitter($submitter_type);
$runner->jobmem(8000000000);

my %dna_info;

$dna_info{prefix} = $output_directory."/dna";
$dna_info{data_type} = "dna";

print "Sorting bam file by read\n";
$dna_info{read_sorted_bam} = $dna_info{prefix}.".read.sorted.bam";
$runner->padd("$samtools_bin sort -n -o #<1 #>1.sort > #>1", [$dna_bam_filename], [$dna_info{read_sorted_bam}]);

my @dna_jobs;

print "Retrieving reads\n";
retrieve_fastq_padd(\%dna_info);
$runner->prun();

print "Splitting fastq files\n";
split_fastq_padd(\%dna_info);
$runner->prun();
split_fastq_finish(\%dna_info, \@dna_jobs);

wgss_stats_padd(\%dna_info);
wgss_align_padd(\%dna_info, \@dna_jobs);
wgss_sample_align_padd(\%dna_info);
$runner->prun();

wgss_merge_cluster(\%dna_info, \@dna_jobs);

sub readsplitcatalog
{
	my $split_catalog = shift;
	my @split_prefixes;

	open SC, $split_catalog or die "Error: Unable to open $split_catalog: $!\n";
	while (<SC>)
	{
		chomp;
		my @fields = split /\t/;

		push @split_prefixes, $fields[0];
	}
	close SC;

	return @split_prefixes;
}

sub get_stats
{
	my $stats_filename = shift;
	my $stats_outref = shift;
	
	open STATS, $stats_filename or die "Error: Unable to open $stats_filename\n";
	my @stats = <STATS>;
	chomp(@stats);
	close STATS;

	scalar @stats == 2 or die "Error: Stats file $stats_filename does not have 2 lines\n";

	my @keys = split /\t/, $stats[0];
	my @values = split /\t/, $stats[1];

	scalar @keys == scalar @values or die "Error: Stats file $stats_filename with column mismatch\n";

	foreach my $stat_index (0..$#keys)
	{
		my $key = $keys[$stat_index];
		my $value = $values[$stat_index];

		$stats_outref->{$key} = $value;
	}
}

sub retrieve_fastq_padd
{
	my $info_ref = shift;
	
	# Fastq files and prefix for index and name map
	$info_ref->{reads_end_1_fastq} = $info_ref->{prefix}.".1.fastq";
	$info_ref->{reads_end_2_fastq} = $info_ref->{prefix}.".2.fastq";
	$info_ref->{reads_end_1_sample_fastq} = $info_ref->{prefix}.".sample.1.fastq";
	$info_ref->{reads_end_2_sample_fastq} = $info_ref->{prefix}.".sample.2.fastq";
	$runner->padd("$samtools_bin view #<1 | $retrieve_sam_fastq_script #>1 #>2 $reads_per_job 17 #>3 #>4", [$info_ref->{read_sorted_bam}], [$info_ref->{reads_end_1_fastq},$info_ref->{reads_end_2_fastq},$info_ref->{reads_end_1_sample_fastq},$info_ref->{reads_end_2_sample_fastq}]);
}

sub split_fastq_padd
{
	my $info_ref = shift;
	
	$info_ref->{reads_split_prefix} = $jobs_directory."/".$info_ref->{data_type}.".";
	$info_ref->{reads_end_1_split_suffix} = ".1.fastq";
	$info_ref->{reads_end_2_split_suffix} = ".2.fastq";
	$info_ref->{reads_end_1_split_catalog} = $output_directory."/".$info_ref->{data_type}.".1.split.catalog";
	$info_ref->{reads_end_2_split_catalog} = $output_directory."/".$info_ref->{data_type}.".2.split.catalog";
	$runner->padd("$split_fastq_script #<1 $reads_per_job $info_ref->{reads_split_prefix} $info_ref->{reads_end_1_split_suffix} > #>1", [$info_ref->{reads_end_1_fastq}], [$info_ref->{reads_end_1_split_catalog}]);
	$runner->padd("$split_fastq_script #<1 $reads_per_job $info_ref->{reads_split_prefix} $info_ref->{reads_end_2_split_suffix} > #>1", [$info_ref->{reads_end_2_fastq}], [$info_ref->{reads_end_2_split_catalog}]);
}

sub split_fastq_finish
{
	my $info_ref = shift;
	my $jobs_ref = shift;
	
	my @reads_end_1_split_fastqs = readsplitcatalog($info_ref->{reads_end_1_split_catalog});
	my @reads_end_2_split_fastqs = readsplitcatalog($info_ref->{reads_end_2_split_catalog});
	
	scalar @reads_end_1_split_fastqs == scalar @reads_end_2_split_fastqs or die "Error: Different split size between end 1 and 2\n";
	
	foreach my $split_index (0..$#reads_end_1_split_fastqs)
	{
		my $fastq1 = $reads_end_1_split_fastqs[$split_index];
		my $fastq2 = $reads_end_2_split_fastqs[$split_index];
		
		my $prefix1 = $fastq1;
		my $prefix2 = $fastq2;
		
		$prefix1 =~ s/$info_ref->{reads_end_1_split_suffix}$//;
		$prefix2 =~ s/$info_ref->{reads_end_2_split_suffix}$//;
		
		$prefix1 eq $prefix2 or die "Error: Inconsistent split, $prefix1 should equal $prefix2\n";
		
		my %job_info;
		$job_info{prefix} = $prefix1;
		$job_info{name} = basename($prefix1);
		$job_info{fastq1} = $fastq1;
		$job_info{fastq2} = $fastq2;
		
		push @{$jobs_ref}, \%job_info;
	}
}

sub wgss_align_padd
{
	my $info_ref = shift;
	my $jobs_ref = shift;
	
	print "Discordant wgss alignments\n";
	foreach my $job_info (@{$jobs_ref})
	{
		# Names of job products
		$job_info->{spanning_alignments} = $job_info->{prefix}.".spanning.alignments";
		$job_info->{spanning_filelist} = $job_info->{prefix}.".spanning.filelist";
		$job_info->{spanning_matealign} = $job_info->{prefix}.".spanning.matealign";
		
		my $job_cmd = $alignjob_dna_script." ";
		$job_cmd .= "-c ".$config_filename." ";
		$job_cmd .= "-j ".$job_info->{name}." ";
		$job_cmd .= "-l ".$joblocal_directory." ";
		$job_cmd .= "-o ".$output_directory." ";
		$job_cmd .= "-n ".$library_name." ";
		$job_cmd .= "-p ".$job_info->{prefix}." ";
		
		my @job_products;
		push @job_products, $job_info->{spanning_alignments};
		push @job_products, $job_info->{spanning_filelist};
		push @job_products, $job_info->{spanning_matealign};
		
		$runner->padd("$job_cmd", [$job_info->{fastq1}, $job_info->{fastq2}], [@job_products]); 
	}
}

sub wgss_sample_align_padd
{
	my $info_ref = shift;
	
	$info_ref->{true_align_samples} = $output_directory."/".$info_ref->{data_type}.".true.align.samples";
	$runner->padd("$bowtie2_bin --no-mixed --no-discordant -X $dna_max_fragment_length $bowtie2_options -x $genome_fasta -1 #<1 -2 #<2 | $filter_sam_mapped_script | $matealigntrue_bin -r $genome_fasta -a - > #>1", [$info_ref->{reads_end_1_sample_fastq},$info_ref->{reads_end_2_sample_fastq}], [$info_ref->{true_align_samples}]);
	
	$info_ref->{null_align_samples} = $output_directory."/".$info_ref->{data_type}.".null.align.samples";
	$runner->padd("cat #<1 #<2 | $matealignnull_bin -r $genome_fasta -l $matealign_search_length > #>1", [$info_ref->{reads_end_1_sample_fastq},$info_ref->{reads_end_2_sample_fastq}], [$info_ref->{null_align_samples}]);
}

sub wgss_stats_padd
{
	my $info_ref = shift;
	
	$info_ref->{concordant_stats} = $info_ref->{prefix}.".concordant.stats";
	$runner->padd("$samtools_bin view #<1 | $filter_sam_concordant_script | $read_stats_script > #>1", [$info_ref->{read_sorted_bam}], [$info_ref->{concordant_stats}]);
	
	$info_ref->{concordant_depthsamples} = $info_ref->{prefix}.".concordant.depthsamples";
	$runner->padd("$samtools_bin view #<1 | $filter_sam_concordant_script | $calcspandist_bin -f $genome_fasta.fai -i $mt_chromosome -t $discord_read_trim -n $spandist_num_samples -a - > #>1", [$info_ref->{read_sorted_bam}], [$info_ref->{concordant_depthsamples}]);
}

sub wgss_merge_cluster
{
	my $info_ref = shift;
	my $jobs_ref = shift;
	
	my @job_spanning_alignments;
	my @job_spanning_matealign;
	foreach my $job_info (@{$jobs_ref})
	{
		push @job_spanning_alignments, $job_info->{spanning_alignments};
		push @job_spanning_matealign, $job_info->{spanning_matealign};
	}
	
	# Merge products of the alignment process
	$info_ref->{spanning_alignments} = $info_ref->{prefix}.".spanning.alignments";
	$info_ref->{spanning_matealign} = $info_ref->{prefix}.".spanning.matealign";
	$runner->padd("cat #<A > #>1", [@job_spanning_alignments], [$info_ref->{spanning_alignments}]);
	$runner->padd("cat #<A > #>1", [@job_spanning_matealign], [$info_ref->{spanning_matealign}]);
	$runner->prun();
	
	# Read in the read stats
	my %read_stat_values;
	get_stats($info_ref->{concordant_stats}, \%read_stat_values);
	
	$info_ref->{read_length_min} = $read_stat_values{"readlength_min"};
	$info_ref->{read_length_max} = $read_stat_values{"readlength_max"};
	$info_ref->{readlengths_list} = $read_stat_values{"readlengths_list"};
	$info_ref->{fragment_mean} = $read_stat_values{"fraglength_mean"};
	$info_ref->{fragment_stddev} = $read_stat_values{"fraglength_stddev"};
	
	print "WGSS Read Stats\n";
	print "\tFragment mean $info_ref->{fragment_mean} stddev $info_ref->{fragment_stddev}\n";
	print "\tRead length min $info_ref->{read_length_min} max $info_ref->{read_length_max}\n";
	
	print "Ranking alignments\n";
	$info_ref->{spanning_alignments_scores} = $info_ref->{prefix}.".spanning.alignments.scores";
	$info_ref->{spanning_alignments_scores_prob} = $info_ref->{prefix}.".spanning.alignments.scores.prob";
	$info_ref->{spanning_alignments_prob} = $info_ref->{prefix}.".spanning.alignments.prob";
	$runner->run("$extract_alignment_scores_script < #<1 > #>1", [$info_ref->{spanning_alignments}], [$info_ref->{spanning_alignments_scores}]);
	$runner->run("$align_prob_rscript #<1 #<2 #>1", [$info_ref->{spanning_alignments_scores},$info_ref->{true_align_samples}], [$info_ref->{spanning_alignments_scores_prob}]);
	$runner->run("$calc_fragment_align_prob_script #<1 < #<2 > #>1", [$info_ref->{spanning_alignments_scores_prob},$info_ref->{spanning_alignments}], [$info_ref->{spanning_alignments_prob}]);
	
	print "Ranking mate alignments\n";
	$info_ref->{spanning_matealign_prob} = $info_ref->{prefix}.".spanning.matealign.prob";
	$runner->jobmem(12000000000);
	$runner->run("$rankmatealign_bin -n #<1 -c #<2 -m #<3 > #>1", [$info_ref->{null_align_samples},$info_ref->{true_align_samples},$info_ref->{spanning_matealign}], [$info_ref->{spanning_matealign_prob}]);
	
	# Read divided spanning alignment lists
	foreach my $job_info (@{$jobs_ref})
	{
		open SFL, $job_info->{spanning_filelist} or die;
		while (<SFL>)
		{
			chomp;
			my ($chr1,$chr2,$filename) = split /\t/;
			push @{$info_ref->{spanning_filenames}{$chr1}{$chr2}}, $filename;
		}
		close SFL;
	}
	
	print "Generating WGSS discordant alignment clusters\n";
	foreach my $chr1 (sort {$a cmp $b} keys %{$info_ref->{spanning_filenames}})
	{
		foreach my $chr2 (sort {$a cmp $b} keys %{$info_ref->{spanning_filenames}{$chr1}})
		{
			$info_ref->{chr_clusters}{$chr1}{$chr2} = $jobs_directory."/".$info_ref->{data_type}.".".$chr1."-".$chr2.".clusters";
			$runner->padd("cat #<A | $clustermatepairs_bin -m $dna_min_spanning_reads -p $chr1,$chr2 -u $info_ref->{fragment_mean} -d $info_ref->{fragment_stddev} -a - -o #>1", [@{$info_ref->{spanning_filenames}{$chr1}{$chr2}}], [$info_ref->{chr_clusters}{$chr1}{$chr2}]);
		}
	}
	$runner->prun();
	
	print "Unifying cluster ids\n";
	my @unify_in_args;
	my @unify_out_args;
	foreach my $chr1 (sort {$a cmp $b} keys %{$info_ref->{chr_clusters}})
	{
		foreach my $chr2 (sort {$a cmp $b} keys %{$info_ref->{chr_clusters}{$chr1}})
		{
			$info_ref->{chr_clusters_unified}{$chr1}{$chr2} = $jobs_directory."/".$info_ref->{data_type}.".".$chr1."-".$chr2.".clusters.unified";
			
			push @unify_in_args, $info_ref->{chr_clusters}{$chr1}{$chr2};
			push @unify_out_args, $info_ref->{chr_clusters_unified}{$chr1}{$chr2};
		}
	}
	$runner->run("$unify_clusters_script #<A #>A", [@unify_in_args], [@unify_out_args]);
	
	print "Filter pcr duplicates\n";
	foreach my $chr1 (sort {$a cmp $b} keys %{$info_ref->{chr_clusters_unified}})
	{
		foreach my $chr2 (sort {$a cmp $b} keys %{$info_ref->{chr_clusters_unified}{$chr1}})
		{
			$info_ref->{chr_clusters_nodup}{$chr1}{$chr2} = $jobs_directory."/".$info_ref->{data_type}.".".$chr1."-".$chr2.".clusters.nodup";
			$runner->padd("$remove_duplicates_script $dna_min_spanning_reads < #<1 > #>1", [$info_ref->{chr_clusters_unified}{$chr1}{$chr2}], [$info_ref->{chr_clusters_nodup}{$chr1}{$chr2}]);
			push @{$info_ref->{chr_clusters_nodup_all}}, $info_ref->{chr_clusters_nodup}{$chr1}{$chr2};
		}
	}
	$runner->prun();
	
	print "Calculating cluster connectivity\n";
	my %clusters_bychr;
	foreach my $chr1 (sort {$a cmp $b} keys %{$info_ref->{chr_clusters_nodup}})
	{
		foreach my $chr2 (sort {$a cmp $b} keys %{$info_ref->{chr_clusters_nodup}{$chr1}})
		{
			push @{$clusters_bychr{$chr1}}, $info_ref->{chr_clusters_nodup}{$chr1}{$chr2};
			push @{$clusters_bychr{$chr2}}, $info_ref->{chr_clusters_nodup}{$chr1}{$chr2};
		}
	}
	foreach my $chr (keys %clusters_bychr)
	{
		$info_ref->{chr_cluster_connect}{$chr} = $jobs_directory."/".$info_ref->{data_type}.".".$chr.".clusters.connect";
		$info_ref->{chr_cluster_connect_null}{$chr} = $jobs_directory."/".$info_ref->{data_type}.".".$chr.".clusters.connect.null";
		$runner->padd("cat #<A | $clusterconnectivity_bin -c #>1 -n #>2 -s $null_connect_samples -r $chr", [sort {$a cmp $b} @{$clusters_bychr{$chr}}], [$info_ref->{chr_cluster_connect}{$chr},$info_ref->{chr_cluster_connect_null}{$chr}]);
		push @{$info_ref->{chr_cluster_connect_all}}, $info_ref->{chr_cluster_connect}{$chr};
		push @{$info_ref->{chr_cluster_connect_null_all}}, $info_ref->{chr_cluster_connect_null}{$chr};
	}
	$runner->prun();
	
	print "Merge clusters\n";
	$info_ref->{clusters_all} = $info_ref->{prefix}.".clusters.all";
	$info_ref->{cluster_connect} = $info_ref->{prefix}.".clusters.connect";
	$info_ref->{cluster_connect_null} = $info_ref->{prefix}.".clusters.connect.null";
	$runner->run("cat #<A > #>1", [@{$info_ref->{chr_clusters_nodup_all}}], [$info_ref->{clusters_all}]);
	$runner->run("cat #<A > #>1", [@{$info_ref->{chr_cluster_connect_all}}], [$info_ref->{cluster_connect}]);
	$runner->run("cat #<A > #>1", [@{$info_ref->{chr_cluster_connect_null_all}}], [$info_ref->{cluster_connect_null}]);
	
	print "Pre-setcover for clusters\n";
	$info_ref->{clusters_raw} = $info_ref->{prefix}.".clusters.raw";
	$runner->run("$presetcover_bin -c #<1 -o #>1", [$info_ref->{clusters_all}], [$info_ref->{clusters_raw}]);
	
	print "Ranking dna clusters\n";
	$info_ref->{clusters_raw_read_counts} = $info_ref->{prefix}.".clusters.raw.readcounts";
	$info_ref->{clusters_raw_prob_step1} = $info_ref->{prefix}.".clusters.raw.prob.step1";
	$info_ref->{clusters_raw_read_counts_prob} = $info_ref->{prefix}.".clusters.raw.readcounts.prob";
	$info_ref->{clusters_raw_prob_step2} = $info_ref->{prefix}.".clusters.raw.prob.step2";
	$runner->run("$count_cluster_reads_script < #<1 > #>1", [$info_ref->{clusters_raw}], [$info_ref->{clusters_raw_read_counts}]);
	$runner->run("$rankclusters_bin -c #<1 -a #<2 -m #<3 > #>1", [$info_ref->{clusters_raw},$info_ref->{spanning_alignments_prob},$info_ref->{spanning_matealign_prob}], [$info_ref->{clusters_raw_prob_step1}]);
	$runner->run("$cluster_size_prob_rscript #<1 #<2 #<3 #>1", [$info_ref->{concordant_depthsamples},$info_ref->{clusters_raw_read_counts},$info_ref->{clusters_raw_prob_step1}], [$info_ref->{clusters_raw_read_counts_prob}]);
	$runner->run("$rankclusters_bin -c #<1 -a #<2 -m #<3 -d #<4 > #>1", [$info_ref->{clusters_raw},$info_ref->{spanning_alignments_prob},$info_ref->{spanning_matealign_prob},$info_ref->{clusters_raw_read_counts_prob}], [$info_ref->{clusters_raw_prob_step2}]);
	
	print "Ranking cluster connectivity\n";
	$info_ref->{connect_prob} = $info_ref->{prefix}.".connect.prob";
	$info_ref->{clusters_raw_prob_step3} = $info_ref->{prefix}.".clusters.raw.prob.step3";
	$runner->run("$connect_prob_rscript #<1 #<2 #>1", [$info_ref->{cluster_connect},$info_ref->{cluster_connect_null}], [$info_ref->{connect_prob}]);
	$runner->run("$calc_cluster_connect_prob_script #<1 #<2 #<3 > #>1", [$info_ref->{connect_prob},$info_ref->{cluster_connect},$info_ref->{clusters_raw_prob_step2}], [$info_ref->{clusters_raw_prob_step3}]);
	
	print "Filtering dna clusters\n";
	$info_ref->{clusters} = $info_ref->{prefix}.".clusters";
	$info_ref->{clusters_prob} = $info_ref->{prefix}.".clusters.prob";
	$runner->run("$filter_clusters_script #<1 #<2 #>1 #>2 $cluster_prob_threshold", [$info_ref->{clusters_raw},$info_ref->{clusters_raw_prob_step3}], [$info_ref->{clusters},$info_ref->{clusters_prob}]); 
}

