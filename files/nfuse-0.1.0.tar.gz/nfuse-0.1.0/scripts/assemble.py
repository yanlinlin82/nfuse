
import optparse
import csv
import os
import sys

usage = """usage: %prog [options] paths dnaclusters rnaregions dnaseqs rnaseqs [rnaids]"""

parser = optparse.OptionParser(usage)
(options, args) = parser.parse_args()

if len(args) < 5:
	parser.error("incorrect number of arguments")

pathsFilename = args[0]
dnaClustersFilename = args[1]
rnaRegionsFilename = args[2]
dnaSeqsFilename = args[3]
rnaSeqsFilename = args[4]

selectRnaIDs = set()
if len(args) > 5:
	if os.path.exists(args[5]):
		idReader = csv.reader(open(args[5], 'r'), delimiter='\t')
		for row in idReader:
			selectRnaIDs.add(int(row[0]))
	else:
		selectRnaIDs.add(int(args[3]))

class clustersParser:
	def __init__(self,clustersFile):
		self.clustersFile = clustersFile
	def clusters(self):
		clustersReader = csv.reader(self.clustersFile, delimiter='\t')
		self.currentId = None
		self.currentRegion = [[None,]*4,[None,]*4]
		for row in clustersReader:
			id =  int(row[0])
			side = int(row[1])
			chr = row[4]
			strand = row[5]
			start = int(row[6])
			end = int(row[7])
			if self.currentId != None and self.currentId != id:
				yield (self.currentId,self.currentRegion)
				self.currentRegion = [[None,]*4,[None,]*4]
			self.currentId = id
			self.currentRegion[side][0] = chr
			self.currentRegion[side][1] = strand
			if not self.currentRegion[side][2]:
				self.currentRegion[side][2] = start
			if not self.currentRegion[side][3]:
				self.currentRegion[side][3] = end
			self.currentRegion[side][2] = min(self.currentRegion[side][2],start)
			self.currentRegion[side][3] = max(self.currentRegion[side][3],end)
		if self.currentId != None:
			yield (self.currentId,self.currentRegion)


class regionsParser:
	def __init__(self,regionsFile):
		self.regionsFile = regionsFile
	def regions(self):
		regionsReader = csv.reader(self.regionsFile, delimiter='\t')
		self.currentId = None
		self.currentRegion = [[None,]*4,[None,]*4]
		for row in regionsReader:
			id =  int(row[0])
			side = int(row[1])
			chr = row[2]
			strand = row[3]
			start = int(row[4])
			end = int(row[5])
			if self.currentId != None and self.currentId != id:
				yield (self.currentId,self.currentRegion)
				self.currentRegion = [[None,]*4,[None,]*4]
			self.currentId = id
			self.currentRegion[side][0] = chr
			self.currentRegion[side][1] = strand
			self.currentRegion[side][2] = start
			self.currentRegion[side][3] = end
		if self.currentId != None:
			yield (self.currentId,self.currentRegion)

class pathsParser:
	def __init__(self,pathsFile):
		self.pathsFile = pathsFile
	def paths(self):
		pathsReader = csv.reader(self.pathsFile, delimiter='\t')
		for row in pathsReader:
			score = float(row[0])
			rnaID = int(row[1])
			dnaIDs = []
			for dnaID,dnaSide in zip(row[2:][::2],row[2:][1::2]):
				if dnaID == "" or dnaSide == "":
					continue
				dnaIDs.append((int(dnaID),int(dnaSide)))
			if len(dnaIDs) == 0:
				continue
			yield (rnaID, score, dnaIDs)

paths = {}
pathRnaID = {}
pathScore = {}
revPathIDs = set()
pathDnaIDs = set()
pathRnaIDs = set()

pathID = 0
for pathInfo in pathsParser(open(pathsFilename,'r')).paths():
	rnaID = pathInfo[0]
	score = pathInfo[1]
	dnaIDs = pathInfo[2]
	
	pathDnaIDs.update(set([a[0] for a in dnaIDs[::2]]))
	pathRnaIDs.add(rnaID)
	
	paths[pathID] = dnaIDs
	pathRnaID[pathID] = rnaID
	pathScore[pathID] = score
	pathID += 1
	
	revDnaIDs = list(dnaIDs)
	revDnaIDs.reverse()
	
	paths[pathID] = revDnaIDs
	pathRnaID[pathID] = rnaID
	pathScore[pathID] = score
	revPathIDs.add(pathID)
	pathID += 1

if len(selectRnaIDs) == 0:
	selectRnaIDs = set(pathRnaIDs)

dnaRegions = {}
for region in clustersParser(open(dnaClustersFilename,'r')).clusters():
	if region[0] not in pathDnaIDs:
		continue
	dnaRegions[region[0]] = region[1]

rnaRegions = {}
for region in regionsParser(open(rnaRegionsFilename,'r')).regions():
	if region[0] not in pathRnaIDs:
		continue
	rnaRegions[region[0]] = region[1]

def fragmentdistance(region1,region2):
	if region1[0] != region2[0] or region1[1] == region2[1]:
		return None
	if region1[1] == "-":
		region1,region2 = region2,region1
	return region1[2] - region2[3]

pathInnerRegions = {}
for pathID,dnaIDs in paths.iteritems():
	pathInnerRegions[pathID] = []
	for dnaID1,dnaID2 in zip(dnaIDs[1::2], dnaIDs[2::2]):
		chr = dnaRegions[dnaID1[0]][dnaID1[1]][0]
		strand = dnaRegions[dnaID1[0]][dnaID1[1]][1]
		start = min(dnaRegions[dnaID1[0]][dnaID1[1]][2],dnaRegions[dnaID2[0]][dnaID2[1]][2])
		end = max(dnaRegions[dnaID1[0]][dnaID1[1]][3],dnaRegions[dnaID2[0]][dnaID2[1]][3])
		pathInnerRegions[pathID].append((chr,strand,start,end))

dnaIDPaths = {}
for pathID, dnaIDs in paths.iteritems():
	for dnaID in dnaIDs:
		if dnaID not in dnaIDPaths:
			dnaIDPaths[dnaID] = set()
		dnaIDPaths[dnaID].add(pathID)

def overlap(list1, list2, common):
	index1 = list1.index(common)
	index2 = list2.index(common)
	while index1 >= 0 and index2 >= 0:
		if list1[index1] != list2[index2]:
			return False
		index1 -= 1
		index2 -= 1
	index1 = list1.index(common)
	index2 = list2.index(common)
	while index1 < len(list1) and index2 < len(list2):
		if list1[index1] != list2[index2]:
			return False
		index1 += 1
		index2 += 1
	return True

def listcontains(list1, list2):
	if list2[0] not in list1:
		return False
	index1 = list1.index(list2[0])
	index2 = 0
	while index2 < len(list2):
		if index1 >= len(list1):
			return False
		if list1[index1] != list2[index2]:
			return False
		index1 += 1
		index2 += 1
	return True

def regionoverlap(region1, region2):
	if region1[0] != region2[0]:
		return None
	return not (region1[2] > region2[3] or region1[3] < region2[2])
	
def pathcontains(pathID1, pathID2):
	if not listcontains(paths[pathID1], paths[pathID2]):
		return False
	rnaSide1,rnaSide2 = 0,1
	if pathID2 in revPathIDs:
		rnaSide1,rnaSide2 = 1,0
	startIndex = paths[pathID1].index(paths[pathID2][0])
	if startIndex > 0:
		if not regionoverlap(pathInnerRegions[pathID1][startIndex/2-1], rnaRegions[pathRnaID[pathID2]][rnaSide1]):
			return False
	endIndex = paths[pathID1].index(paths[pathID2][-1])
	if endIndex < len(paths[pathID1]) - 1:
		if not regionoverlap(pathInnerRegions[pathID1][endIndex/2], rnaRegions[pathRnaID[pathID2]][rnaSide2]):
			return False
	return True

containMap = {}
support = {}
for dnaID, pathIDs in dnaIDPaths.iteritems():
	for pathID1 in pathIDs:
		if pathRnaID[pathID1] not in selectRnaIDs:
			continue
		if pathID1 not in support:
			support[pathID1] = [set([(0,len(paths[pathID1])-1)]) for a in paths[pathID1]]
		for pathID2 in pathIDs:
			if pathRnaID[pathID1] == pathRnaID[pathID2]:
				continue
			if pathcontains(pathID1, pathID2):
				if pathID1 not in containMap:
					containMap[pathID1] = set()
				containMap[pathID1].add(pathID2)
				startIndex = paths[pathID1].index(paths[pathID2][0])
				endIndex = paths[pathID1].index(paths[pathID2][-1])
				for index1 in range(startIndex, endIndex + 1):
					support[pathID1][index1].add((startIndex,endIndex))

filteredRnaID = set()
filteredDnaID = set()
for pathID in containMap:
	if len(paths[pathID]) == 2:
		continue
	if pathID in revPathIDs:
		continue
	if pathRnaID[pathID] not in selectRnaIDs:
		continue
	filteredRnaID.add(pathRnaID[pathID])
	filteredDnaID.update(set([id[0] for id in paths[pathID][::2]]))
	for containedPathID in containMap[pathID]:
		if pathRnaID[containedPathID] == pathRnaID[pathID]:
			continue
		filteredRnaID.add(pathRnaID[containedPathID])

rnaSeqs = {}
rnaCounts = {}
for row in csv.reader(open(rnaSeqsFilename,'r'), delimiter='\t'):
	id = int(row[0])
	if id not in filteredRnaID:
		continue
	rnaSeqs[id] = row[1]
	rnaCounts[id] = row[2]

dnaSeqs = {}
dnaCounts = {}
for row in csv.reader(open(dnaSeqsFilename,'r'), delimiter='\t'):
	id = int(row[0])
	if id not in filteredDnaID:
		continue
	dnaSeqs[id] = row[1]
	dnaCounts[id] = row[2]

for pathID in containMap:
	if len(paths[pathID]) == 2:
		continue
	if pathID in revPathIDs:
		continue
	if pathRnaID[pathID] not in selectRnaIDs:
		continue
	supportCounts = [len(a) for a in support[pathID][::2]]
	regions = [dnaRegions[paths[pathID][0][0]][paths[pathID][0][1]]] + pathInnerRegions[pathID] + [dnaRegions[paths[pathID][-1][0]][paths[pathID][-1][1]]]
	chrs = [a[0] for a in regions]
	mids = [(a[2]+a[3])/2 for a in regions]
	midsMeg = [float(a)/1000000 for a in mids]
	print ""
	print pathRnaID[pathID]
	print "\t%s" % ("\t".join(chrs))
	print "\t%s" % ("\t".join(["%.1f"%a for a in midsMeg]))
	print len(containMap[pathID])
	print "sup\t\t%s" % ("\t".join([str(a) for a in supportCounts]))
	print "seq\t\t%s" % ("\t".join([dnaSeqs[id[0]] for id in paths[pathID][::2]]))
	print "cnt\t\t%s" % ("\t".join([dnaCounts[id[0]] for id in paths[pathID][::2]]))
	print "%d\t%.3f\t%s\t%s\t%s" % (pathRnaID[pathID],pathScore[pathID],"\t".join([str(id[0]) for id in paths[pathID][::2]]),rnaSeqs[pathRnaID[pathID]],rnaCounts[pathRnaID[pathID]])
	for containedPathID in containMap[pathID]:
		if pathRnaID[containedPathID] == pathRnaID[pathID]:
			continue
		startIndex = paths[pathID].index(paths[containedPathID][0]) / 2
		formatted = [""] * startIndex + [str(id[0]) for id in paths[containedPathID][::2]]
		formatted = formatted + [""] * (len(paths[pathID][::2]) - len(formatted))
		print "%d\t%.3f\t%s\t%s\t%s" % (pathRnaID[containedPathID],pathScore[containedPathID],"\t".join(formatted),rnaSeqs[pathRnaID[containedPathID]],rnaCounts[pathRnaID[containedPathID]])

