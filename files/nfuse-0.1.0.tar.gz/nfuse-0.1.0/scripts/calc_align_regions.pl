#!/usr/bin/perl

use strict;
use warnings;
use List::Util qw[min max];


my $current_cluster_id;
my %current_cluster_preamb;
my %current_cluster_regions;
while (<>)
{
	chomp;
	my @fields = split /\t/;

	my $cluster_id = $fields[0];
	my $cluster_end = $fields[1];
	my $fragment = $fields[2];
	my $read_end = $fields[3];
	my $ref_name = $fields[4];
	my $strand = $fields[5];
	my $start = $fields[6];
	my $end = $fields[7];

	if (defined $current_cluster_id and $current_cluster_id != $cluster_id)
	{
		print $current_cluster_preamb{"0"}."\t".$current_cluster_regions{"0"}{start}."\t".$current_cluster_regions{"0"}{end}."\n";
		print $current_cluster_preamb{"1"}."\t".$current_cluster_regions{"1"}{start}."\t".$current_cluster_regions{"1"}{end}."\n";

		delete $current_cluster_regions{"0"};
		delete $current_cluster_regions{"1"};
	}
	
	$current_cluster_id = $cluster_id;

	$current_cluster_regions{$cluster_end}{start} = $start if not defined $current_cluster_regions{$cluster_end}{start};
	$current_cluster_regions{$cluster_end}{end} = $end if not defined $current_cluster_regions{$cluster_end}{end};
	
	$current_cluster_regions{$cluster_end}{start} = min($start, $current_cluster_regions{$cluster_end}{start});
	$current_cluster_regions{$cluster_end}{end} = max($end, $current_cluster_regions{$cluster_end}{end});

	$current_cluster_preamb{$cluster_end} = $cluster_id."\t".$cluster_end."\t".$ref_name."\t".$strand;
}

if (defined $current_cluster_id)
{
	print $current_cluster_preamb{"0"}."\t".$current_cluster_regions{"0"}{start}."\t".$current_cluster_regions{"0"}{end}."\n";
	print $current_cluster_preamb{"1"}."\t".$current_cluster_regions{"1"}{start}."\t".$current_cluster_regions{"1"}{end}."\n";
}



