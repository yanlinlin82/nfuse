#!/usr/bin/perl

use strict;
use warnings;
use List::Util qw[min max];

my $max_fragment_length = shift;

defined $max_fragment_length or die "Usage: $0 max_fragment_length < clusters > breaks\n";

$max_fragment_length = int($max_fragment_length);

my $current_cluster_id;
my %current_cluster_preamb;
my %current_cluster_breaks;
while (<>)
{
	chomp;
	my @fields = split /\t/;

	my $cluster_id = $fields[0];
	my $cluster_end = $fields[1];
	my $fragment = $fields[2];
	my $read_end = $fields[3];
	my $ref_name = $fields[4];
	my $strand = $fields[5];
	my $start = $fields[6];
	my $end = $fields[7];

	if (defined $current_cluster_id and $current_cluster_id != $cluster_id)
	{
		print $current_cluster_preamb{"0"}."\t".$current_cluster_breaks{"0"}{start}."\t".$current_cluster_breaks{"0"}{end}."\n";
		print $current_cluster_preamb{"1"}."\t".$current_cluster_breaks{"1"}{start}."\t".$current_cluster_breaks{"1"}{end}."\n";

		delete $current_cluster_breaks{"0"};
		delete $current_cluster_breaks{"1"};
	}
	
	my $align_length = $end - $start + 1;
	
	my $break_start;
	my $break_end;
	if ($strand eq "+")
	{
		$break_start = $end + 1;
		$break_end = $end + $max_fragment_length - 2 * $align_length;
	}
	else
	{
		$break_start = $start - $max_fragment_length + 2 * $align_length;
		$break_end = $start - 1;
	}

	$current_cluster_id = $cluster_id;

	$current_cluster_breaks{$cluster_end}{start} = $break_start if not defined $current_cluster_breaks{$cluster_end}{start};
	$current_cluster_breaks{$cluster_end}{end} = $break_end if not defined $current_cluster_breaks{$cluster_end}{end};
	
	$current_cluster_breaks{$cluster_end}{start} = min($break_start, $current_cluster_breaks{$cluster_end}{start});
	$current_cluster_breaks{$cluster_end}{end} = max($break_end, $current_cluster_breaks{$cluster_end}{end});

	$current_cluster_preamb{$cluster_end} = $cluster_id."\t".$cluster_end."\t".$ref_name."\t".$strand;
}

if (defined $current_cluster_id)
{
	print $current_cluster_preamb{"0"}."\t".$current_cluster_breaks{"0"}{start}."\t".$current_cluster_breaks{"0"}{end}."\n";
	print $current_cluster_preamb{"1"}."\t".$current_cluster_breaks{"1"}{start}."\t".$current_cluster_breaks{"1"}{end}."\n";
}



