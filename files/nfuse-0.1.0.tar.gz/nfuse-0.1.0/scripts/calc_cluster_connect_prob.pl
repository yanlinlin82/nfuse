#!/usr/bin/perl

use strict;
use warnings;
use List::Util qw[min max];


my $connect_prob_filename = shift;
my $cluster_connect_filename = shift;
my $cluster_prob_filename = shift;

die "Usage: $0 connect_prob cluster_connect cluster_prob > cluster_full_prob\n" if not defined $cluster_prob_filename;

my %connect_prob;
open PROB, $connect_prob_filename or die "Error: Unable to open $connect_prob_filename\n";
while (<PROB>)
{
	chomp;
	my ($connect,$probability) = split /\t/;
	$connect_prob{$connect} = $probability;
}
close PROB;

my %cluster_connect_prob;
open CLC, $cluster_connect_filename or die "Error: Unable to open $cluster_connect_filename\n";
while (<CLC>)
{
	chomp;
	my @fields = split /\t/;
	
	my $cluster_id = $fields[0];
	my $cluster_end = $fields[1];
	my $connect = $fields[2];
	
	$cluster_connect_prob{$cluster_id}{$cluster_end} = $connect_prob{$connect};
}
close CLC;

open CLP, $cluster_prob_filename or die "Error: Unable to open $cluster_prob_filename\n";
while (<CLP>)
{
	chomp;
	my @fields = split /\t/;
	
	my $cluster_id = $fields[0];
	my $cluster_prob = $fields[1];
	
	my $full_prob = $cluster_prob * $cluster_connect_prob{$cluster_id}{"0"} * $cluster_connect_prob{$cluster_id}{"1"};
	
	print $cluster_id."\t".$full_prob."\n";
}
close CLP;


