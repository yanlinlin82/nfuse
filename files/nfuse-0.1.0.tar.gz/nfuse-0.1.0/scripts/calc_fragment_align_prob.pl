#!/usr/bin/perl

use strict;
use warnings;
use List::Util qw[min max];


my $probabilities_filename = shift;

die "Usage: $0 probabilities < alignments > alignments_prob\n" if not defined $probabilities_filename;

my %probabilities;
open PROB, $probabilities_filename or die "Error: Unable to open $probabilities_filename\n";
while (<PROB>)
{
	chomp;
	my ($aligned_length,$score,$probability) = split /\t/;
	$probabilities{$aligned_length}{$score} = $probability;
}
close PROB;

my $current_fragment_id;
my %scores;
while (<>)
{
	chomp;
	my @fields = split /\t/;
	
	my $fragment_id = $fields[0];
	my $read_end = $fields[1];
	my $aligned_length = $fields[7];
	my $score = $fields[8];
	
	if (defined $current_fragment_id and $current_fragment_id != $fragment_id)
	{
		my $probability = 1.0;
		foreach my $read_end ("0","1")
		{
			my $max_score = max(keys %{$scores{$read_end}});
			my $max_score_aligned_length = $scores{$read_end}{$max_score};
			$probability *= $probabilities{$max_score_aligned_length}{$max_score};
		}
		
		print $current_fragment_id."\t".$probability."\n";
		
		%scores = ();
	}
	
	$scores{$read_end}{$score} = $aligned_length;
	
	$current_fragment_id = $fragment_id;
}

if (defined $current_fragment_id)
{
	my $probability = 1.0;
	foreach my $read_end ("0","1")
	{
		my $max_score = max(keys %{$scores{$read_end}});
		my $max_score_aligned_length = $scores{$read_end}{$max_score};
		$probability *= $probabilities{$max_score_aligned_length}{$max_score};
	}
	
	print $current_fragment_id."\t".$probability."\n";
}


