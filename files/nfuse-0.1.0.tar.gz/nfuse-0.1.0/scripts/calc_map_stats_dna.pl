#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use List::Util qw[min max];

my $clusters_filename = shift;

die "Usage: $0 clusters < alignments\n" if not defined $clusters_filename;

my %solution_clusters;
my %solution_fragments;
open SC, $clusters_filename or die "Error: Unable to open $clusters_filename: $!\n";
while (<SC>)
{
	chomp;
	my ($cluster_id,$cluster_end,$fragment_index,$read_end) = split /\t/;
	
	$solution_clusters{$cluster_id}{$fragment_index} = 1;
	$solution_fragments{$fragment_index} = 1;
}
close SC;

my %alignment_counts;
while (<>)
{
	chomp;
	my @fields = split /\t/;
	
	my $fragment_index = $fields[0];
	my $read_end = $fields[1];
	my $rname = $fields[2];
	my $strand = $fields[3];
	my $start = $fields[4];
	my $end = $fields[5];
	
	next unless defined $solution_fragments{$fragment_index};
	
	$alignment_counts{$fragment_index}{$read_end}++;
}

foreach my $cluster_id (keys %solution_clusters)
{
	my @alignment_counts;
	foreach my $fragment_index (keys %{$solution_clusters{$cluster_id}})
	{
		my $alignment_count_end_1 = $alignment_counts{$fragment_index}{0};
		my $alignment_count_end_2 = $alignment_counts{$fragment_index}{1};
		
		my $alignment_count = $alignment_count_end_1 * $alignment_count_end_2;
		
		push @alignment_counts, $alignment_count;
	}
	
	my $min_count = min(@alignment_counts);
	my $max_count = max(@alignment_counts);
	my $mean_count = calc_mean(@alignment_counts);
	my $num_multi = count_multi(@alignment_counts);
	
	print $cluster_id."\tmin_map_count\t".$min_count."\n";
	print $cluster_id."\tmax_map_count\t".$max_count."\n";
	print $cluster_id."\tmean_map_count\t".$mean_count."\n";
	print $cluster_id."\tnum_multi_map\t".$num_multi."\n";
}

sub calc_mean
{
	my $mean = 0;
	foreach my $value (@_)
	{
		$mean += $value;
	}
	
	$mean /= scalar @_;
	
	return $mean;
}

sub count_multi
{
	my $num_multi = 0;
	foreach my $value (@_)
	{
		$num_multi++ if $value > 1;
	}
	
	return $num_multi;
}

