#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use List::Util qw[min max];

use lib dirname($0);
use gene_models;

my $gene_models_filename = shift;
my $clusters_filename = shift;

die "Usage: $0 gene_models clusters < alignments\n" if not defined $clusters_filename;

my $bin_spacing = 200000;

# Read in the gene models
my $gene_models = gene_models->new($gene_models_filename);

my %solution_clusters;
my %solution_fragments;
open SC, $clusters_filename or die "Error: Unable to open $clusters_filename: $!\n";
while (<SC>)
{
	chomp;
	my ($cluster_id,$cluster_end,$fragment_index,$read_end) = split /\t/;
	
	$solution_clusters{$cluster_id}{$fragment_index} = 1;
	$solution_fragments{$fragment_index} = 1;
}
close SC;

my %genome_positions;
while (<>)
{
	chomp;
	my @fields = split /\t/;
	
	my $fragment_index = $fields[0];
	my $read_end = $fields[1];
	my $rname = $fields[2];
	my $strand = $fields[3];
	my $start = $fields[4];
	my $end = $fields[5];
	
	next unless defined $solution_fragments{$fragment_index};
	
	my $chromosome = $gene_models->calc_genomic_chromosome($rname);
	my $genome_start = $gene_models->calc_genomic_position($rname, $start);
	my $genome_end = $gene_models->calc_genomic_position($rname, $end);
	
	if ($genome_start > $genome_end)
	{
		($genome_start,$genome_end) = ($genome_end,$genome_start);
	}
	
	push @{$genome_positions{$fragment_index}{$read_end}}, [$chromosome,$genome_start,$genome_end];
}

my %alignment_counts;
foreach my $fragment_index (keys %genome_positions)
{
	foreach my $read_end (keys %{$genome_positions{$fragment_index}})
	{
		my %read_bins;
		foreach my $align_index (0..$#{$genome_positions{$fragment_index}{$read_end}})
		{
			my $chromosome = $genome_positions{$fragment_index}{$read_end}->[$align_index]->[0];
			my $start = $genome_positions{$fragment_index}{$read_end}->[$align_index]->[1];
			my $end = $genome_positions{$fragment_index}{$read_end}->[$align_index]->[2];
			
			foreach my $bin (get_bins($start,$end))
			{
				push @{$read_bins{$chromosome}{$bin}}, [$start,$end,$align_index];
			}
		}
		
		my %overlapping;
		foreach my $chromosome (keys %read_bins)
		{
			foreach my $bin (keys %{$read_bins{$chromosome}})
			{
				foreach my $align1 (@{$read_bins{$chromosome}{$bin}})
				{
					foreach my $align2 (@{$read_bins{$chromosome}{$bin}})
					{
						if (overlap($align1,$align2))
						{
							$overlapping{$align1->[2]}{$align2->[2]} = 1;
						}
					}
				}
			}
		}
		
		my $alignment_count = 0;
		while (scalar keys %overlapping > 0)
		{
			my $align_index = (keys %overlapping)[0];
			my @other_align_indices = keys %{$overlapping{$align_index}};
			
			foreach my $other_align_index (@other_align_indices)
			{
				delete $overlapping{$other_align_index};
			}
			
			$alignment_count++;
		}
		
		$alignment_counts{$fragment_index}{$read_end} = $alignment_count;
	}
}

foreach my $cluster_id (keys %solution_clusters)
{
	my @alignment_counts;
	foreach my $fragment_index (keys %{$solution_clusters{$cluster_id}})
	{
		my $alignment_count_end_1 = $alignment_counts{$fragment_index}{0};
		my $alignment_count_end_2 = $alignment_counts{$fragment_index}{1};
		
		my $alignment_count = $alignment_count_end_1 * $alignment_count_end_2;
		
		push @alignment_counts, $alignment_count;
	}
	
	my $min_count = min(@alignment_counts);
	my $max_count = max(@alignment_counts);
	my $mean_count = calc_mean(@alignment_counts);
	my $num_multi = count_multi(@alignment_counts);
	
	print $cluster_id."\tmin_map_count\t".$min_count."\n";
	print $cluster_id."\tmax_map_count\t".$max_count."\n";
	print $cluster_id."\tmean_map_count\t".$mean_count."\n";
	print $cluster_id."\tnum_multi_map\t".$num_multi."\n";
}

sub calc_mean
{
	my $mean = 0;
	foreach my $value (@_)
	{
		$mean += $value;
	}
	
	$mean /= scalar @_;
	
	return $mean;
}

sub count_multi
{
	my $num_multi = 0;
	foreach my $value (@_)
	{
		$num_multi++ if $value > 1;
	}
	
	return $num_multi;
}

# Calculate bins overlapped by a region
sub get_bins
{
	my $start = shift;
	my $end = shift;
	
	my $start_bin = int($start / $bin_spacing);
	my $end_bin = int($end / $bin_spacing);
	
	return ($start_bin .. $end_bin);
}

# Check for overlap between regions
sub overlap
{
	my $region1 = $_[0];
	my $region2 = $_[1];
	
	if ($region1->[1] < $region2->[0] or $region1->[0] > $region2->[1])
	{
		return 0;
	}
	else
	{
		return 1;
	}
}

