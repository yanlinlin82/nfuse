#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';

my $match_score = 2;
my $gap_open_score = 5;
my $gap_extension_score = 3;

while (<>)
{
	my $line = $_;

	chomp;
	next if /^\@/;

	my @sam_info = split /\t/;
	
	my $qname = $sam_info[0];
	my $flag = $sam_info[1];
	my $rname = $sam_info[2];
	my $pos = $sam_info[3];
	my $mapq = $sam_info[4];
	my $cigar = $sam_info[5];
	my $mrnm = $sam_info[6];
	my $mpos = $sam_info[7];
	my $isize = $sam_info[8];
	my $seq = $sam_info[9];
	my $qual = $sam_info[10];
	
	next if $flag & hex('0x0004');
	
	$qname =~ /^(\d+)\/([12])/;
	my $fragment_index = $1;
	my $read_end = $2 - 1;
	
	my $align_score;
	my $num_mismatches;
	foreach my $opt_index (11 .. $#sam_info)
	{
		if ($sam_info[$opt_index] =~ /^AS:i:(-?\d+)$/)
		{
			$align_score = $1;
		}
		
		if ($sam_info[$opt_index] =~ /^XM:i:(\d+)$/)
		{
			$num_mismatches = $1;
		}
	}
	
	my $start_gap = 0;
	if ($cigar =~ /^(\d+)S/)
	{
		$start_gap = $1;
	}
	
	my $end_gap = 0;
	if ($cigar =~ /(\d+)S$/)
	{
		$end_gap = $1;
	}
	
	my $matched = 0;
	while ($cigar =~ /(\d+)M/g)
	{
		$matched += $1;
	}
	
	my $deleted = 0;
	while ($cigar =~ /(\d+)D/g)
	{
		$deleted += $1;
	}
	
	my $matches = $matched - $num_mismatches;
	
	$align_score -= $match_score * $matches;
	
	my $strand = "+";
	if ($flag & hex('0x0010'))
	{
		$strand = "-";
	}
	
	my $read_aligned_length = length($seq);
	my $ref_aligned_length = $matched + $deleted;
	if ($strand eq "+")
	{
		$read_aligned_length -= $end_gap;

		$ref_aligned_length += $start_gap;

		$pos -= $start_gap;
		
		if ($start_gap > 0)
		{
			$align_score -= $gap_open_score + $gap_extension_score * $start_gap;
		}
	}
	else
	{
		$read_aligned_length -= $start_gap;
		
		$ref_aligned_length += $end_gap;
		
		if ($end_gap > 0)
		{
			$align_score -= $gap_open_score + $gap_extension_score * $end_gap;
		}
	}
	
	my $start = $pos;
	my $end = $pos + $ref_aligned_length - 1;
	
	my $read_length = length($seq);
	
	print $fragment_index."\t";
	print $read_end."\t";
	print $rname."\t";
	print $strand."\t";
	print $start."\t";
	print $end."\t";
	print $read_length."\t";
	print $read_aligned_length."\t";
	print $align_score."\n";
}
