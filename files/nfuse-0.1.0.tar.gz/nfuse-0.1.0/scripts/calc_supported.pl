#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use List::Util qw[min max];

use lib dirname($0);
use configdata;
use cmdrunner;

my @usage;
push @usage, "Usage: ".basename($0)." [options]\n";
push @usage, "Annotate fusions\n";
push @usage, "  -h, --help      Displays this information\n";
push @usage, "  -c, --config    Configuration Filename\n";
push @usage, "  -o, --output    Output Directory\n";
push @usage, "  -n, --name      Library Name\n";

my $help;
my $config_filename;
my $output_directory;
my $library_name;

GetOptions
(
	'help'        => \$help,
	'config=s'    => \$config_filename,
	'output=s'    => \$output_directory,
	'name=s'      => \$library_name,
);

not defined $help or usage() and exit;

defined $config_filename or die @usage;
defined $output_directory or die @usage;
defined $library_name or die @usage;

my $config = configdata->new();
$config->read($config_filename);

my $log_directory = $output_directory."/log";
my $log_prefix = $log_directory."/calc_supported";

mkdir $log_directory if not -e $log_directory;

my $runner = cmdrunner->new();
$runner->name("calc_supported");
$runner->prefix($log_prefix);

my %dna_rna_support;
my $dna_rna_support_filename = $output_directory."/dna.rna.support";
read_overlap($dna_rna_support_filename, \%dna_rna_support);

my %dna_cluster_ids;
my %rna_cluster_ids;
my $dna_clusters_setcover = $output_directory."/dna.clusters.sc.all";
my $rna_clusters_setcover = $output_directory."/rna.clusters.sc.all";
read_cluster_ids($dna_clusters_setcover, \%dna_cluster_ids);
read_cluster_ids($rna_clusters_setcover, \%rna_cluster_ids);

my %dna_supported;
my %rna_supported;
foreach my $dna_cluster_id (keys %dna_rna_support)
{
	foreach my $rna_cluster_id (keys %{$dna_rna_support{$dna_cluster_id}})
	{
		if (defined $dna_cluster_ids{$dna_cluster_id} and defined $rna_cluster_ids{$rna_cluster_id})
		{
			$dna_supported{$dna_cluster_id} = 1;
			$rna_supported{$rna_cluster_id} = 1;
		}
	}
}

my $dna_supported = $output_directory."/dna.supported";
my $rna_supported = $output_directory."/rna.supported";
write_cluster_ids($dna_supported, \%dna_supported);
write_cluster_ids($rna_supported, \%rna_supported);

sub read_cluster_ids
{
	my $clusters_filename = shift;
	my $gene_clusters_ref = shift;

	open CLU, $clusters_filename or die "Error: Unable to open $clusters_filename: $!\n";
	while (<CLU>)
	{
		chomp;
		my @fields = split /\t/;
		
		my $cluster_id = $fields[0];
		$gene_clusters_ref->{$cluster_id} = 1;
	}
	close CLU;
}

sub read_overlap
{
	my $overlaps_filename = shift;
	my $overlaps_ref = shift;

	open OV, $overlaps_filename or die "Error: Unable to open $overlaps_filename: $!\n";
	while (<OV>)
	{
		chomp;
		my ($dna_cluster_id,$rna_cluster_id) = split /\t/;

		$overlaps_ref->{$dna_cluster_id}{$rna_cluster_id} = 1;
	}
	close OV;
}

sub write_cluster_ids
{
	my $cluster_ids_filename = shift;
	my $cluster_ids_ref = shift;

	open CLU, ">".$cluster_ids_filename or die "Error: Unable to open $cluster_ids_filename: $!\n";
	foreach my $cluster_id (keys %{$cluster_ids_ref})
	{
		print CLU $cluster_id."\n";
	}
	close CLU;
}

