args = commandArgs(TRUE)

#args = c("dna.concordant.depthsamples","dna.clusters.raw.readcounts","dna.clusters.raw.weightedcounts")

depthsamples = read.table(args[1])
clustersizes = read.table(args[2],col.names=c("id","size"))
clusterprobs = read.table(args[3],col.names=c("id","prob"))

clusterinfo = merge(clustersizes, clusterprobs, by="id")

n = 100000

weightedsizes = list()
for (size in clustersizes$size) {
	weightedsizes[[as.character(size)]] = 0
}
for (index in 1:length(clusterinfo$size)) {
	weightedsizes[[as.character(clusterinfo$size[index])]] = weightedsizes[[as.character(clusterinfo$size[index])]] + clusterinfo$prob[index]
}

weightedsizes = data.frame(sizes=as.integer(names(weightedsizes)),weights=unlist(weightedsizes,use.names=F))

cs = weightedsizes$sizes[which(rmultinom(n,size=1,prob=weightedsizes$weights)==1,arr.ind=T)[,1]]

ds = sample(depthsamples$V1[depthsamples$V1>0],n,replace=T)

alls = c(cs,ds)
allv = c(rep(0,n),rep(1,n))

logr = glm(allv ~ alls, family=binomial("logit"))

cval = sum(predict(logr,newdata=data.frame(alls=ds),type="response"))/length(ds)

clamp01 = function(x) return(max(0,min(1,x)))
prob = sapply(predict(logr,newdata=data.frame(alls=seq(1:max(cs))),type="response") / cval, clamp01)

sizeprob = data.frame(size=seq(1:max(cs)),prob=prob)

write.table(sizeprob, file=args[4], quote=F, sep="\t", eol="\n", row.names=F, col.names=F)

