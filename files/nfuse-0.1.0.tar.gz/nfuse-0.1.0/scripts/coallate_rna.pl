#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use List::Util qw[min max];


my %annotations;
while (<>)
{
	chomp;
	my @fields = split /\t/;
	
	my $cluster_id = $fields[0];
	my $anno_type = $fields[1];
	my $anno_value = $fields[2];
	
	$annotations{$cluster_id}{$anno_type} = $anno_value;
}

my %annotation_names;
foreach my $cluster_id (keys %annotations)
{
	foreach my $anno_type (keys %{$annotations{$cluster_id}})
	{
		$annotation_names{$anno_type} = 1;
	}
}

my @annotations_order = sort { $a cmp $b } keys %annotation_names;

print "cluster_id\t";
foreach my $anno_type (@annotations_order)
{
	print $anno_type."\t";
}
print "\n";

foreach my $cluster_id (keys %annotations)
{
	print $cluster_id."\t";
	foreach my $anno_type (@annotations_order)
	{
		if (defined $annotations{$cluster_id}{$anno_type})
		{
			print $annotations{$cluster_id}{$anno_type}."\t";
		}
		else
		{
			print "-\t";
		}
	}
	print "\n";	
}

