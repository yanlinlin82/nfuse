args = commandArgs(TRUE)

#args = c("dna.clusters.connect", "dna.clusters.connect.null")

connect = read.table(args[1])
null = read.table(args[2])

n = 100000

cs = sample(connect$V3,n,replace=T)
ns = sample(null$V1,n,replace=T)

alls = c(cs,ns)
allv = c(rep(0,n),rep(1,n))

logr = glm(allv ~ alls, family=binomial("logit"))

cval = sum(predict(logr,newdata=data.frame(alls=ns),type="response"))/length(ns)

clamp01 = function(x) return(max(0,min(1,x)))
prob = sapply(predict(logr,newdata=data.frame(alls=seq(1:max(cs))),type="response") / cval, clamp01)

connectprob = data.frame(size=seq(1:max(cs)),prob=prob)

write.table(connectprob, file=args[3], quote=F, sep="\t", eol="\n", row.names=F, col.names=F)

