#!/usr/bin/perl

use strict;
use warnings;

my %cluster_counts;

while (<>)
{
	chomp;
	my @fields = split /\t/;
	$cluster_counts{$fields[0]}++;
}

foreach my $cluster_id (keys %cluster_counts)
{
	print $cluster_id."\t";
	print $cluster_counts{$cluster_id} / 2;
	print "\n";
}

