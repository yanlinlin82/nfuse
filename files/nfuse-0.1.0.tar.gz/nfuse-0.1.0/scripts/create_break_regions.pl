#!/usr/bin/perl

use strict;
use warnings FATAL => qw( all );
use Getopt::Std;
use Getopt::Long;
use File::Basename;

$| = 1;

my @usage;
push @usage, "Usage: ".basename($0)." [options] < in.sam > out.breaks\n";
push @usage, "Create breakpoint regions.\n";
push @usage, "  -h, --help      Displays this information\n";
push @usage, "  -s, --stats     Paired end alignment stats\n";

my $help;
my $stats_filename;

GetOptions
(
	'help'        => \$help,
	'stats=s'     => \$stats_filename,
);

not defined $help or die "@usage";

defined $stats_filename or die "@usage";


# Read in the read stats
my %stat_values;
open RS, $stats_filename or die "Error: Unable to open $stats_filename\n";
while (<RS>)
{
	chomp;
	my ($key,$value) = split /\s*=\s*/;
	
	next if not defined $key or not defined $value;
	
	$stat_values{$key} = $value;
}
close RS;

my $read_length_min = $stat_values{"Read length min"};
my $read_length_max = $stat_values{"Read length max"};
my $fragment_mean = $stat_values{"Fragment mean"};
my $fragment_stddev = $stat_values{"Fragment stddev"};

my $max_frag_length = int($fragment_mean + 3 * $fragment_stddev);

my $linenumber = 0;
while (<>)
{
	my $line = $_;
	$linenumber++;

	chomp;
	next if /^\@/;

	my @sam_info = split /\t/;
	
	my $qname = $sam_info[0];
	my $flag = $sam_info[1];
	my $rname = $sam_info[2];
	my $pos = $sam_info[3];
	my $mapq = $sam_info[4];
	my $cigar = $sam_info[5];
	my $mrnm = $sam_info[6];
	my $mpos = $sam_info[7];
	my $isize = $sam_info[8];
	my $seq = $sam_info[9];
	my $qual = $sam_info[10];
	my $opt = $sam_info[11];

	if ($flag & hex('0x0010'))
	{
		$pos = -$pos;
	}
	
	my $breakstart = $pos + length($seq);
	my $breakend = $pos + $max_frag_length - 1 - length($seq);

	print $linenumber."\t".$breakstart."\t".$breakend."\n";
}

