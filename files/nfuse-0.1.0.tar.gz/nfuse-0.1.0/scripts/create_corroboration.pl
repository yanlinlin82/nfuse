#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';

my $paths_filename = shift;
my $cycles_filename = shift;
my $readthroughs_filename = shift;

defined $readthroughs_filename or die "Usage: $0 paths_filename cycles_filename readthroughs_filename\n";

my %paths;
read_paths($paths_filename, \%paths);

my @cycles;
read_cycles($cycles_filename, \@cycles);

my %readthroughs;
read_readthroughs($readthroughs_filename, \%readthroughs);

foreach my $rna_cluster_id (keys %paths)
{
	my @dna_cluster_ids = keys %{$paths{$rna_cluster_id}};

	print $rna_cluster_id."\t";

	foreach my $dna_cluster_index (0..$#dna_cluster_ids)
	{
		print $dna_cluster_ids[$dna_cluster_index];
		print "\t" unless $dna_cluster_index == $#dna_cluster_ids;
	}
	print "\n";
}

foreach my $cycle (@cycles)
{
	print "\t";
	
	my @dna_cluster_ids = @{$cycle};
	
	foreach my $dna_cluster_index (0..$#dna_cluster_ids)
	{
		print $dna_cluster_ids[$dna_cluster_index];
		print "\t" unless $dna_cluster_index == $#dna_cluster_ids;
	}
	print "\n";
}

foreach my $rna_cluster_id (keys %readthroughs)
{	
	print $rna_cluster_id."\n";
}

sub read_paths
{
	my $paths_filename = shift;
	my $paths_ref = shift;

	open PA, $paths_filename or die "Error: Unable to open $paths_filename: $!\n";
	while (<PA>)
	{
		chomp;
		my @fields = split /\t/;
		
		my $score = shift @fields;
		
		my $rna_cluster_id = shift @fields;
		
		while (scalar @fields > 0)
		{
			my $dna_cluster_id1 = shift @fields;
			my $dna_cluster_end1 = shift @fields;
			my $dna_cluster_id2 = shift @fields;
			my $dna_cluster_end2 = shift @fields;
			
			$dna_cluster_id1 == $dna_cluster_id2 or die;
			$dna_cluster_end1 != $dna_cluster_end2 or die;
			
			$paths_ref->{$rna_cluster_id}{$dna_cluster_id1} = 1;
		}
	}
	close PA;
}

sub read_cycles
{
	my $cycles_filename = shift;
	my $cycles_ref = shift;

	open CY, $cycles_filename or die "Error: Unable to open $cycles_filename: $!\n";
	while (<CY>)
	{
		chomp;
		my @fields = split /\t/;
		
		my $score = shift @fields;
		
		my %dna_cluster_ids;
		while (scalar @fields > 0)
		{
			my $dna_cluster_id = shift @fields;
			my $dna_cluster_end = shift @fields;
			
			$dna_cluster_ids{$dna_cluster_id} = 1;
		}
		
		push @{$cycles_ref}, [keys %dna_cluster_ids];
	}
	close CY;
}

sub read_readthroughs
{
	my $readthroughs_filename = shift;
	my $readthroughs_ref = shift;

	open RT, $readthroughs_filename or die "Error: Unable to open $readthroughs_filename: $!\n";
	while (<RT>)
	{
		chomp;
		
		$readthroughs_ref->{$_} = 1;
	}
	close RT;
}

