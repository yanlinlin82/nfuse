import optparse
import os
import sys
import string

usage = """usage: %prog [options] concordant_sam reads_fastq_1 reads_fastq_2 > discordant_fastq"""

parser = optparse.OptionParser(usage)
(options, args) = parser.parse_args()

if len(args) < 1:
	parser.error("incorrect number of arguments")

concordantSam = args[0]
readsFastq1Filename = args[1]
readsFastq2Filename = args[2]

concordant = set()
for samLine in open(concordantSam,'r'):
	if samLine[0] == "@":
		continue
	samRow = samLine.rstrip().split('\t')
	readid = int(samRow[0].split('/')[0])
	flag = int(samRow[1])
	if flag & 0x0002:
		concordant.add(readid)

readsFastq1 = open(readsFastq1Filename,'r')
readsFastq2 = open(readsFastq2Filename,'r')

fastqLines = [[],[]]
for fastq1Line,fastq2Line in zip(readsFastq1,readsFastq2):
	fastqLines[0].append(fastq1Line.rstrip())
	fastqLines[1].append(fastq2Line.rstrip())
	if len(fastqLines[0]) == 4:
		readid = int(fastqLines[0][0][1:].split("/")[0])
		if readid not in concordant:
			for readend in (0,1):
				for line in fastqLines[readend]:
					print line
		fastqLines = [[],[]]
	
