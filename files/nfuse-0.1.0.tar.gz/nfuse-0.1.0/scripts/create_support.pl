#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';

my $dna_rna_overlap_filename = shift;
my $cycles_filename = shift;
my $paths_filename = shift;
my $readthroughs_filename = shift;

defined $readthroughs_filename or die "Usage: $0 dna_rna_overlap_filename cycles_filename paths_filename readthroughs_filename\n";

my %dna_rna_overlap;
my %rna_dna_overlap;
read_overlap($dna_rna_overlap_filename, \%dna_rna_overlap, \%rna_dna_overlap);

my %cycles;
read_cycles($cycles_filename, \%cycles);

my %paths;
read_paths($paths_filename, \%paths);

my %readthroughs;
read_readthroughs($readthroughs_filename, \%readthroughs);

foreach my $rna_cluster_id (keys %rna_dna_overlap)
{
	foreach my $dna_cluster_id (keys %{$rna_dna_overlap{$rna_cluster_id}})
	{
		print $dna_cluster_id."\t".$rna_cluster_id."\n";

		foreach my $cycle_dna_cluster_id (keys %{$cycles{$dna_cluster_id}})
		{
			print $cycle_dna_cluster_id."\t".$rna_cluster_id."\n";
		}
	}
}

foreach my $rna_cluster_id (keys %paths)
{
	foreach my $dna_cluster_id (keys %{$paths{$rna_cluster_id}})
	{
		print $dna_cluster_id."\t".$rna_cluster_id."\n";
	}
}

foreach my $rna_cluster_id (keys %readthroughs)
{	
	print "\t".$rna_cluster_id."\n";
}

sub read_overlap
{
	my $overlaps_filename = shift;
	my $dna_rna_overlaps_ref = shift;
	my $rna_dna_overlaps_ref = shift;

	open OV, $overlaps_filename or die "Error: Unable to open $overlaps_filename: $!\n";
	while (<OV>)
	{
		chomp;
		my ($dna_cluster_id,$rna_cluster_id) = split /\t/;

		$dna_rna_overlaps_ref->{$dna_cluster_id}{$rna_cluster_id} = 1;
		$rna_dna_overlaps_ref->{$rna_cluster_id}{$dna_cluster_id} = 1;
	}
	close OV;
}

sub read_cycles
{
	my $cycles_filename = shift;
	my $cycles_ref = shift;

	open CY, $cycles_filename or die "Error: Unable to open $cycles_filename: $!\n";
	while (<CY>)
	{
		chomp;
		my @fields = split /\t/;
		
		my $score = shift @fields;
		
		my @dna_cluster_ids;
		while (scalar @fields > 0)
		{
			my $dna_cluster_id = shift @fields;
			my $dna_cluster_end = shift @fields;
			
			push @dna_cluster_ids, $dna_cluster_id;
		}
		
		foreach my $cluster_id1 (@dna_cluster_ids)
		{
			foreach my $cluster_id2 (@dna_cluster_ids)
			{
				$cycles_ref->{$cluster_id1}{$cluster_id2} = 1;
			}
		}
	}
	close CY;
}

sub read_paths
{
	my $paths_filename = shift;
	my $paths_ref = shift;

	open PA, $paths_filename or die "Error: Unable to open $paths_filename: $!\n";
	while (<PA>)
	{
		chomp;
		my @fields = split /\t/;
		
		my $score = shift @fields;
		
		my $rna_cluster_id = shift @fields;
		
		while (scalar @fields > 0)
		{
			my $dna_cluster_id1 = shift @fields;
			my $dna_cluster_end1 = shift @fields;
			my $dna_cluster_id2 = shift @fields;
			my $dna_cluster_end2 = shift @fields;
			
			$dna_cluster_id1 == $dna_cluster_id2 or die;
			$dna_cluster_end1 != $dna_cluster_end2 or die;
			
			$paths_ref->{$rna_cluster_id}{$dna_cluster_id1} = 1;
		}
	}
	close PA;
}

sub read_readthroughs
{
	my $readthroughs_filename = shift;
	my $readthroughs_ref = shift;

	open RT, $readthroughs_filename or die "Error: Unable to open $readthroughs_filename: $!\n";
	while (<RT>)
	{
		chomp;
		
		$readthroughs_ref->{$_} = 1;
	}
	close RT;
}

