#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;

my @usage;
push @usage, "Usage: $0 [options]\n";
push @usage, "Divide alignments by chromosome pair.\n";
push @usage, "  -h, --help      Displays this information\n";
push @usage, "  -p, --prefix    Prefix for divided files\n";
push @usage, "  -m, --mtchr     Mitochondrial chromosome\n";
push @usage, "  -c, --cdnachr   cDNA chromosome map (optional)\n";

my $help;
my $output_prefix;
my $mt_chr;
my $cdna_chr_filename;

GetOptions
(
	'help'        => \$help,
	'prefix=s'    => \$output_prefix,
	'mtchr=s'     => \$mt_chr,
	'cdnachr=s'   => \$cdna_chr_filename,
);

not defined $help or die @usage;

defined $output_prefix or die @usage;
defined $mt_chr or die @usage;

my %cdna_chr;

if (defined $cdna_chr_filename)
{
	open CCHR, $cdna_chr_filename or die "Error: Unable to open $cdna_chr_filename: $!\n";
	while (<CCHR>)
	{
		chomp;
		my @fields = split /\t/;
		$cdna_chr{$fields[0]} = $fields[1];
	}
	close CCHR;
}

my %alignment_buffer;
my %output_filename;

my $max_cached = 10000;

sub flush
{
	my $chr1 = shift;
	my $chr2 = shift;
	
	my $filename = $output_prefix.$chr1."-".$chr2;
	
	if (not defined $output_filename{$chr1}{$chr2})
	{
		unlink $filename;
	}
	
	$output_filename{$chr1}{$chr2} = $filename;
	
	open OUT, ">>".$filename or die "Error: Unable to write to $filename\n $!\n";
	foreach my $line (@{$alignment_buffer{$chr1}{$chr2}})
	{
		print OUT $line;
	}
	close OUT;
	
	@{$alignment_buffer{$chr1}{$chr2}} = ();
}

sub output
{
	my $chr1 = shift;
	my $chr2 = shift;
	my $alignment = shift;
	
	push @{$alignment_buffer{$chr1}{$chr2}}, $alignment;
	
	if (scalar @{$alignment_buffer{$chr1}{$chr2}} > $max_cached)
	{
		flush($chr1,$chr2);
	}
}

sub process_alignments
{
	my $alignments_ref = shift;
	
	if (scalar keys %{$alignments_ref} < 2)
	{
		return;
	}
	
	foreach my $chr1 (keys %{$alignments_ref->{"0"}})
	{
		foreach my $chr2 (keys %{$alignments_ref->{"1"}})
		{
			next if $chr1 ne $chr2 and ($chr1 eq $mt_chr or $chr2 eq $mt_chr);
			
			my ($chr1_sorted,$chr2_sorted) = sort ($chr1,$chr2);
			
			foreach my $alignment (@{$alignments_ref->{"0"}{$chr1}})
			{
				output($chr1_sorted, $chr2_sorted, $alignment);
			}
			foreach my $alignment (@{$alignments_ref->{"1"}{$chr2}})
			{
				output($chr1_sorted, $chr2_sorted, $alignment);
			}
		}
	}
}

my $current_fragment_id;
my %current_alignments;
while (<>)
{
	my $line = $_;
	
	chomp;
	my @fields = split /\t/, $line;
	
	my $fragment_id = $fields[0];
	my $read_end = $fields[1];
	my $ref_name = $fields[2];
	
	my $chr = $ref_name;
	if (defined $cdna_chr{$ref_name})
	{
		$chr = $cdna_chr{$ref_name};
	}
	
	if (defined $current_fragment_id and $current_fragment_id ne $fragment_id)
	{
		process_alignments(\%current_alignments);
		%current_alignments = ();
	}
	
	$current_fragment_id = $fragment_id;
	push @{$current_alignments{$read_end}{$chr}}, $line;
}

if (defined $current_fragment_id)
{
	process_alignments(\%current_alignments);
}

foreach my $chr1 (sort keys %alignment_buffer)
{
	foreach my $chr2 (sort keys %{$alignment_buffer{$chr1}})
	{
		flush($chr1,$chr2);
		print $chr1."\t".$chr2."\t".$output_filename{$chr1}{$chr2}."\n";
	}
}


