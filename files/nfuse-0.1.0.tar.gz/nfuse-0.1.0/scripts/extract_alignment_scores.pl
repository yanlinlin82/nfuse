#!/usr/bin/perl

use strict;
use warnings;
use List::Util qw[min max];

my $current_fragment_id;
my %scores;
while (<>)
{
	chomp;
	my @fields = split /\t/;

	my $fragment_id = $fields[0];
	my $read_end = $fields[1];
	my $aligned_length = $fields[7];
	my $score = $fields[8];
	
	if (defined $current_fragment_id and $current_fragment_id != $fragment_id)
	{
		foreach my $read_end ("0","1")
		{
			my $max_score = max(keys %{$scores{$read_end}});
			print $scores{$read_end}{$max_score}."\t".$max_score."\n";
		}

		%scores = ();
	}
	
	$scores{$read_end}{$score} = $aligned_length;
	
	$current_fragment_id = $fragment_id;
}

if (defined $current_fragment_id)
{
	foreach my $read_end ("0","1")
	{
		my $max_score = max(keys %{$scores{$read_end}});
		print $scores{$read_end}{$max_score}."\t".$max_score."\n";
	}
}
