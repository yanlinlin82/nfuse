#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';

while (<>)
{
	chomp;
	next if /^\@/;

	my @sam_info = split /\t/;
	
	my $flag = $sam_info[1];
	my $seq = $sam_info[9];
	
	next if $flag & hex('0x0004');
	
	my $align_score;
	foreach my $opt_index (11 .. $#sam_info)
	{
		if ($sam_info[$opt_index] =~ /^AS:i:(-?\d+)$/)
		{
			$align_score = $1;
		}
	}
	
	my $read_length = length($seq);
	
	print $read_length."\t".$align_score."\n";
}

