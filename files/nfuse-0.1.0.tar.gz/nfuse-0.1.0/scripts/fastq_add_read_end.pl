#!/usr/bin/perl

use strict;
use warnings;

my $read_end = shift;

die "Usage: $0 [1|2]\n" if not defined $read_end or $read_end !~ /^[12]$/;

while (1)
{
	my $readid = <>;
	my $sequence = <>;
	my $comment = <>;
	my $quality = <>;

	last if not defined $quality;

	chomp($readid);
	chomp($sequence);
	chomp($comment);
	chomp($quality);

	print $readid."/".$read_end."\n";
	print $sequence."\n";
	print $comment."\n";
	print $quality."\n";
}

