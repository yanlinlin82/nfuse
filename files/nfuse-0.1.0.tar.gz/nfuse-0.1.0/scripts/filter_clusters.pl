#!/usr/bin/perl

use strict;
use warnings;

my $in_cluster_filename = shift;
my $in_cluster_prob_filename = shift;
my $out_cluster_filename = shift;
my $out_cluster_prob_filename = shift;
my $threshold = shift;

defined $threshold or die "Usage: $0 in_cluster in_cluster_prob out_cluster out_cluster_prob threshold\n";

my %cluster_ids;

open OCP, ">".$out_cluster_prob_filename or die;
open ICP, $in_cluster_prob_filename or die;
while (<ICP>)
{
	chomp;
	my @fields = split /\t/;
	
	if ($fields[1] >= $threshold)
	{
		$cluster_ids{$fields[0]} = 1;
		print OCP $_."\n";
	}
}
close OCP;
close ICP;

open OCL, ">".$out_cluster_filename or die;
open ICL, $in_cluster_filename or die;
while (<ICL>)
{
	chomp;
	my @fields = split /\t/;
	
	if (defined $cluster_ids{$fields[0]})
	{
		print OCL $_."\n";
	}
}
close OCL;
close ICL;


