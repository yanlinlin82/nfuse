#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';

my $dna_clusters_sc_filename = shift;
my $rna_clusters_sc_filename = shift;

defined $rna_clusters_sc_filename or die "Usage: $0 dna_clusters_sc rna_clusters_sc < corroboration_in > corroboration_out\n";

sub read_cluster_ids
{
	my $clusters_filename = shift;
	my $clusters_ids_ref = shift;

	open CLU, $clusters_filename or die "Error: Unable to open $clusters_filename: $!\n";
	while (<CLU>)
	{
		chomp;
		my @fields = split /\t/;
		
		my $cluster_id = $fields[0];
		$clusters_ids_ref->{$cluster_id} = 1;
	}
	close CLU;
}

my %dna_cluster_sc_ids;
read_cluster_ids($dna_clusters_sc_filename,\%dna_cluster_sc_ids);

my %rna_cluster_sc_ids;
read_cluster_ids($rna_clusters_sc_filename,\%rna_cluster_sc_ids);

while (<>)
{
	my $line = $_;
	
	chomp;
	my @fields = split /\t/;
	my $rna_cluster_id = shift @fields;
	my @dna_cluster_ids = @fields;
	
	next if $rna_cluster_id ne "" and not defined $rna_cluster_sc_ids{$rna_cluster_id};
	
	my $filtered = 0;
	foreach my $dna_cluster_id (@dna_cluster_ids)
	{
		if (not defined $dna_cluster_sc_ids{$dna_cluster_id})
		{
			$filtered = 1;
			last;
		}
	}
	
	next if $filtered;
	
	print $line;
}

