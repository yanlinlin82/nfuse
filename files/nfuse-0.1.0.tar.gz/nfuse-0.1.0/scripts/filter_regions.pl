#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use List::Util qw[min max];

my $regions_filename = shift;

die "Usage: $0 regions_filename < in > out\n" if not defined $regions_filename;

# Read in regions
my @regions;
my $length_sum = 0;
open REG, $regions_filename or die "Error: Unable to open $regions_filename: $!\n";
while (<REG>)
{
	chomp;
	my ($chromosome,$start,$end) = split /\t/;
	
	push @regions, [$chromosome,$start,$end];
	$length_sum += $end - $start;
}
close REG;
my $length_mean = $length_sum / scalar @regions;

# Bin spacing so that most regions are contained in only a few bins
my $bin_spacing = $length_mean * 5;

# Binning for gene lookup
my %binned_regions;
foreach my $region (@regions)
{
	foreach my $bin (get_bins($region->[1],$region->[2]))
	{
		push @{$binned_regions{$region->[0]}{$bin}}, [$region->[1],$region->[2]];
	}
}

# Read sam from stdin and write contained to stdout
while (<>)
{
	my $line = $_;

	chomp;
	next if /^\@/;

	my @sam_info = split /\t/;
	
	my $qname = $sam_info[0];
	my $flag = $sam_info[1];
	my $rname = $sam_info[2];
	my $pos = $sam_info[3];
	my $mapq = $sam_info[4];
	my $cigar = $sam_info[5];
	my $mrnm = $sam_info[6];
	my $mpos = $sam_info[7];
	my $isize = $sam_info[8];
	my $seq = $sam_info[9];
	my $qual = $sam_info[10];
	my $opt = $sam_info[11];

	my $start = $pos;
	my $end = $pos + length($seq) - 1;

	my $align = [$start,$end];
	
	my $contained = 0;
	foreach my $bin (get_bins($start,$end))
	{
		foreach my $region (@{$binned_regions{$rname}{$bin}})
		{
			if (contains($region,$align))
			{
				$contained = 1;
				last;
			}
		}
		
		if ($contained)
		{
			last;
		}
	}

	if ($contained)
	{
		print $line;
	}
}

# Calculate bins overlapped by a region
sub get_bins
{
	my $start = shift;
	my $end = shift;
	
	my $start_bin = int($start / $bin_spacing);
	my $end_bin = int($end / $bin_spacing);
	
	return ($start_bin .. $end_bin);
}

# Check for overlap between regions
sub overlap
{
	my $region1 = $_[0];
	my $region2 = $_[1];
	
	if ($region1->[1] < $region2->[0] or $region1->[0] > $region2->[1])
	{
		return 0;
	}
	else
	{
		return 1;
	}
}

# Check for overlap between regions
sub contains
{
	my $region1 = $_[0];
	my $region2 = $_[1];
	
	if ($region2->[0] >= $region1->[0] and $region2->[1] <= $region1->[1])
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
