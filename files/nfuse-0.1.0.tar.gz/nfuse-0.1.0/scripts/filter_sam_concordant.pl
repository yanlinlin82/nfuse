#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';

my $usage = "Usage: $0 < sam > paired_sam\n";

my $current_fragment_id;
my %current_read_ends;
my @current_lines;
while (<>)
{
	my $line = $_;
	
	my @sam_fields = split /\t/;
	
	my $fragment_id = $sam_fields[0];
	my $flag = $sam_fields[1];
	
	next unless $flag & hex('0x0002');
	
	my $read_end;
	if ($flag & hex('0x0040'))
	{
		$read_end = 1;
	}
	
	if ($flag & hex('0x0080'))
	{
		$read_end = 2;
	}
	
	if (defined $current_fragment_id and $fragment_id ne $current_fragment_id)
	{
		if (keys %current_read_ends == 2)
		{
			print @current_lines;
		}
		
		%current_read_ends = ();
		@current_lines = ();
	}
	
	$current_fragment_id = $fragment_id;
	$current_read_ends{$read_end} = 1;
	push @current_lines, $line;
}

if (defined $current_fragment_id)
{
	if (keys %current_read_ends == 2)
	{
		print @current_lines;
	}
}

