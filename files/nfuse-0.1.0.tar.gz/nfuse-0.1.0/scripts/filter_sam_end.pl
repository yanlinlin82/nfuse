#!/usr/bin/perl

use strict;
use warnings FATAL => qw( all );

my $usage = "Usage: $0 read_end\n";

my $read_end = shift;

die $usage if not defined $read_end;

while (my $line = <>)
{
	chomp($line);

	next if $line =~ /^\@/;

	my @sam_fields = split /\t/, $line;

	my $sam_flag = $sam_fields[1];

	my $sam_read_end;
	if ($sam_flag & hex('0x0040'))
	{
		$sam_read_end = "1";
	}
	elsif ($sam_flag & hex('0x0080'))
	{
		$sam_read_end = "2";
	}

	if ($sam_read_end eq $read_end)
	{
		print $line."\n";
	}
}

