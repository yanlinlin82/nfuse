#!/usr/bin/perl

use strict;
use warnings FATAL => qw( all );

my $usage = "Usage: $0 max_alignments\n";

my $max_alignments = shift;

die $usage if not defined $max_alignments;

my %counts;
while (my $line = <>)
{
	chomp($line);

	next if $line =~ /^\@/;

	my @sam_fields = split /\t/, $line;

	my $read_id = $sam_fields[0];
	
	$counts{$read_id}++;
}

foreach my $read_id (keys %counts)
{
	print $read_id."\n" if defined $counts{$read_id} and $counts{$read_id} > $max_alignments;
}

