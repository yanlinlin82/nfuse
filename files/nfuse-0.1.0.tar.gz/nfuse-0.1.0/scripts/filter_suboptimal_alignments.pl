#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use List::Util qw[min max];

my $match_score = 2;
my $gap_open_score = 5;
my $gap_extension_score = 3;

my $max_alignments = shift;
my $diff_from_best = shift;

defined $diff_from_best or die "Usage: $0 max_alignments diff_from_best < alignments > filtered_alignments\n";

sub process_lines
{
	my $scores_ref = shift;
	my $lines_ref = shift;
	
	foreach my $read_end ("0","1")
	{
		my $max_score = max(@{$scores_ref->{$read_end}});
		
		my @max_score_lines;
		foreach my $line_index (0..$#{$lines_ref->{$read_end}})
		{
			my $score = $scores_ref->{$read_end}[$line_index];
			
			if ($score >= $max_score - $diff_from_best)
			{
				push @max_score_lines, $lines_ref->{$read_end}[$line_index];
			}
		}

		if (scalar @max_score_lines <= $max_alignments)
		{
			print @max_score_lines;
		}
	}
}

my $current_fragment_id;
my %current_scores;
my %current_lines;
while (<>)
{
	my $line = $_;

	chomp;
	next if /^\@/;

	my @sam_info = split /\t/;
	
	my $qname = $sam_info[0];
	my $flag = $sam_info[1];
	my $rname = $sam_info[2];
	my $pos = $sam_info[3];
	my $mapq = $sam_info[4];
	my $cigar = $sam_info[5];
	my $mrnm = $sam_info[6];
	my $mpos = $sam_info[7];
	my $isize = $sam_info[8];
	my $seq = $sam_info[9];
	my $qual = $sam_info[10];
	
	next if $flag & hex('0x0004');
	
	$qname =~ /^(\d+)\/([12])/;
	my $fragment_id = $1;
	my $read_end = $2 - 1;
	
	my $score;
	foreach my $opt_index (11 .. $#sam_info)
	{
		if ($sam_info[$opt_index] =~ /^AS:i:(-?\d+)$/)
		{
			$score = $1;
		}
	}
	
	my $start_gap = 0;
	if ($cigar =~ /^(\d+)S/)
	{
		$start_gap = $1;
	}
	
	my $end_gap = 0;
	if ($cigar =~ /(\d+)S$/)
	{
		$end_gap = $1;
	}
	
	my $strand = "+";
	if ($flag & hex('0x0010'))
	{
		$strand = "-";
	}
	
	if ($strand eq "+")
	{
		if ($start_gap > 0)
		{
			$score -= $gap_open_score + $gap_extension_score * $start_gap;
		}
	}
	else
	{
		if ($end_gap > 0)
		{
			$score -= $gap_open_score + $gap_extension_score * $end_gap;
		}
	}
	
	if (defined $current_fragment_id and $fragment_id != $current_fragment_id)
	{
		process_lines(\%current_scores, \%current_lines);
		
		%current_scores = ();
		%current_lines = ();
	}
	
	$current_fragment_id = $fragment_id;
	push @{$current_scores{$read_end}}, $score;
	push @{$current_lines{$read_end}}, $line;
}

if (defined $current_fragment_id)
{
	process_lines(\%current_scores, \%current_lines);
}

