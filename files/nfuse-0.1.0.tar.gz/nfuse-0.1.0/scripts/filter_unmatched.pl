#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';

my $usage = "Usage: $0 alignments > matched_alignments\n";

my $current_fragment_id;
my %current_read_ends;
my @current_lines;
while (my $line = <>)
{
	my @fields = split /\t/, $line;
	
	my $fragment_id = $fields[0];
	my $read_end = $fields[1];
	
	if (defined $current_fragment_id and $fragment_id != $current_fragment_id)
	{
		if (keys %current_read_ends == 2)
		{
			print @current_lines;
		}
		
		%current_read_ends = ();
		@current_lines = ();
	}
	
	$current_fragment_id = $fragment_id;
	$current_read_ends{$read_end} = 1;
	push @current_lines, $line;
}

if (defined $current_fragment_id)
{
	if (keys %current_read_ends == 2)
	{
		print @current_lines;
	}
}

