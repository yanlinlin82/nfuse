#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use File::Basename;
use List::Util qw[min max];

use lib dirname($0);
use gene_models;

my $concordant_length = shift;

defined $concordant_length or die "Usage: $0 concordant_length < sam_alignments > concordant_readids\n";

# Calculate bins overlapped by a region
sub get_bins
{
	my $region_ref = shift;
	my $bin_spacing = shift;

	my $start = $region_ref->[0];
	my $end = $region_ref->[1];
	
	my $start_bin = int($start / $bin_spacing);
	my $end_bin = int($end / $bin_spacing);
	
	return ($start_bin .. $end_bin);
}

my %alignments;

while (<>)
{
	next if /^\@/;

	chomp;
	my @fields = split /\t/;

	my $flag = $fields[1];

	next if ($flag & hex('0x0004'));

	my $readid = $fields[0];
	my $chromosome = $fields[2];
	my $pos = $fields[3];
	my $seq = $fields[9];
	
	$readid =~ /^(.*)\/([12])$/ or die "Fastq error, unable to interpret readid $readid\n";
	my $fragment = $1;
	my $read_end = $2;
	
	my $strand;
	if ($flag & hex('0x0010'))
	{
		$strand = "-";
	}
	else
	{
		$strand = "+";
	}
	
	my $start = $pos;
	my $end = $pos + length($seq) - 1;
	my $alignment = [$start, $end, $strand];
	
	push @{$alignments{$fragment}{$read_end}{$chromosome}}, $alignment;
}

foreach my $fragment (keys %alignments)
{
	my $concordant = 0;
	
	foreach my $chromosome (keys %{$alignments{$fragment}{"1"}})
	{
		next unless defined $alignments{$fragment}{"2"}{$chromosome};
		
		my %align_bins;
		foreach my $alignment (@{$alignments{$fragment}{"1"}{$chromosome}})
		{
			foreach my $bin (get_bins($alignment, $concordant_length))
			{
				push @{$align_bins{$bin}}, $alignment;
			}
		}
		
		foreach my $alignment (@{$alignments{$fragment}{"2"}{$chromosome}})
		{
			my $search_region = [$alignment->[0], $alignment->[1]];
			
			if ($alignment->[2] eq "+")
			{
				$search_region->[1] = $search_region->[1] + $concordant_length;
			}
			else
			{
				$search_region->[0] = $search_region->[0] - $concordant_length;
			}
			
			foreach my $bin (get_bins($search_region, $concordant_length))
			{
				foreach my $other_alignment (@{$align_bins{$bin}})
				{
					if ($alignment->[2] eq "+" and $other_alignment->[2] eq "-" and
					    $alignment->[0] < $other_alignment->[1] and 
					    $other_alignment->[0] - $alignment->[0] < $concordant_length)
					{
						$concordant = 1;
					}
					
					if ($other_alignment->[2] eq "+" and $alignment->[2] eq "-" and
					    $other_alignment->[0] < $alignment->[1] and 
					    $alignment->[0] - $other_alignment->[0] < $concordant_length)
					{
						$concordant = 1;
					}
					
					last if $concordant;
				}
				
				last if $concordant;
			}
			
			last if $concordant;
		}
		
		last if $concordant;
	}
	
	if ($concordant)
	{
		print $fragment."\n";
	}
}
	
