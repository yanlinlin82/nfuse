args <- commandArgs(TRUE)

require("MASS")

samples = read.table(file("stdin"))

fit = fitdistr(samples$V1[samples$V1>=1]-1,"negative binomial")

size = fit$estimate[["size"]]
prob = fit$estimate[["size"]]/(fit$estimate[["size"]]+fit$estimate[["mu"]])

parameters <- data.frame(size=size,prob=prob)

write.table(parameters, stdout(), quote=F, sep="\t", eol="\n", row.names=F, col.names=T)

