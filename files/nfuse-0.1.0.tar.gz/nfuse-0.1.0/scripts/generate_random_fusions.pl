#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use List::Util qw[min max];

use lib dirname($0);
use gene_models;

use lib dirname($0)."/../external/BioPerl-1.6.1";
use Bio::DB::Fasta;
use Bio::SeqIO;

my $input_gene_models = shift;
my $input_reference_fasta = shift;
my $transcripts_fasta = shift;
my $breakpoints_fasta = shift;
my $fusion_boundaries = shift;
my $breakpoint_positions = shift;

defined $breakpoint_positions or die "Usage: $0 input_gene_models input_reference_fasta transcripts_fasta breakpoints_fasta fusion_boundaries breakpoint_positions\n";

srand(0);

my %chromosomes = map { $_ => 1 } split /,/, "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,X,Y,MT";
my %sources = map { $_ => 1 } split /,/, "IG_C_gene,IG_D_gene,IG_J_gene,IG_V_gene,processed_transcript,protein_coding";

my $gene_models = gene_models->new($input_gene_models);

my $reference_db = Bio::DB::Fasta->new($input_reference_fasta);

my $exon_fusions_to_simulate = 500;
my $intron_fusions_to_simulate = 500;
my $min_distance_to_edge = 100;
my $breakpoint_sequence_length = 700;
my $min_transcript_length = 500;

sub revcomp
{
        my $sequence = shift;
        my $revcomp = reverse($sequence);
        $revcomp =~ tr/ACGTacgt/TGCAtgca/;
        return $revcomp;
}

sub create_breakpoint_sequence
{
	my $chromosome = shift;
	my $strand = shift;
	my $position = shift;
	
	if ($strand eq "+")
	{
		my $seq = $reference_db->seq($chromosome, $position - $breakpoint_sequence_length + 1, $position);
		
		return $seq;
	}
	elsif ($strand eq "-")
	{
		my $seq = $reference_db->seq($chromosome, $position, $position + $breakpoint_sequence_length - 1);
		$seq = revcomp($seq);
		
		return $seq;
	}
}

open TFA, ">".$transcripts_fasta or die;
open BFA, ">".$breakpoints_fasta or die;
open FUS, ">".$fusion_boundaries or die;
open BRK, ">".$breakpoint_positions or die;

my @gene_ids = keys %{$gene_models->{genes}};

my %fusion_genes;

my $fusion_id = 0;

my $num_exon_fusions = 0;
while ($num_exon_fusions < $exon_fusions_to_simulate)
{
	my $gene_index_1 = rand_range(0,$#gene_ids);
	my $gene_id_1 = $gene_ids[$gene_index_1];
	
	my $gene_index_2 = rand_range(0,$#gene_ids);
	my $gene_id_2 = $gene_ids[$gene_index_2];
	
	next if defined $fusion_genes{$gene_id_1};
	next if defined $fusion_genes{$gene_id_2};
	next if $gene_id_1 eq $gene_id_2;
	
	my @transcript_ids_1 = keys %{$gene_models->{genes}{$gene_id_1}{transcripts}};
	my $transcript_index_1 = rand_range(0,$#transcript_ids_1);
	my $transcript_id_1 = $transcript_ids_1[$transcript_index_1];
	my $transcript_length_1 = gene_models::regions_length(@{$gene_models->{transcripts}{$transcript_id_1}{exons}});
	
	my @transcript_ids_2 = keys %{$gene_models->{genes}{$gene_id_2}{transcripts}};
	my $transcript_index_2 = rand_range(0,$#transcript_ids_2);
	my $transcript_id_2 = $transcript_ids_2[$transcript_index_2];
	my $transcript_length_2 = gene_models::regions_length(@{$gene_models->{transcripts}{$transcript_id_2}{exons}});
	
	next if $transcript_length_1 < $min_distance_to_edge * 2 + 1;
	next if $transcript_length_2 < $min_distance_to_edge * 2 + 1;
	
	next unless defined $sources{$gene_models->{transcripts}{$transcript_id_1}{source}};
	next unless defined $sources{$gene_models->{transcripts}{$transcript_id_2}{source}};
	
	my $transcript_position_1 = rand_range($min_distance_to_edge, $transcript_length_1 - $min_distance_to_edge);
	my $transcript_position_2 = rand_range($min_distance_to_edge, $transcript_length_2 - $min_distance_to_edge);
	
	my $transcript_sequence_1 = $reference_db->seq($transcript_id_1);
	my $transcript_sequence_2 = $reference_db->seq($transcript_id_2);
	
	next if not defined $transcript_sequence_1;
	next if not defined $transcript_sequence_2;
	
	my $transcript_sequence = substr $transcript_sequence_1, 0, $transcript_position_1;
	$transcript_sequence .= substr $transcript_sequence_2, $transcript_position_2 - 1;
	
	next unless length($transcript_sequence) >= $min_transcript_length;
	
	my $chromosome_1 = $gene_models->calc_genomic_chromosome($transcript_id_1);
	my $chromosome_2 = $gene_models->calc_genomic_chromosome($transcript_id_2);
	
	next unless defined $chromosomes{$chromosome_1};
	next unless defined $chromosomes{$chromosome_2};
	
	my $genomic_strand_1 = $gene_models->calc_genomic_strand($transcript_id_1, "+");
	my $genomic_strand_2 = $gene_models->calc_genomic_strand($transcript_id_2, "-");
	
	my $genomic_position_1 = $gene_models->calc_genomic_position($transcript_id_1, $transcript_position_1);
	my $genomic_position_2 = $gene_models->calc_genomic_position($transcript_id_2, $transcript_position_2);
	
	my $genomic_sequence_1 = create_breakpoint_sequence($chromosome_1, $genomic_strand_1, $genomic_position_1);
	my $genomic_sequence_2 = create_breakpoint_sequence($chromosome_2, $genomic_strand_2, $genomic_position_2);
	
	my $genomic_sequence = $genomic_sequence_1.revcomp($genomic_sequence_2);
	
	print TFA ">".$fusion_id."\n".$transcript_sequence."\n";
	print BFA ">".$fusion_id."\n".$genomic_sequence."\n";
	print FUS $fusion_id."\t".$transcript_id_1."\t+\t".$transcript_position_1."\t".$transcript_id_2."\t-\t".$transcript_position_2."\n";
	print BRK $fusion_id."\t".$chromosome_1."\t".$genomic_strand_1."\t".$genomic_position_1."\t".$chromosome_2."\t".$genomic_strand_2."\t".$genomic_position_2."\n";
	$fusion_id++;
	
	$fusion_genes{$gene_id_1} = 1;
	$fusion_genes{$gene_id_2} = 1;
	$num_exon_fusions++;
}

my $num_intron_fusions = 0;
while ($num_intron_fusions < $intron_fusions_to_simulate)
{
	my $gene_index_1 = rand_range(0,$#gene_ids);
	my $gene_id_1 = $gene_ids[$gene_index_1];
	
	my $gene_index_2 = rand_range(0,$#gene_ids);
	my $gene_id_2 = $gene_ids[$gene_index_2];
	
	next if defined $fusion_genes{$gene_id_1};
	next if defined $fusion_genes{$gene_id_2};
	next if $gene_id_1 eq $gene_id_2;
	
	my ($transcript_id_1, $genomic_position_1, $fiveprime_1, $threeprime_1) = select_intron_breakpoint();
	my ($transcript_id_2, $genomic_position_2, $fiveprime_2, $threeprime_2) = select_intron_breakpoint();
	
	next if not defined $transcript_id_1;
	next if not defined $transcript_id_2;
	
	next unless defined $sources{$gene_models->{transcripts}{$transcript_id_1}{source}};
	next unless defined $sources{$gene_models->{transcripts}{$transcript_id_2}{source}};
	
	my $transcript_sequence_1 = $reference_db->seq($transcript_id_1);
	my $transcript_sequence_2 = $reference_db->seq($transcript_id_2);
	
	next if not defined $transcript_sequence_1;
	next if not defined $transcript_sequence_2;
	
	my $transcript_position_1 = $fiveprime_1;
	my $transcript_position_2 = $threeprime_2;
	
	my $transcript_subseq_1 = substr $transcript_sequence_1, 0, $transcript_position_1;
	my $transcript_subseq_2 = substr $transcript_sequence_2, $transcript_position_2 - 1;

	next if length($transcript_subseq_1) < $min_distance_to_edge;
	next if length($transcript_subseq_2) < $min_distance_to_edge;
	
	my $transcript_sequence = $transcript_subseq_1.$transcript_subseq_2;
	
	next unless length($transcript_sequence) >= $min_transcript_length;
	
	my $chromosome_1 = $gene_models->calc_genomic_chromosome($transcript_id_1);
	my $chromosome_2 = $gene_models->calc_genomic_chromosome($transcript_id_2);
	
	next unless defined $chromosomes{$chromosome_1};
	next unless defined $chromosomes{$chromosome_2};
	
	my $genomic_strand_1 = $gene_models->calc_genomic_strand($transcript_id_1, "+");
	my $genomic_strand_2 = $gene_models->calc_genomic_strand($transcript_id_2, "-");
	
	my $genomic_sequence_1 = create_breakpoint_sequence($chromosome_1, $genomic_strand_1, $genomic_position_1);
	my $genomic_sequence_2 = create_breakpoint_sequence($chromosome_2, $genomic_strand_2, $genomic_position_2);
	
	my $genomic_sequence = $genomic_sequence_1.revcomp($genomic_sequence_2);
	
	print TFA ">".$fusion_id."\n".$transcript_sequence."\n";
	print BFA ">".$fusion_id."\n".$genomic_sequence."\n";
	print FUS $fusion_id."\t".$transcript_id_1."\t+\t".$transcript_position_1."\t".$transcript_id_2."\t-\t".$transcript_position_2."\n";
	print BRK $fusion_id."\t".$chromosome_1."\t".$genomic_strand_1."\t".$genomic_position_1."\t".$chromosome_2."\t".$genomic_strand_2."\t".$genomic_position_2."\n";
	$fusion_id++;
	
	$fusion_genes{$gene_id_1} = 1;
	$fusion_genes{$gene_id_2} = 1;
	$num_intron_fusions++;
}

close TFA;
close BFA;
close FUS;
close BRK;

sub select_intron_breakpoint
{
	my $gene_index = rand_range(0,$#gene_ids);
	my $gene_id = $gene_ids[$gene_index];
	
	my @transcript_ids = keys %{$gene_models->{genes}{$gene_id}{transcripts}};
	my $transcript_index = rand_range(0,$#transcript_ids);
	my $transcript_id = $transcript_ids[$transcript_index];
	
	my @exons = @{$gene_models->{transcripts}{$transcript_id}{exons}};
	
	my $transcript_start = $exons[0]->[0];
	my $transcript_end = $exons[$#exons]->[1];
	my $transcript_length = gene_models::regions_length(@exons);
	my $transcript_genomic_length = $transcript_end - $transcript_start + 1;
	
	return if $transcript_genomic_length < $min_distance_to_edge * 2 + 1;
	
	my $genomic_position = rand_range($transcript_start + $min_distance_to_edge, $transcript_end - $min_distance_to_edge);
	
	my $fiveprime;
	my $threeprime;
	my $local_offset = 0;
	foreach my $exon (@exons)
	{
		return if $exon->[0] <= $genomic_position and $exon->[1] >= $genomic_position;
		
		$fiveprime = $local_offset;
		$threeprime = $local_offset + 1;
		
		last if $exon->[0] > $genomic_position;
		
		$local_offset += $exon->[1] - $exon->[0] + 1;
	}
	
	if ($gene_models->{transcripts}{$transcript_id}{strand} eq "-")
	{
		($fiveprime,$threeprime) = ($transcript_length - $threeprime + 1, $transcript_length - $fiveprime + 1);
	}
	
	return ($transcript_id, $genomic_position, $fiveprime, $threeprime);
}

sub rand_range
{
	my $start = shift;
	my $end = shift;
	
	return $start + int(rand($end - $start + 1));
}

