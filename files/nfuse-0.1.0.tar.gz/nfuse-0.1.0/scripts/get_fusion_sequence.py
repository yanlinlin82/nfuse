import optparse
import csv
import os
import sys
import string

usage = """usage: %prog [options] fasta < clusters > sequences"""

parser = optparse.OptionParser(usage)
(options, args) = parser.parse_args()

if len(args) < 1:
	parser.error("incorrect number of arguments")

fastaFilename = args[0]

class fastaParser:
	def __init__(self,fastaFile):
		self.fastaFile = fastaFile
	def sequences(self):
		self.id = None
		self.sequences = []
		for line in self.fastaFile:
			line = line.rstrip()
			if len(line) == 0:
				continue
			if line[0] == ">":
				if self.id is not None:
					yield (self.id,''.join(self.sequences))
				self.id = line[1:]
				self.sequences = []
			else:
				self.sequences.append(line)
		if self.id is not None:
			yield (self.id,''.join(self.sequences))

class clustersParser:
	def __init__(self,clustersFile):
		self.clustersFile = clustersFile
	def clusters(self):
		clustersReader = csv.reader(self.clustersFile, delimiter='\t')
		self.id = None
		self.region = [[None,]*4,[None,]*4]
		self.count = 0
		for row in clustersReader:
			id =  int(row[0])
			side = int(row[1])
			chr = row[4]
			strand = row[5]
			start = int(row[6])
			end = int(row[7])
			if self.id is not None and self.id != id:
				yield (self.id,self.region,int(self.count))
				self.region = [[None,]*4,[None,]*4]
				self.count = 0
			self.id = id
			self.region[side][0] = chr
			self.region[side][1] = strand
			if not self.region[side][2]:
				self.region[side][2] = start
			if not self.region[side][3]:
				self.region[side][3] = end
			self.region[side][2] = min(self.region[side][2],start)
			self.region[side][3] = max(self.region[side][3],end)
			self.count += 0.5
		if self.id != None:
			yield (self.id,self.region,int(self.count))

def reverseComplement(sequence):
	return sequence[::-1].translate(string.maketrans('ACTGactg','TGACtgac'))

sequences = {}
for (id,seq) in fastaParser(open(fastaFilename,'r')).sequences():
	sequences[id] = seq

for cluster in clustersParser(sys.stdin).clusters():
	sequence1 = sequences[cluster[1][0][0]][cluster[1][0][2] - 1 : cluster[1][0][3]]
	sequence2 = sequences[cluster[1][1][0]][cluster[1][1][2] - 1 : cluster[1][1][3]]
	sequence = None
	if cluster[1][0][1] == "+" and cluster[1][1][1] == "-":
		sequence = sequence1 + "N" + sequence2;
	elif cluster[1][0][1] == "-" and cluster[1][1][1] == "+":
		sequence = sequence2 + "N" + sequence1;
	elif cluster[1][0][1] == "-" and cluster[1][1][1] == "-":
		sequence = reverseComplement(sequence1) + "N" + sequence2;
	elif cluster[1][0][1] == "+" and cluster[1][1][1] == "+":
		sequence = sequence1 + "N" + reverseComplement(sequence2);
	print "%d\t%s\t%d" % (cluster[0],sequence,cluster[2])

