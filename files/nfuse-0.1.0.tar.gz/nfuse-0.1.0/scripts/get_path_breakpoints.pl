#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';

my %unique_dna_clusters;

while (<>)
{
	chomp;
	my @fields = split /\t/;
	
	my $score = shift @fields;
	
	my $rna_cluster_id = shift @fields;
	
	while (scalar @fields > 0)
	{
		my $dna_cluster_id1 = shift @fields;
		my $dna_cluster_end1 = shift @fields;
		my $dna_cluster_id2 = shift @fields;
		my $dna_cluster_end2 = shift @fields;
		
		$dna_cluster_id1 == $dna_cluster_id2 or die;
		$dna_cluster_end1 != $dna_cluster_end2 or die;
		
		$unique_dna_clusters{$dna_cluster_id1} = 1;
	}
}

foreach my $dna_cluster_id (keys %unique_dna_clusters)
{
	print $dna_cluster_id."\n";
}

