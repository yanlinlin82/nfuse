#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use File::Spec;
use List::Util qw[min max];

use lib dirname($0);
use configdata;
use parsers;

my @usage;
push @usage, "Usage: ".basename($0)." [options]\n";
push @usage, "Retrieve reads supporting a fusion.\n";
push @usage, "  -h, --help      Displays this information\n";
push @usage, "  -c, --config    Configuration Filename\n";
push @usage, "  -o, --output    Output Directory\n";
push @usage, "  -i, --id        Cluster ID\n";

my $help;
my $config_filename;
my $output_directory;
my $query_cluster_id;

GetOptions
(
	'help'        => \$help,
	'config=s'    => \$config_filename,
	'output=s'    => \$output_directory,
	'id=s'        => \$query_cluster_id,
);

not defined $help or die @usage;

defined $config_filename or die @usage;
defined $output_directory or die @usage;

my $config = configdata->new();
$config->read($config_filename);

my $reads_prefix = $output_directory."/dna";
my $clusters_sc = $output_directory."/dna.clusters.sc";
my $spanning_alignments = $output_directory."/dna.spanning.alignments";

my %cluster_alignments;
read_cluster_alignments($clusters_sc, $query_cluster_id, \%cluster_alignments);

if (keys %cluster_alignments == 0)
{
	die "Unable to find cluster $query_cluster_id\n";
}

print "Spanning Reads:\n";
open SAL, $spanning_alignments or die "Error: Unable to open $spanning_alignments: $!\n";
while (<SAL>)
{
	my $line = $_;
	
	chomp;
	my @fields = split /\t/;
	
	my $fragment_id = $fields[0];
	my $read_end = $fields[1];
	my $ref_name = $fields[2];
	my $strand = $fields[3];
	my $start = $fields[4];
	my $end = $fields[5];
	
	my $align_key = join (":", $fragment_id, $read_end, $ref_name, $strand, $start, $end);
	
	print $cluster_alignments{$align_key} if defined $cluster_alignments{$align_key};
}
close SAL;

sub read_cluster_alignments
{
	my $clusters_filename = shift;
	my $query_cluster_id = shift;
	my $cluster_alignments_ref = shift;
	
	open CLU, $clusters_filename or die "Error: Unable to find $clusters_filename: $!\n";
	while (<CLU>)
	{
		my $line = $_;
		
		chomp;
		my @fields = split /\t/;

		my $cluster_id = $fields[0];
		my $cluster_end = $fields[1];
		my $fragment_id = $fields[2];
		my $read_end = $fields[3];
		my $ref_name = $fields[4];
		my $strand = $fields[5];
		my $start = $fields[6];
		my $end = $fields[7];
		
		next unless $cluster_id == $query_cluster_id;
		
		my $align_key = join (":", $fragment_id, $read_end, $ref_name, $strand, $start, $end);
		
		$cluster_alignments_ref->{$align_key} = $line;
	}
	close CLU;
}

