import optparse
import csv
import os
import sys
import string

usage = """usage: %prog [options] depthsamples1 depthsamples2 ... > depthsamples_merged"""

parser = optparse.OptionParser(usage)
(options, args) = parser.parse_args()

if len(args) == 0:
	parser.error("no arguments")

depthsamples_merged = []
for depthsamples_filename in args:
	with open(depthsamples_filename,'r') as depthsamples_file:
		depthsamples = [int(a.rstrip()) for a in depthsamples_file.readlines()]
		if len(depthsamples_merged) == 0:
			depthsamples_merged = depthsamples
		else:
			for index,sample in enumerate(depthsamples):
				depthsamples_merged[index] += sample

for sample in depthsamples_merged:
	print sample
