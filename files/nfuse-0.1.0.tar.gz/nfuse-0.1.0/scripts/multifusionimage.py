
import optparse
import csv
import os
import sys
import pysvg

usage = """usage: %prog [options] paths dnaclusters rnaregions genesgtf scalewidth rnaid otherrnaid1 otherrnaid2 ..."""

parser = optparse.OptionParser(usage)
(options, args) = parser.parse_args()

if len(args) < 6:
	parser.error("incorrect number of arguments")

pathsFilename = args[0]
dnaClustersFilename = args[1]
rnaRegionsFilename = args[2]
gtfFilename = args[3]
scalewidth = float(args[4])
drawRnaID = int(args[5])
otherRnaIDs = set([int(a) for a in args[6:]])

class geneModels:
	def __init__(self,gtfFile):
		self.gtfFile = gtfFile
	def genes(self):
		self.transcriptID = None
		self.geneName = None
		self.chromosome = None
		self.strand = None
		self.exons = []
		self.cds = []
		for line in self.gtfFile:
			line = line.rstrip()
			row = line.split('\t')
			chr = row[0]
			type = row[2]
			start = int(row[3])
			end = int(row[4])
			strand = row[6]
			info = {}
			for keyval in row[8].split(';'):
				keyval = keyval.strip(' ')
				if keyval == "":
					continue
				(key,value) = keyval.split(' ')
				value = value.strip('"')
				info[key] = value
			gene_id = info['gene_id']
			transcript_id = info['transcript_id']
			gene_name = info['gene_name']
			exon_number = info['exon_number']
			if self.transcriptID != None and self.transcriptID != transcript_id:
				geneStart = min([a[0] for a in self.exons])
				geneEnd = max([a[1] for a in self.exons])
				yield (self.transcriptID,self.geneName,(self.chromosome,self.strand,geneStart,geneEnd),self.exons,self.cds)
				self.exons = []
				self.cds = []
			self.transcriptID = transcript_id
			self.geneName = gene_name
			self.chromosome = chr
			self.strand = strand
			if type == "exon":
				self.exons.append((start,end))
			if type == "CDS":
				self.cds.append((start,end))
		if self.transcriptID != None:
			geneStart = min([a[0] for a in self.exons])
			geneEnd = max([a[1] for a in self.exons])
			yield (self.transcriptID,self.geneName,(self.chromosome,self.strand,geneStart,geneEnd),self.exons,self.cds)

class clustersParser:
	def __init__(self,clustersFile):
		self.clustersFile = clustersFile
	def clusters(self):
		clustersReader = csv.reader(self.clustersFile, delimiter='\t')
		self.currentId = None
		self.currentRegion = [[None,]*4,[None,]*4]
		for row in clustersReader:
			id =  int(row[0])
			side = int(row[1])
			chr = row[4]
			strand = row[5]
			start = int(row[6])
			end = int(row[7])
			if self.currentId != None and self.currentId != id:
				yield (self.currentId,self.currentRegion)
				self.currentRegion = [[None,]*4,[None,]*4]
			self.currentId = id
			self.currentRegion[side][0] = chr
			self.currentRegion[side][1] = strand
			if not self.currentRegion[side][2]:
				self.currentRegion[side][2] = start
			if not self.currentRegion[side][3]:
				self.currentRegion[side][3] = end
			self.currentRegion[side][2] = min(self.currentRegion[side][2],start)
			self.currentRegion[side][3] = max(self.currentRegion[side][3],end)
		if self.currentId != None:
			yield (self.currentId,self.currentRegion)


class regionsParser:
	def __init__(self,regionsFile):
		self.regionsFile = regionsFile
	def regions(self):
		regionsReader = csv.reader(self.regionsFile, delimiter='\t')
		self.currentId = None
		self.currentRegion = [[None,]*4,[None,]*4]
		for row in regionsReader:
			id =  int(row[0])
			side = int(row[1])
			chr = row[2]
			strand = row[3]
			start = int(row[4])
			end = int(row[5])
			if self.currentId != None and self.currentId != id:
				yield (self.currentId,self.currentRegion)
				self.currentRegion = [[None,]*4,[None,]*4]
			self.currentId = id
			self.currentRegion[side][0] = chr
			self.currentRegion[side][1] = strand
			self.currentRegion[side][2] = start
			self.currentRegion[side][3] = end
		if self.currentId != None:
			yield (self.currentId,self.currentRegion)

class pathsParser:
	def __init__(self,pathsFile):
		self.pathsFile = pathsFile
	def paths(self):
		pathsReader = csv.reader(self.pathsFile, delimiter='\t')
		for row in pathsReader:
			score = float(row[0])
			rnaID = int(row[1])
			dnaIDs = []
			for dnaID,dnaSide in zip(row[2:][::2],row[2:][1::2]):
				if dnaID == "" or dnaSide == "":
					continue
				dnaIDs.append((int(dnaID),int(dnaSide)))
			if len(dnaIDs) == 0:
				continue
			yield (rnaID, score, dnaIDs)

paths = {}
pathRnaID = {}
pathScore = {}
revPathIDs = set()
pathDnaIDs = set()
pathRnaIDs = set()
drawPathID = None

pathID = 0
for pathInfo in pathsParser(open(pathsFilename,'r')).paths():
	rnaID = pathInfo[0]
	score = pathInfo[1]
	dnaIDs = pathInfo[2]
	
	if rnaID != drawRnaID and rnaID not in otherRnaIDs:
		continue
	
	if rnaID == drawRnaID:
		drawPathID = pathID
	
	pathDnaIDs.update(set([a[0] for a in dnaIDs[::2]]))
	pathRnaIDs.add(rnaID)
	
	paths[pathID] = dnaIDs
	pathRnaID[pathID] = rnaID
	pathScore[pathID] = score
	pathID += 1
	
	revDnaIDs = list(dnaIDs)
	revDnaIDs.reverse()
	
	paths[pathID] = revDnaIDs
	pathRnaID[pathID] = rnaID
	pathScore[pathID] = score
	revPathIDs.add(pathID)
	pathID += 1

dnaRegions = {}
for region in clustersParser(open(dnaClustersFilename,'r')).clusters():
	if region[0] not in pathDnaIDs:
		continue
	dnaRegions[region[0]] = region[1]

rnaRegions = {}
for region in regionsParser(open(rnaRegionsFilename,'r')).regions():
	if region[0] not in pathRnaIDs:
		continue
	rnaRegions[region[0]] = region[1]

def fragmentdistance(region1,region2):
	if region1[0] != region2[0] or region1[1] == region2[1]:
		return None
	if region1[1] == "-":
		region1,region2 = region2,region1
	return region1[2] - region2[3]

pathInnerRegions = {}
for pathID,dnaIDs in paths.iteritems():
	pathInnerRegions[pathID] = []
	for dnaID1,dnaID2 in zip(dnaIDs[1::2], dnaIDs[2::2]):
		chr = dnaRegions[dnaID1[0]][dnaID1[1]][0]
		strand = dnaRegions[dnaID1[0]][dnaID1[1]][1]
		start = min(dnaRegions[dnaID1[0]][dnaID1[1]][2],dnaRegions[dnaID2[0]][dnaID2[1]][2])
		end = max(dnaRegions[dnaID1[0]][dnaID1[1]][3],dnaRegions[dnaID2[0]][dnaID2[1]][3])
		pathInnerRegions[pathID].append((chr,strand,start,end))

dnaIDPaths = {}
for pathID, dnaIDs in paths.iteritems():
	for dnaID in dnaIDs:
		if dnaID not in dnaIDPaths:
			dnaIDPaths[dnaID] = set()
		dnaIDPaths[dnaID].add(pathID)

def overlap(list1, list2, common):
	index1 = list1.index(common)
	index2 = list2.index(common)
	while index1 >= 0 and index2 >= 0:
		if list1[index1] != list2[index2]:
			return False
		index1 -= 1
		index2 -= 1
	index1 = list1.index(common)
	index2 = list2.index(common)
	while index1 < len(list1) and index2 < len(list2):
		if list1[index1] != list2[index2]:
			return False
		index1 += 1
		index2 += 1
	return True

def listcontains(list1, list2):
	if list2[0] not in list1:
		return False
	index1 = list1.index(list2[0])
	index2 = 0
	while index2 < len(list2):
		if index1 >= len(list1):
			return False
		if list1[index1] != list2[index2]:
			return False
		index1 += 1
		index2 += 1
	return True

def regionoverlap(region1, region2):
	if region1[0] != region2[0]:
		return None
	return not (region1[2] > region2[3] or region1[3] < region2[2])

def pathcontains(pathID1, pathID2):
	if not listcontains(paths[pathID1], paths[pathID2]):
		return False
	rnaSide1,rnaSide2 = 0,1
	if pathID2 in revPathIDs:
		rnaSide1,rnaSide2 = 1,0
	startIndex = paths[pathID1].index(paths[pathID2][0])
	if startIndex > 0:
		if not regionoverlap(pathInnerRegions[pathID1][startIndex/2-1], rnaRegions[pathRnaID[pathID2]][rnaSide1]):
			return False
	endIndex = paths[pathID1].index(paths[pathID2][-1])
	if endIndex < len(paths[pathID1]) - 1:
		if not regionoverlap(pathInnerRegions[pathID1][endIndex/2], rnaRegions[pathRnaID[pathID2]][rnaSide2]):
			return False
	return True

containMap = {}
support = {}
for dnaID, pathIDs in dnaIDPaths.iteritems():
	for pathID1 in pathIDs:
		if pathID1 not in containMap:
			containMap[pathID1] = set()
		if pathID1 not in support:
			support[pathID1] = [set([(0,len(paths[pathID1])-1)]) for a in paths[pathID1]]
		for pathID2 in pathIDs:
			if pathRnaID[pathID1] == pathRnaID[pathID2]:
				continue
			if pathcontains(pathID1, pathID2):
				containMap[pathID1].add(pathID2)
				startIndex = paths[pathID1].index(paths[pathID2][0])
				endIndex = paths[pathID1].index(paths[pathID2][-1])
				for index1 in range(startIndex, endIndex + 1):
					support[pathID1][index1].add((startIndex,endIndex))

regions = [dnaRegions[paths[drawPathID][0][0]][paths[drawPathID][0][1]]] + pathInnerRegions[drawPathID] + [dnaRegions[paths[drawPathID][-1][0]][paths[drawPathID][-1][1]]]

extendleftright = 2000

fullPathIDs = set([drawPathID])
for containedPathID in containMap[drawPathID]:
	if len(paths[containedPathID]) < len(paths[drawPathID]):
		continue
	fullPathIDs.add(containedPathID)

for fullPathID in fullPathIDs:
	if len(paths[fullPathID]) < len(paths[drawPathID]):
		continue
	rnaRegion = (rnaRegions[pathRnaID[fullPathID]][0],rnaRegions[pathRnaID[fullPathID]][1])
	if fullPathID in revPathIDs:
		rnaRegion = (rnaRegion[1],rnaRegion[0])
	if regions[0][1] == "+":
		regions[0][2] = min(regions[0][2], rnaRegion[0][2] - extendleftright)
	else:
		regions[0][3] = max(regions[0][3], rnaRegion[0][3] + extendleftright)
		
	if regions[-1][1] == "+":
		regions[-1][2] = min(regions[-1][2], rnaRegion[1][2] - extendleftright)
	else:
		regions[-1][3] = max(regions[-1][3], rnaRegion[1][3] + extendleftright)

if regions[-1][1] == "+":
	regions[-1][1] = "-"
else:
	regions[-1][1] = "+"

chrs = [a[0] for a in regions]
strands = [a[1] for a in regions]
starts = [a[2] for a in regions]
ends = [a[3] for a in regions]

exons = [set() for a in regions]
genes = [set() for a in regions]
for gene in geneModels(open(gtfFilename,'r')).genes():
	for index,region in enumerate(regions):
		if regionoverlap(gene[2],region):
			genes[index].add(gene[1])
			for exon in gene[3]:
				if exon[0] > region[3] or exon[1] < region[2]:
					continue
				trimexon = (max(exon[0],region[2]),min(exon[1],region[3]))
				exons[index].add(trimexon)

drawoffset = [0 for a in regions]
drawwidth = 0
for index,region in enumerate(regions):
	drawoffset[index] = drawwidth
	drawwidth = drawwidth + region[3] - region[2] + 1

def getdrawpos(regions,index,position):
	localstart = position - regions[index][2] + 1
	if regions[index][1] == "-":
		localstart = regions[index][3] - position + 1
	return drawoffset[index] + localstart

regionnames = ["chr%s %.1fM %s" % (a[0],(float(a[2]+a[3])/(2*1000000)),a[1]) for a in regions]

import svgwrite

svg_document = svgwrite.Drawing()#size = (drawwidth/scalewidth, 100))

horizontal_gradient = svg_document.linearGradient((0, 0), (0, 1))
svg_document.defs.add(horizontal_gradient)
horizontal_gradient.add_stop_color(0, 'rgb(0,0,255)')
horizontal_gradient.add_stop_color(0.5, 'rgb(128,128,255)')
horizontal_gradient.add_stop_color(1, 'rgb(0,0,255)')

colors = ["rgb(255,0,0)","rgb(0,255,0)","rgb(0,0,255)","rgb(255,255,0)","rgb(255,0,255)","rgb(0,255,255)","rgb(128,128,0)","rgb(128,0,128)","rgb(0,128,128)"]

for index,region in enumerate(regions):
	regionwidth = region[3] - region[2] + 1
	svg_document.add(svg_document.rect(insert = (drawoffset[index]/scalewidth, 22), size = (regionwidth/scalewidth, 4), stroke_width = 1, stroke = colors[index], fill = colors[index]))
	if index != 0:
		svg_document.add(svg_document.rect(insert = (drawoffset[index]/scalewidth, 0), size = (1, 50), stroke_width = "1", stroke = "gray", fill = "gray"))
	for geneName in genes[index]:
		svg_document.add(svg_document.text(geneName, insert = (drawoffset[index]/scalewidth + 5, 10)))
	svg_document.add(svg_document.text(regionnames[index], insert = (drawoffset[index]/scalewidth + 5, 48)))
	for exon in exons[index]:
		length = exon[1] - exon[0] + 1
		localstart = exon[0] - region[2] + 1
		if region[1] == "-":
			localstart = region[3] - exon[1] + 1
		start = drawoffset[index] + localstart
		svg_document.add(svg_document.rect(insert = (start/scalewidth, 12), size = (length/scalewidth, 24), stroke_width = 1, stroke = colors[index], fill = colors[index]))

drawRnaIDs = set([(drawRnaID,False,0,len(regions)-1)])
for containedPathID in containMap[drawPathID]:
	if pathRnaID[containedPathID] == pathRnaID[drawPathID]:
		continue
	startIndex = paths[drawPathID].index(paths[containedPathID][0]) / 2
	endIndex = paths[drawPathID].index(paths[containedPathID][-1]) / 2 + 1
	drawRnaIDs.add((pathRnaID[containedPathID],containedPathID in revPathIDs,startIndex,endIndex))

rnapos = 60
for rnaToDraw in drawRnaIDs:
	rnaRegion = (rnaRegions[rnaToDraw[0]][0],rnaRegions[rnaToDraw[0]][1])
	startEnd = (rnaToDraw[2],rnaToDraw[3])
	if rnaToDraw[1]:
		rnaRegion = (rnaRegion[1],rnaRegion[0])
	leftpos = getdrawpos(regions,startEnd[0],rnaRegion[0][3])
	rightpos = getdrawpos(regions,startEnd[1],rnaRegion[1][2])
	svg_document.add(svg_document.rect(insert = (leftpos/scalewidth - 10, rnapos), size = (10, 5), stroke_width = "1", stroke = "black", fill = "rgb(0,0,0)"))	
	svg_document.add(svg_document.rect(insert = (rightpos/scalewidth, rnapos), size = (10, 5), stroke_width = "1", stroke = "black", fill = "rgb(0,0,0)"))	
	svg_document.add(svg_document.rect(insert = (leftpos/scalewidth, rnapos + 2), size = ((rightpos-leftpos)/scalewidth, 1), stroke_width = "1", stroke = "black", fill = "rgb(0,0,0)"))	
	rnapos += 8

scalepos = rnapos + 20
svg_document.add(svg_document.rect(insert = (0,scalepos), size = (10000/scalewidth, 1), stroke_width = 1, stroke = "black", fill = "black"))		
svg_document.add(svg_document.rect(insert = (0,scalepos-5), size = (1, 5), stroke_width = 1, stroke = "black", fill = "black"))		
svg_document.add(svg_document.rect(insert = (10000/scalewidth,scalepos-5), size = (1, 5), stroke_width = 1, stroke = "black", fill = "black"))		
svg_document.add(svg_document.text("10kb", insert = (5000/scalewidth, scalepos-3)))

svg_document.viewbox(width=drawwidth/scalewidth, height=scalepos)

print(svg_document.tostring())

svg_document.save()

