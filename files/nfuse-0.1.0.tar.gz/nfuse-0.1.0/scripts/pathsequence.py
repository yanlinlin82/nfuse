
import optparse
import csv
import os
import sys
import string
import copy

usage = """usage: %prog [options] paths dnaclusters fasta [rnaids]"""

parser = optparse.OptionParser(usage)
(options, args) = parser.parse_args()

if len(args) < 3:
	parser.error("incorrect number of arguments")

pathsFilename = args[0]
dnaClustersFilename = args[1]
fastaFilename = args[2]

selectRnaIDs = set()
if len(args) > 3:
	if os.path.exists(args[3]):
		idReader = csv.reader(open(args[3], 'r'), delimiter='\t')
		for row in idReader:
			selectRnaIDs.add(int(row[0]))
	else:
		selectRnaIDs.add(int(args[3]))

extend = 1600

class fastaParser:
	def __init__(self,fastaFile):
		self.fastaFile = fastaFile
	def sequences(self):
		self.id = None
		self.sequences = []
		for line in self.fastaFile:
			line = line.rstrip()
			if len(line) == 0:
				continue
			if line[0] == ">":
				if self.id is not None:
					yield (self.id,''.join(self.sequences))
				self.id = line[1:]
				self.sequences = []
			else:
				self.sequences.append(line)
		if self.id is not None:
			yield (self.id,''.join(self.sequences))

class clustersParser:
	def __init__(self,clustersFile):
		self.clustersFile = clustersFile
	def clusters(self):
		clustersReader = csv.reader(self.clustersFile, delimiter='\t')
		self.currentId = None
		self.currentRegion = [[None,]*4,[None,]*4]
		for row in clustersReader:
			id =  int(row[0])
			side = int(row[1])
			chr = row[4]
			strand = row[5]
			start = int(row[6])
			end = int(row[7])
			if self.currentId != None and self.currentId != id:
				yield (self.currentId,self.currentRegion)
				self.currentRegion = [[None,]*4,[None,]*4]
			self.currentId = id
			self.currentRegion[side][0] = chr
			self.currentRegion[side][1] = strand
			if not self.currentRegion[side][2]:
				self.currentRegion[side][2] = start
			if not self.currentRegion[side][3]:
				self.currentRegion[side][3] = end
			self.currentRegion[side][2] = min(self.currentRegion[side][2],start)
			self.currentRegion[side][3] = max(self.currentRegion[side][3],end)
		if self.currentId != None:
			yield (self.currentId,self.currentRegion)


class pathsParser:
	def __init__(self,pathsFile):
		self.pathsFile = pathsFile
	def paths(self):
		pathsReader = csv.reader(self.pathsFile, delimiter='\t')
		for row in pathsReader:
			score = float(row[0])
			rnaID = int(row[1])
			dnaIDs = []
			for dnaID,dnaSide in zip(row[2:][::2],row[2:][1::2]):
				if dnaID == "" or dnaSide == "":
					continue
				dnaIDs.append((int(dnaID),int(dnaSide)))
			if len(dnaIDs) == 0:
				continue
			yield (rnaID, score, dnaIDs)

paths = {}
pathRnaID = {}
pathDnaIDs = set()
pathRnaIDs = set()

pathID = 0
for pathInfo in pathsParser(open(pathsFilename,'r')).paths():
	rnaID = pathInfo[0]
	score = pathInfo[1]
	dnaIDs = pathInfo[2]
	
	pathDnaIDs.update(set([a[0] for a in dnaIDs[::2]]))
	pathRnaIDs.add(rnaID)
	
	paths[pathID] = dnaIDs
	pathRnaID[pathID] = rnaID
	pathID += 1

if len(selectRnaIDs) == 0:
	selectRnaIDs = set(pathRnaIDs)

dnaRegions = {}
for region in clustersParser(open(dnaClustersFilename,'r')).clusters():
	if region[0] not in pathDnaIDs:
		continue
	dnaRegions[region[0]] = region[1]

pathRegions = {}
for pathID,dnaIDs in paths.iteritems():
	if pathRnaID[pathID] not in selectRnaIDs:
		continue
	pathRegions[pathID] = []
	pathRegions[pathID].append(copy.deepcopy(dnaRegions[dnaIDs[0][0]][dnaIDs[0][1]]))
	if pathRegions[pathID][0][1] == "+":
		pathRegions[pathID][0][2] -= extend
	else:
		pathRegions[pathID][0][3] += extend
	for dnaID1,dnaID2 in zip(dnaIDs[1::2], dnaIDs[2::2]):
		chr = dnaRegions[dnaID1[0]][dnaID1[1]][0]
		strand = dnaRegions[dnaID2[0]][dnaID2[1]][1]
		start = min(dnaRegions[dnaID1[0]][dnaID1[1]][2],dnaRegions[dnaID2[0]][dnaID2[1]][2])
		end = max(dnaRegions[dnaID1[0]][dnaID1[1]][3],dnaRegions[dnaID2[0]][dnaID2[1]][3])
		pathRegions[pathID].append((chr,strand,start,end))
	pathRegions[pathID].append(copy.deepcopy(dnaRegions[dnaIDs[-1][0]][dnaIDs[-1][1]]))
	if pathRegions[pathID][-1][1] == "+":
		pathRegions[pathID][-1][1] = "-"
		pathRegions[pathID][-1][2] -= extend
	else:
		pathRegions[pathID][-1][1] = "+"
		pathRegions[pathID][-1][3] += extend

def reverseComplement(sequence):
	return sequence[::-1].translate(string.maketrans('ACTGactg','TGACtgac'))

sequences = {}
for (id,seq) in fastaParser(open(fastaFilename,'r')).sequences():
	sequences[id] = seq

for pathID,regions in pathRegions.iteritems():
	sequence = ""
	for region in regions:
		regionSeq = sequences[region[0]][region[2]-1:region[3]]
		if region[1] == "-":
			regionSeq = reverseComplement(regionSeq)
		if sequence != "":
			sequence = sequence + "|"
		sequence = sequence + regionSeq
	print ">%d\n%s" % (pathRnaID[pathID],sequence)
		
