#!/usr/bin/perl

use strict;
use warnings;
use List::Util qw[min max];

my $dna_fai = shift;
my $num_breaks = shift;

defined $num_breaks or die "Usage: $0 dna_fai num_breaks > breaks\n";

my %chromosome_length;
open FAI, $dna_fai or die;
while (<FAI>)
{
	chomp;
	my ($chromosome,$length) = split /\t/;
	$chromosome_length{$chromosome} = $length;
}
close FAI;

my @chromosomes = keys %chromosome_length;
my $num_chromosomes = scalar @chromosomes;

my @strands = ("+","-");

my $break_length = 200;

foreach my $sample (1..$num_breaks)
{
	my $chromosome1 = $chromosomes[int(rand($num_chromosomes))];
	my $chromosome2 = $chromosomes[int(rand($num_chromosomes))];
	
	my $strand1 = $strands[int(rand(2))];
	my $strand2 = $strands[int(rand(2))];
	
	my $start1 = int(rand($chromosome_length{$chromosome1}));
	my $start2 = int(rand($chromosome_length{$chromosome2}));
	
	my $end1 = $start1 + $break_length;
	my $end2 = $start2 + $break_length;
	
	print $sample."\t"."0"."\t".$chromosome1."\t".$strand1."\t".$start1."\t".$end1."\n";
	print $sample."\t"."1"."\t".$chromosome2."\t".$strand2."\t".$start2."\t".$end2."\n";

}

