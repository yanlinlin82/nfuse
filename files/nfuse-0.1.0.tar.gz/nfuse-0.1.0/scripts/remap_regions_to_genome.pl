#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use List::Util qw[min max];

$| = 1;

use lib dirname($0);
use gene_models;

my $gene_models_filename = shift;
my $max_overhang = shift;

defined $max_overhang or die "Usage: $0 gene_models_filename max_overhang < regions > remapped_regions\n";

# Read in the gene models
my $gene_models = gene_models->new($gene_models_filename);

while (<>)
{
	chomp;
	my @fields = split /\t/;
	
	my $cluster_id = $fields[0];
	my $cluster_end = $fields[1];
	my $ref_name = $fields[2];
	my $strand = $fields[3];
	my $start = $fields[4];
	my $end = $fields[5];
	
	my $chromosome = $gene_models->calc_genomic_chromosome($ref_name);
	my $genome_strand = $gene_models->calc_genomic_strand($ref_name, $strand);
	my $genome_start = $gene_models->calc_genomic_position($ref_name, $start + $max_overhang);
	my $genome_end = $gene_models->calc_genomic_position($ref_name, $end - $max_overhang);
	
	($genome_start,$genome_end) = sort { $a <=> $b } ($genome_start - $max_overhang,$genome_end + $max_overhang);
	
	print $cluster_id."\t".$cluster_end."\t".$chromosome."\t".$genome_strand."\t".$genome_start."\t".$genome_end."\n";
}

