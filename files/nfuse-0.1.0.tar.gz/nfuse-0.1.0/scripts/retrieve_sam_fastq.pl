#!/usr/bin/perl

use strict;
use warnings;

my $reads_1_fastq = shift;
my $reads_2_fastq = shift;
my $sample_size = shift;
my $sample_seed = shift;
my $sample_1_fastq = shift;
my $sample_2_fastq = shift;

defined $sample_1_fastq or die "Usage: $0 reads_1_fastq reads_2_fastq sample_size sample_seed sample_1_fastq sample_2_fastq\n";

open FQ1, ">".$reads_1_fastq or die "Error: Unable to open $reads_1_fastq: $!\n";
open FQ2, ">".$reads_2_fastq or die "Error: Unable to open $reads_2_fastq: $!\n";

my $fragment_id = 0;

srand($sample_seed);
my @sample_reads;
my $sample_count = 0;

my $unmatched = 0;

my $read_1;
my $read_2;
while (<>)
{
	chomp;
	next if /^@/;
	
	my @sam_fields = split /\t/;
	my $qname = $sam_fields[0];
	my $flag = $sam_fields[1];
	my $seq = $sam_fields[9];
	my $qual = $sam_fields[10];
	
	my $strand = '+';
	$strand = '-' if $flag & hex('0x0010');
	
	if ($flag & hex('0x0010'))
	{
		$seq = reverse($seq);
		$seq =~ tr/ACGTacgt/TGCAtgca/;
		$qual = reverse($qual);
	}
	
	if ($flag & hex('0x0040'))
	{
		if (defined $read_1)
		{
			warn "Warning: read $read_1->[0] unmatched\n";
			$unmatched++;
		}
		
		if (defined $read_2 and $qname ne $read_2->[0])
		{
			warn "Warning: read $read_2->[0] unmatched\n";
			$read_2 = undef;
			$unmatched++;
		}
		
		$read_1 = [$qname,$fragment_id,"1",$seq,$qual];
	}
	
	if ($flag & hex('0x0080'))
	{
		if (defined $read_2)
		{
			warn "Warning: read $read_2->[0] unmatched\n";
			$unmatched++;
		}
		
		if (defined $read_1 and $qname ne $read_1->[0])
		{
			warn "Warning: read $read_1->[0] unmatched\n";
			$read_1 = undef;
			$unmatched++;
		}
		
		$read_2 = [$qname,$fragment_id,"2",$seq,$qual];
	}
	
	if (defined $read_1 and defined $read_2)
	{
		if (not ($flag & hex('0x0002')))
		{
			print_read(\*FQ1, $read_1);
			print_read(\*FQ2, $read_2);
		}
		
		if (scalar @sample_reads < $sample_size)
		{
			push @sample_reads, [$read_1,$read_2];
		}
		else
		{
			my $index = int(rand($sample_count));
			if ($index < $sample_size)
			{
				$sample_reads[$index] = [$read_1,$read_2];
			}
		}
		
		$sample_count++;
		
		$read_1 = undef;
		$read_2 = undef;
		$fragment_id++;
	}
	
	if ($fragment_id > 100000 and $unmatched / $fragment_id > 0.5)
	{
		die "Error: Too many unmatched reads, perhaps the input is not sorted by read name\n";
	}
}

close FQ1;
close FQ2;

open SFQ1, ">".$sample_1_fastq or die "Error: Unable to open $sample_1_fastq: $!\n";
open SFQ2, ">".$sample_2_fastq or die "Error: Unable to open $sample_2_fastq: $!\n";

foreach my $read (@sample_reads)
{
	print_read(\*SFQ1, $read->[0]);
	print_read(\*SFQ2, $read->[1]);
}

close SFQ1;
close SFQ2;

sub print_read
{
	my $fastq = shift;
	my $read = shift;
	
	print $fastq "\@".$read->[1]."/".$read->[2]."\n";
	print $fastq $read->[3]."\n";
	print $fastq "+".$read->[0]."\n";
	print $fastq $read->[4]."\n";
}


