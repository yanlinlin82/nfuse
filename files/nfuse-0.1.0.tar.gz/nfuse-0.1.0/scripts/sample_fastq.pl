#!/usr/bin/perl

use strict;
use warnings;
use Getopt::Std;
use Getopt::Long;

my $size = shift;
my $seed = shift;

my $usage = "Usage: $0 size seed < infastq > outfastq\n";

die $usage if not defined $seed;

srand($seed);

my @reads;
my $count = 0;
while (1)
{
	my $readid = <>;
	my $sequence = <>;
	my $comment = <>;
	my $quality = <>;
	
	last if not defined $quality;
	
	if (scalar @reads < $size)
	{
		push @reads, [$readid,$sequence,$comment,$quality];
	}
	else
	{
		my $index = int(rand($count));
		if ($index < $size)
		{
			$reads[$index] = [$readid,$sequence,$comment,$quality];
		}
	}
	
	$count++;
}

foreach my $read (@reads)
{
	print @{$read};
}

