#!/usr/bin/perl

use strict;
use warnings;

my $proportion = shift;

my $usage = "Usage: $0 proportion < in > out\n";

die $usage if not defined $proportion;

while (<>)
{
	next if rand() > $proportion;
	print $_;
}

