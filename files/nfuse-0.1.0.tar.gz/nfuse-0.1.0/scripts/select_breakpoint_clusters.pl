#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use List::Util qw[min max];


my $corroboration_sc_filename = shift;

defined $corroboration_sc_filename or die "Usage: $0 corroboration_sc_filename < clusters_in > clusters_out\n";

my %corroborating;
open CORR, $corroboration_sc_filename or die "Error: Unable to open $corroboration_sc_filename\n";
while (<CORR>)
{
	chomp;
	my @fields = split /\t/;
	
	my $rna_cluster_id = shift @fields;
	
	foreach my $dna_cluster_id (@fields)
	{
		$corroborating{$dna_cluster_id} = 1;
	}
}
close CORR;

while (<>)
{
	my $line = $_;
	
	chomp;
	my @fields = split /\t/;
	
	my $cluster_id = $fields[0];
	
	next if not defined $corroborating{$cluster_id};
	
	print $line;
}

