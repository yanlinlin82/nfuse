#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use List::Util qw[min max];

use lib dirname($0);
use configdata;
use cmdrunner;
use gene_models;

my $config_filename = shift;
my $corroboration_filename = shift;

defined $corroboration_filename or die "Usage: $0 config_filename corroboration_filename < clusters_in > clusters_out\n";

my $config = configdata->new();
$config->read($config_filename);

# Config values
my $gene_models_filename = $config->get_value("gene_models");
my $mt_chromosome = $config->get_value("mt_chromosome");
my $filter_mitochondrial = $config->get_value("filter_mitochondrial");
my $filter_intergenic = $config->get_value("filter_intergenic");
my $filter_intronic = $config->get_value("filter_intronic");
my $filter_strand_inconsistent = $config->get_value("filter_strand_inconsistent");

my $gene_models = gene_models->new($gene_models_filename);

my %corroborated;
open CORR, $corroboration_filename or die "Error: Unable to open $corroboration_filename\n";
while (<CORR>)
{
	chomp;
	my @fields = split /\t/;
	$corroborated{$fields[0]} = 1;
}
close CORR;

sub is_fusion
{
	my $cluster_id = shift;
	my $cluster_ref = shift;
	
	my $pos1 = ($cluster_ref->{"0"}{start} + $cluster_ref->{"0"}{end}) / 2;
	my $pos2 = ($cluster_ref->{"1"}{start} + $cluster_ref->{"1"}{end}) / 2;
	
	my $gene1 = $gene_models->calc_gene($cluster_ref->{"0"}{ref_name}, $pos1);
	my $gene2 = $gene_models->calc_gene($cluster_ref->{"1"}{ref_name}, $pos2);
	
	my $chromosome1 = $gene_models->calc_genomic_chromosome($cluster_ref->{"0"}{ref_name});
	my $chromosome2 = $gene_models->calc_genomic_chromosome($cluster_ref->{"1"}{ref_name});
	
	my $genomic_strand1 = $gene_models->calc_genomic_strand($cluster_ref->{"0"}{ref_name}, $cluster_ref->{"0"}{strand});
	my $genomic_strand2 = $gene_models->calc_genomic_strand($cluster_ref->{"1"}{ref_name}, $cluster_ref->{"1"}{strand});
	
	my $genomic_pos1 = $gene_models->calc_genomic_position($cluster_ref->{"0"}{ref_name}, $pos1);
	my $genomic_pos2 = $gene_models->calc_genomic_position($cluster_ref->{"1"}{ref_name}, $pos2);
	
	my $gene_location1 = $gene_models->calc_gene_location($gene1, $genomic_pos1);
	my $gene_location2 = $gene_models->calc_gene_location($gene2, $genomic_pos2);
	
	my $gene_align_strand1 = ($genomic_strand1 eq $gene_models->{genes}{$gene1}{strand}) ? "+" : "-";
	my $gene_align_strand2 = ($genomic_strand2 eq $gene_models->{genes}{$gene2}{strand}) ? "+" : "-";
	
	# Filter clusters involving the same gene
	return 0 if $gene1 eq $gene2;
	
	# Filter intergenic clusters if requested
	my $intergenic = 0;
	$intergenic++ if ($gene_location1 eq "upstream" or $gene_location1 eq "downstream");
	$intergenic++ if ($gene_location2 eq "upstream" or $gene_location2 eq "downstream");
	return 0 if $intergenic >= $filter_intergenic;
	
	# Filter intronic clusters if requested
	my $intronic = 0;
	$intronic++ if ($gene_location1 eq "intron");
	$intronic++ if ($gene_location2 eq "intron");
	return 0 if $intronic >= $filter_intronic;
	
	# Filter mitochondrial if requested
	return 0 if ($filter_mitochondrial and ($chromosome1 eq $mt_chromosome or $chromosome2 eq $mt_chromosome));
	
	# Filter strand inconsistent if requested
	return 0 if ($filter_strand_inconsistent and ($gene_align_strand1 eq $gene_align_strand2));
	
	return 1;
}


my $current_id;
my %cluster;
my @lines;
while (<>)
{
	my $line = $_;
	
	chomp;
	my @fields = split /\t/;
	
	my $cluster_id = $fields[0];
	my $cluster_end = $fields[1];
	my $fragment_id = $fields[2];
	my $read_end = $fields[3];
	my $ref_name = $fields[4];
	my $strand = $fields[5];
	my $start = $fields[6];
	my $end = $fields[7];
	
	if (defined $current_id and $current_id != $cluster_id)
	{
		die "Error: Unmatched cluster $current_id\n" if not defined $cluster{"0"} or not defined $cluster{"1"};
		
		if (is_fusion($current_id, \%cluster))
		{
			print @lines;
		}
		
		%cluster = ();
		@lines = ();
	}
	
	my $chromosome = $gene_models->calc_genomic_chromosome($ref_name);
	
	$current_id = $cluster_id;
	$cluster{$cluster_end}{ref_name} = $ref_name;
	$cluster{$cluster_end}{strand} = $strand;
	
	$cluster{$cluster_end}{start} = $start if not defined $cluster{$cluster_end}{start};
	$cluster{$cluster_end}{end} = $end if not defined $cluster{$cluster_end}{end};
	
	$cluster{$cluster_end}{start} = min($cluster{$cluster_end}{start}, $start);
	$cluster{$cluster_end}{end} = max($cluster{$cluster_end}{end}, $end);
	
	push @lines, $line;
}

if (defined $current_id)
{
	die "Error: Unmatched cluster $current_id\n" if not defined $cluster{"0"} or not defined $cluster{"1"};
	
	if (is_fusion($current_id, \%cluster))
	{
		print @lines;
	}
}
