#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';

my $usage = "Usage: $0 fastq size prefix suffix > catalog\n";

my $fastq = shift;
my $size = shift;
my $prefix = shift;
my $suffix = shift;

die $usage if not defined $suffix;

my $file_count = 0;
my $read_count = $size;
my $split_fastq_file;

open FQ, $fastq or die "Error: Unable to open $fastq: $!\n";
while (1)
{
	my $readid = <FQ>;
	my $sequence = <FQ>;
	my $comment = <FQ>;
	my $quality = <FQ>;
	
	last if not defined $readid;
	
	defined $quality or die "Error: Fastq with number of lines not divisible by 4\n";
	
	if ($read_count == $size)
	{
		my $file_num_str = $file_count;
		$file_num_str = "0".$file_num_str while length($file_num_str) < 3;
		$file_count++;
		
		my $split_fastq = $prefix.$file_num_str.$suffix;
		
		print $split_fastq."\n";
		
		close $split_fastq_file if defined $split_fastq_file;
		open $split_fastq_file, ">".$split_fastq or die "Error: Unable to open $split_fastq: $!\n";
		
		$read_count = 0;
	}
	
	print $split_fastq_file $readid;
	print $split_fastq_file $sequence;
	print $split_fastq_file $comment;
	print $split_fastq_file $quality;
	
	$read_count++;
}
close FQ;
close $split_fastq_file if defined $split_fastq_file;

