#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use List::Util qw(min max);

die "Usage $0 clusters1_in clusters2_in ... clusters1_out clusters2_out ...\n" if scalar @ARGV == 0;

my $num_files = scalar(@ARGV) / 2;

my @clusters_in_filenames = @ARGV[0..($num_files-1)];
my @clusters_out_filenames = @ARGV[$num_files..(2*$num_files-1)];

my $cluster_id = 0;
while (scalar @clusters_in_filenames > 0 and scalar @clusters_out_filenames > 0)
{
	my $clusters_in_filename = shift @clusters_in_filenames;
	my $clusters_out_filename = shift @clusters_out_filenames;
	
	my $previous_cluster_id;
	open CIN, $clusters_in_filename or die "Error: Unable to open $clusters_in_filename\n";
	open COUT, ">".$clusters_out_filename or die "Error: Unable to open $clusters_out_filename\n";
	while (<CIN>)
	{
		my @fields = split /\t/;
		
		if (defined $previous_cluster_id and $previous_cluster_id != $fields[0])
		{
			$cluster_id++;
		}
		$previous_cluster_id = $fields[0];
		
		$fields[0] = $cluster_id;
		
		print COUT join "\t", @fields;
	}
	close CIN;
	close COUT;

	if (defined $previous_cluster_id)
	{
		$cluster_id++;
	}
}

