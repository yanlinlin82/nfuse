/*
 *  Parsers.h
 */

#ifndef PARSERS_H_
#define PARSERS_H_

#include "Common.h"
#include "Indexer.h"

#include <fstream>
#include <iostream>
#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/unordered_set.hpp>

using namespace boost;
using namespace std;


struct AlignmentScore
{
	ReadID readID;
	int score;
	int alignedLength;
};

typedef vector<AlignmentScore> AlignmentScoreVec;
typedef vector<AlignmentScore>::iterator AlignmentScoreVecIter;
typedef vector<AlignmentScore>::const_iterator AlignmentScoreVecConstIter;

struct MateAlignmentScore
{
	int fragmentIndex;
	int score;
	int alignedLength;
	int alignmentCount;
};

typedef vector<MateAlignmentScore> MateAlignmentScoreVec;
typedef vector<MateAlignmentScore>::iterator MateAlignmentScoreVecIter;
typedef vector<MateAlignmentScore>::const_iterator MateAlignmentScoreVecConstIter;

void ReadClusters(const string& clustersFilename, IntegerVecMap& clusters);
void ReadClusters(const string& clustersFilename, CompactLocationVecMap& clusters, NameIndex& references);
void WriteClusters(const string& inClustersFilename, const string& outClustersFilename, const IntegerSet& clusters);
void ReadCorroboration(const string& corroborationFilename, IntegerVecPairVec& corroboration);
void IntepretAlignString(const string& alignString, Location& alignRegion);
void ReadAlignRegionPairs(const string& filename, LocationVecMap& alignRegionPairs);
void ReadDoubleMap(const string& filename, DoubleMap& values);
void ReadAlignmentScores(const string& filename, AlignmentScoreVec& mateAlignments);
void ReadMateAlignmentScores(const string& filename, MateAlignmentScoreVec& mateAlignments);
void ReadDoubleVec(const string& filename, DoubleVec& values);
void ReadIntegerVecMap(const string& filename, IntegerVecMap& values);


class ClusterReader
{
public:
	ClusterReader(istream& clustersFile) : mClustersFile(clustersFile), mLineNumber(0)
	{
		if (!mClustersFile)
		{
			cerr << "Error: unable to read clusters" << endl;		
			exit(1);
		}
		
		mLastGetResult = GetLineTSV(mClustersFile, mCurrentFields);
		mCurrentClusterID = mCurrentFields[0];
	}
	
	bool Next(int& clusterID, LocationVec& clusterLocations, IntegerVec& fragmentIndices)
	{
		if (!mLastGetResult)
		{
			return false;
		}
		
		bool clusterInit[2] = {false, false};
		
		fragmentIndices.clear();
		
		while (mLastGetResult && mCurrentFields[0] == mCurrentClusterID)
		{
			Interpret(mCurrentFields, clusterLocations, fragmentIndices, clusterInit);
			mLastGetResult = GetLineTSV(mClustersFile, mCurrentFields);
		}
		
		int previousID = lexical_cast<int>(mCurrentClusterID);
		
		if (fragmentIndices.empty())
		{
			cerr << "Error: cluster " << previousID << " with no fragments" << endl;
			exit(1);
		}
		
		mCurrentClusterID = mCurrentFields[0];

		clusterID = previousID;

		return true;
	}
	
private:
	bool GetLineTSV(istream& file, StringVec& fields)
	{
		string line;
		if (!getline(file, line))
		{
			return false;
		}
		
		mLineNumber++;
		
		split(fields, line, is_any_of("\t"));
		
		return true;
	}
	
	void Interpret(const StringVec& fields, LocationVec& clusterLocations, IntegerVec& fragmentIndices, bool clusterInit[])
	{
		if (fields.size() < 8)
		{
			cerr << "Error: Empty clusters line " << mLineNumber << endl;
			exit(1);
		}
		
		int clusterID = lexical_cast<int>(fields[0]);
		int clusterEnd = lexical_cast<int>(fields[1]);
		
		int fragmentIndex = lexical_cast<int>(fields[2]);
		int readEnd = lexical_cast<int>(fields[3]);
		
		clusterLocations[clusterEnd].refName = fields[4];
		clusterLocations[clusterEnd].strand = InterpretStrand(fields[5]);
		
		int start = lexical_cast<int>(fields[6]);
		int end = lexical_cast<int>(fields[7]);
		
		if (!clusterInit[clusterEnd])
		{
			clusterLocations[clusterEnd].start = start;
			clusterLocations[clusterEnd].end = end;
			
			clusterInit[clusterEnd] = true;
		}
		
		clusterLocations[clusterEnd].start = min(clusterLocations[clusterEnd].start, start);
		clusterLocations[clusterEnd].end = min(clusterLocations[clusterEnd].end, end);
		
		if (readEnd == 0)
		{
			fragmentIndices.push_back(fragmentIndex);
		}
	}
	
	istream& mClustersFile;
	bool mLastGetResult;
	string mCurrentClusterID;
	StringVec mCurrentFields;
	int mLineNumber;
};

#endif

