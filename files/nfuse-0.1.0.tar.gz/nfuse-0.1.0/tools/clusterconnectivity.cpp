/*
 *  clusterconnectivity.cpp
 *
 *  Created by Andrew McPherson on 06-06-12.
 *
 */


#include "BinaryMinHeap.h"
#include "CompactBreakRegion.h"
#include "DebugCheck.h"
#include "Matrix.h"
#include "Parsers.h"

#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/unordered_set.hpp>
#include <boost/unordered_map.hpp>

using namespace boost;
using namespace std;


class RegionDB
{
public:
	explicit RegionDB(int binSpacing = 10000) : mBinSpacing(binSpacing) {}
	
	void Add(int id, int ref, int start, int end)
	{
		for (int bin = start / mBinSpacing; bin <= end / mBinSpacing; bin++)
		{
			mBinned[RefBin(ref,bin)].push_back(IDStartEnd(id,start,end));
		}
	}
	
	void Overlapping(int ref, int start, int end, IntegerSet& overlapping) const
	{
		for (int bin = start / mBinSpacing; bin <= end / mBinSpacing; bin++)
		{
			unordered_map<RefBin,IDStartEndVec>::const_iterator findIter = mBinned.find(RefBin(ref,bin));
			
			if (findIter != mBinned.end())
			{
				for (IDStartEndVec::const_iterator regionIter = findIter->second.begin(); regionIter != findIter->second.end(); regionIter++)
				{
					if (regionIter->Overlaps(start,end))
					{
						overlapping.insert(regionIter->ID());
					}
				}
			}
		}
	}
	
private:
	typedef pair<int,int> RefBin;
	
	class IDStartEnd
	{
	public:
		IDStartEnd(int id, int start, int end) : mID(id), mStart(start), mEnd(end) {}
		
		bool Overlaps(int start, int end) const
		{
			return !(mEnd < start || end < mStart);
		}
		
		int ID() const { return mID; }
		
	private:
		int mID;
		int mStart;
		int mEnd;
	};
	
	typedef vector<IDStartEnd> IDStartEndVec;
	
	int mBinSpacing;
	unordered_map<RefBin,IDStartEndVec> mBinned;
};

int SetCoverSize(const IntegerSet& ids, const IntegerVecMap& sets)
{
	BinaryMinHeap minHeap;
	
	IntegerVecMap elementSets;
	IntegerMap setSizes;
	for (IntegerSetConstIter idIter = ids.begin(); idIter != ids.end(); idIter++)
	{
		int id = *idIter;
		const IntegerVec& set = sets.find(id)->second;
		
		setSizes[id] = set.size();
		
		for (IntegerVecConstIter elementIter = set.begin(); elementIter != set.end(); elementIter++)
		{
			elementSets[*elementIter].push_back(id);
			
			minHeap.Push(id, 1.0 / (double)set.size());
		}
	}
	
	int numSets = 0;
	
	IntegerSet assigned;
	while (!minHeap.Empty())
	{
		int nextSetID = minHeap.MinID();
		
		numSets++;
		
		const IntegerVec& set = sets.find(nextSetID)->second;
		
		IntegerSet alteredSets;
		for (IntegerVecConstIter elementIter = set.begin(); elementIter != set.end(); elementIter++)
		{
			if (assigned.insert(*elementIter).second)
			{
				for (IntegerVecConstIter setIter = elementSets[*elementIter].begin(); setIter != elementSets[*elementIter].end(); setIter++)
				{
					setSizes[*setIter]--;
					alteredSets.insert(*setIter);
				}
			}
		}
		
		for (IntegerSetConstIter setIter = alteredSets.begin(); setIter != alteredSets.end(); setIter++)
		{
			DebugCheck(setSizes[*setIter] >= 0);
			
			if (setSizes[*setIter] == 0)
			{
				minHeap.Remove(*setIter);
			}
			else
			{
				minHeap.IncreaseKey(*setIter, 1.0 / (double)setSizes[*setIter]);
			}
		}
	}
	
	return numSets;
}

int NumDisjointOverlapping(const RegionDB& clusterRegionDB, const IntegerVecMap& clusterFragments, const IntegerVecMap& fragmentClusters, int ref, int start, int end)
{
	IntegerSet overlapping;
	clusterRegionDB.Overlapping(ref, start, end, overlapping);
	
	IntegerSet fragments;
	for (IntegerSetConstIter overlapIter = overlapping.begin(); overlapIter != overlapping.end(); overlapIter++)
	{
		fragments.insert(clusterFragments.find(*overlapIter)->second.begin(), clusterFragments.find(*overlapIter)->second.end());
	}
	
	return SetCoverSize(fragments, fragmentClusters);
}

template<typename ttype>
void print(const ttype& seq)
{
	for (typename ttype::const_iterator iter = seq.begin(); iter != seq.end(); iter++)
	{
		cout << *iter << " ";
	}
	cout << endl;
}

void UpdateMax(int& currentMax, int newValue)
{
	currentMax = max(currentMax, newValue);
}

int main(int argc, char* argv[])
{
	string connectFilename;
	string nullFilename;
	int numSamples;
	string restrictChromosome;
	
	try
	{
		TCLAP::CmdLine cmd("Number of overlapping clusters with distinct fragment sets");
		TCLAP::ValueArg<string> connectFilenameArg("c","connect","Connectivity Counts Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> nullFilenameArg("n","null","Null Connectivity Counts Filename",true,"","string",cmd);
		TCLAP::ValueArg<int> numSamplesArg("s","samples","Number of Samples from Null",true,-1,"integer",cmd);
		TCLAP::ValueArg<string> restrictChromosomeArg("r","restrict","Restrict to the Given Chromosome",false,"","string",cmd);
		cmd.parse(argc,argv);
		
		connectFilename = connectFilenameArg.getValue();
		nullFilename = nullFilenameArg.getValue();
		numSamples = numSamplesArg.getValue();
		restrictChromosome = restrictChromosomeArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	if (sizeof(long) != 8)
	{
		cerr << "Error: sizeof(long) != 8" << endl;		
		exit(1);
	}
	
	cout << "Reading all clusters" << endl;
	
	NameIndex referenceNames;
	IntegerMap referenceMaxClusterEnd;
	IntegerMap clusterReference[2];
	IntegerMap clusterRegionStart[2];
	IntegerMap clusterRegionEnd[2];
	int clusterMaxRegionLength = 0;
	RegionDB clusterRegionDB;
	vector<ClusterEndID> clusterEndIDs;
	IntegerVecMap clusterFragments;
	IntegerVecMap fragmentClusters;
	
	{
		ClusterReader clusterReader(cin);
		
		int clusterID;
		LocationVec clusterLocations(2);
		IntegerVec fragmentIndices;
		while (clusterReader.Next(clusterID, clusterLocations, fragmentIndices))
		{
			for (int clusterEnd = 0; clusterEnd <= 1; clusterEnd++)
			{
				if (restrictChromosome != "" && restrictChromosome != clusterLocations[clusterEnd].refName)
				{
					continue;
				}
				
				ClusterEndID clusterEndID;
				clusterEndID.clusterID = clusterID;
				clusterEndID.clusterEnd = clusterEnd;
				
				clusterEndIDs.push_back(clusterEndID);
				
				RefStrand refStrand;
				refStrand.referenceIndex = referenceNames.Index(clusterLocations[clusterEnd].refName);
				refStrand.strand = clusterLocations[clusterEnd].strand;
				
				clusterReference[clusterEnd][clusterID] = refStrand.referenceIndex;
				clusterRegionStart[clusterEnd][clusterID] = clusterLocations[clusterEnd].start;
				clusterRegionEnd[clusterEnd][clusterID] = clusterLocations[clusterEnd].end;			
				
				clusterRegionDB.Add(clusterID, refStrand.referenceIndex, clusterLocations[clusterEnd].start, clusterLocations[clusterEnd].end);
				
				UpdateMax(referenceMaxClusterEnd.insert(make_pair(refStrand.referenceIndex,0)).first->second, clusterLocations[clusterEnd].end);
				UpdateMax(clusterMaxRegionLength, clusterLocations[clusterEnd].end - clusterLocations[clusterEnd].start + 1);
			}
			
			for (IntegerVecConstIter fragIter = fragmentIndices.begin(); fragIter != fragmentIndices.end(); fragIter++)
			{
				clusterFragments[clusterID].push_back(*fragIter);
				fragmentClusters[*fragIter].push_back(clusterID);
			}
		}
	}
	
	ofstream connectFile(connectFilename.c_str());
	CheckFile(connectFile, connectFilename);
	
	for (vector<ClusterEndID>::const_iterator clusterEndIDIter = clusterEndIDs.begin(); clusterEndIDIter != clusterEndIDs.end(); clusterEndIDIter++)
	{
		int clusterID = clusterEndIDIter->clusterID;
		int clusterEnd = clusterEndIDIter->clusterEnd;
		
		int numDisjoint = NumDisjointOverlapping(clusterRegionDB, clusterFragments, fragmentClusters, clusterReference[clusterEnd][clusterID], clusterRegionStart[clusterEnd][clusterID], clusterRegionEnd[clusterEnd][clusterID]);

		connectFile << clusterID << "\t" << clusterEnd << "\t" << numDisjoint << endl;
	}
	
	connectFile.close();
	
	// Initialize RNG for predictability
	srand(1);
	
	ofstream nullFile(nullFilename.c_str());
	CheckFile(nullFile, nullFilename);
	
	int samples = 0;
	while (samples < numSamples)
	{
		int reference = rand() % referenceNames.Size();
		int refLength = referenceMaxClusterEnd[reference];
		
		int start = rand() % (refLength - clusterMaxRegionLength);
		int end = start + clusterMaxRegionLength;
		
		int numDisjoint = NumDisjointOverlapping(clusterRegionDB, clusterFragments, fragmentClusters, reference, start, end);
		
		if (numDisjoint == 0)
		{
			continue;
		}
		
		nullFile << numDisjoint - 1 << endl;
		
		samples++;
	}
	
	nullFile.close();
}

