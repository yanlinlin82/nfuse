/*
 *  clustermatepairs.cpp
 *
 *  Created by Andrew McPherson on 28/09/09.
 *
 */

#include "Common.h"
#include "DebugCheck.h"
#include "AlignmentStream.h"
#include "Indexer.h"
#include "ReadStream.h"
#include "Sequences.h"
#include "SimpleAligner.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

using namespace boost;
using namespace std;


struct CompactPosition
{
	RefStrand refStrand;
	int position;
};

typedef vector<CompactPosition> CompPosVec;
typedef vector<CompactPosition>::iterator CompPosVecIter;
typedef vector<CompactPosition>::const_iterator CompPosVecConstIter;

int main(int argc, char* argv[])
{
	int matchScore;
	int misMatchScore;
	int gapScore;
	int searchLength;
	string alignmentsFilename;
	string referenceFasta;
	string readSeqsFilename;
	
	try
	{
		TCLAP::CmdLine cmd("Mate Realignment Tool");
		TCLAP::ValueArg<int> matchScoreArg("m","match","Match Score",true,0,"int",cmd);
		TCLAP::ValueArg<int> misMatchScoreArg("x","mismatch","Mismatch Score",true,0,"int",cmd);
		TCLAP::ValueArg<int> gapScoreArg("g","gap","Gap Score",true,0,"int",cmd);
		TCLAP::ValueArg<int> searchLengthArg("l","length","Search Length",true,-1,"integer",cmd);
		TCLAP::ValueArg<string> alignmentsFilenameArg("a","align","Alignments Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> referenceFastaArg("r","reference","Reference Sequences Fasta",true,"","string",cmd);
		TCLAP::ValueArg<string> readSeqsFilenameArg("s","seq","Read Sequences Fastq",true,"","string",cmd);
		cmd.parse(argc,argv);
		
		matchScore = matchScoreArg.getValue();
		misMatchScore = misMatchScoreArg.getValue();
		gapScore = gapScoreArg.getValue();
		searchLength = searchLengthArg.getValue();
		alignmentsFilename = alignmentsFilenameArg.getValue();
		referenceFasta = referenceFastaArg.getValue();
		readSeqsFilename = readSeqsFilenameArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	cerr << "Reading alignments" << endl;
	
	ifstream alignmentsFile(alignmentsFilename.c_str());
	if (!alignmentsFile)
	{
		cerr << "Error: unable to read alignments file" << endl;		
		exit(1);
	}
	
	unordered_map<int,CompPosVec> readAlignments;
	unordered_map<int,int> maxAlignedLength;
	
	NameIndex refNameIndex;
	
	AlignmentStream* alignmentStream = new CompactAlignmentStream(alignmentsFilename);
	FragmentAlignmentStream fragmentAlignments(alignmentStream);
	
	RawAlignmentVec alignments;
	while (fragmentAlignments.GetNextAlignments(alignments))
	{
		for (RawAlignmentVecConstIter alignmentIter = alignments.begin(); alignmentIter != alignments.end(); alignmentIter++)
		{
			CompactPosition alignment;
			alignment.refStrand.referenceIndex = refNameIndex.Index(alignmentIter->reference);
			alignment.refStrand.strand = alignmentIter->strand;
			alignment.position = (alignmentIter->strand == PlusStrand) ? alignmentIter->region.start : alignmentIter->region.end;
			
			ReadID readID;
			readID.fragmentIndex = lexical_cast<int>(alignmentIter->fragment);
			readID.readEnd = alignmentIter->readEnd;
			
			readAlignments[readID.id].push_back(alignment);
			
			unordered_map<int,int>::iterator maxAlignedLengthIter = maxAlignedLength.insert(make_pair(readID.id,0)).first;
			maxAlignedLengthIter->second = max(maxAlignedLengthIter->second, alignmentIter->alignedLength);
		}
	}
	
	cerr << "Reading reference fasta" << endl;
	
	Sequences referenceSequences;
	referenceSequences.Read(referenceFasta);

	ifstream readSeqsFile(readSeqsFilename.c_str());
	CheckFile(readSeqsFile, readSeqsFilename);
	FastqReadStream readSeqsStream(readSeqsFile);
	
	cerr << "Doing mate alignments" << endl;
	
	SimpleAligner aligner(matchScore, misMatchScore, gapScore);
	
	RawRead rawRead;
	while (readSeqsStream.GetNextRead(rawRead))
	{
		ReadID readID;
		readID.fragmentIndex = lexical_cast<int>(rawRead.fragment);
		readID.readEnd = rawRead.readEnd;
		
		ReadID otherReadID;
		otherReadID.fragmentIndex = lexical_cast<int>(rawRead.fragment);
		otherReadID.readEnd = OtherReadEnd(rawRead.readEnd);
		
		if (readAlignments.find(otherReadID.id) != readAlignments.end())
		{
			for(CompPosVecConstIter posIter = readAlignments[otherReadID.id].begin(); posIter != readAlignments[otherReadID.id].end(); posIter++)
			{
				string referenceSequence;
				
				if (posIter->refStrand.strand == PlusStrand)
				{
					referenceSequences.Get(refNameIndex.Get(posIter->refStrand.referenceIndex), posIter->position, posIter->position + searchLength, referenceSequence);
					
					ReverseComplement(referenceSequence);
				}
				else
				{
					referenceSequences.Get(refNameIndex.Get(posIter->refStrand.referenceIndex), posIter->position - searchLength, posIter->position, referenceSequence);						
				}
				
				string readSequence = rawRead.sequence;
				readSequence.resize(maxAlignedLength[readID.id]);
				
				string readQuality = rawRead.quality;
				readQuality.resize(maxAlignedLength[readID.id]);
				
				int score = aligner.EndToEndAlign(referenceSequence, readSequence, readQuality);
				
				cout << readID.fragmentIndex << "\t" << readID.readEnd << "\t" << readSequence.size() << "\t" << score << endl;
			}
		}
	}
}

