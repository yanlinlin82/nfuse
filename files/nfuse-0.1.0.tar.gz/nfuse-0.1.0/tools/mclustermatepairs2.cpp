/*
 *  clustermatepairs.cpp
 *
 *  Created by Andrew McPherson on 28/09/09.
 *
 */

#include "AlignmentIndex.h"
#include "DebugCheck.h"
#include "ExonRegions.h"
#include "FragmentAlignmentsIterator.h"
#include "DiscordantAlignments.h"
#include "MatePairEM.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include "bam.h"
#include "sam.h"

using namespace boost;
using namespace std;


class Binning
{
public:
	Binning(int binLength, int regionExtend) : mBinLength(binLength), mRegionExtend(regionExtend)
	{}
	
	void GetBins(const Region& region, IntegerVec& bins)
	{
		int startBin = (region.start - mRegionExtend) / mBinLength;
		int endBin = (region.end + mRegionExtend) / mBinLength;
		
		for (int bin = startBin; bin <= endBin; bin++)
		{
			bins.push_back(bin);
		}
	}
	
	int CalcBinRelativePos(int bin, int pos) const
	{
		return pos - bin * mBinLength + mBinLength / 2;
	}

	int CalcAbsolutePos(int bin, int pos) const
	{
		return pos + bin * mBinLength - mBinLength / 2;
	}
	
private:
	int mBinLength;
	int mRegionExtend;
};

struct RefBin
{
	RefBin() {}
	RefBin(int ref, int bin) : ref(ref), bin(bin) {}
	
	int ref;
	int bin;
	
	bool operator<(const RefBin& other) const
	{
		if (ref < other.ref)
		{
			return true;
		}
		else if (ref > other.ref)
		{
			return false;
		}
		
		return (bin < other.bin);
	}
};

typedef unordered_set<RefBin> RefBinSet;
typedef unordered_set<RefBin>::const_iterator RefBinSetConstIter;

inline bool operator==(const RefBin& rb1, const RefBin& rb2)
{
	return rb1.ref == rb2.ref && rb1.bin == rb2.bin;
}

inline size_t hash_value(const RefBin& rb)
{
	size_t seed = 0;
	hash_combine(seed, rb.ref);
	hash_combine(seed, rb.bin);
	return seed;
}

void GetFragmentAlignments(const CompAlignVec& alignments, IntegerVecMap& fragments)
{
	for (int alignIndex = 0; alignIndex < alignments.size(); alignIndex++)
	{
		fragments[alignments[alignIndex].readID.fragmentIndex].push_back(alignIndex);		
	}
}

void FilterUnmatched(const IntegerVecMap& fragments1, IntegerVecMap& fragments2)
{
	IntegerVecMap matchedFragments2;
	for (IntegerVecMapIter fragment2Iter = fragments2.begin(); fragment2Iter != fragments2.end(); fragment2Iter++)
	{
		if (fragments1.find(fragment2Iter->first) != fragments1.end())
		{
			swap(matchedFragments2[fragment2Iter->first], fragment2Iter->second);
		}
	}
	
	swap(matchedFragments2, fragments2);
}

void FilterOverlapping(IntegerVecMap& fragments, const CompAlignVec& alignments, int minFusionRange)
{
	Binning overlapBinning(minFusionRange, 0);
	
	for (IntegerVecMapIter fragmentIter = fragments.begin(); fragmentIter != fragments.end(); fragmentIter++)
	{
		IntegerVec filtered;
		
		// Select a set of non overlapping end alignments
		RefBinSet alignmentBins[2];
		IntegerVec nonOverlapping;
		for (IntegerVecConstIter alignIter = fragmentIter->second.begin(); alignIter != fragmentIter->second.end(); alignIter++)
		{
			const CompactAlignment& alignment = alignments[*alignIter];
			
			IntegerVec rangeBins;
			overlapBinning.GetBins(alignment.region, rangeBins);
			
			// Check for a potential overlapping alignment of one end
			bool overlappingAlignment = false;
			for (IntegerVecConstIter rangeBinIter = rangeBins.begin(); rangeBinIter != rangeBins.end(); rangeBinIter++)
			{
				RefBin refIdRangeBin(alignment.refStrand.id,*rangeBinIter);				
				if (alignmentBins[alignment.readID.readEnd].find(refIdRangeBin) != alignmentBins[alignment.readID.readEnd].end())
				{
					overlappingAlignment = true;
				}
			}
			
			// Randomly select the first encountered of potential overlapping ends
			if (!overlappingAlignment)
			{
				for (IntegerVecConstIter rangeBinIter = rangeBins.begin(); rangeBinIter != rangeBins.end(); rangeBinIter++)
				{
					RefBin refIdRangeBin(alignment.refStrand.id,*rangeBinIter);				
					alignmentBins[alignment.readID.readEnd].insert(refIdRangeBin);
				}
				
				filtered.push_back(*alignIter);
			}
		}
		
		swap(filtered, fragmentIter->second);
	}
}

void GetAlignPairs(const IntegerVecMap& fragments1, const IntegerVecMap& fragments2, const CompAlignVec& alignments1, const CompAlignVec& alignments2, PairIndex& alignPairs)
{
	for (IntegerVecMapConstIter fragment1Iter = fragments1.begin(); fragment1Iter != fragments1.end(); fragment1Iter++)
	{
		const IntegerVec& alignIndices1 = fragment1Iter->second;
		const IntegerVec& alignIndices2 = fragments2.find(fragment1Iter->first)->second;
		
		for (IntegerVecConstIter align1Iter = alignIndices1.begin(); align1Iter != alignIndices1.end(); align1Iter++)
		{
			for (IntegerVecConstIter align2Iter = alignIndices2.begin(); align2Iter != alignIndices2.end(); align2Iter++)
			{
				if (alignments1[*align1Iter].readID.readEnd != alignments2[*align2Iter].readID.readEnd)
				{
					alignPairs.Index(IntegerPair(*align1Iter, *align2Iter));
				}
			}
		}
	}
}

void OutputClusterMember(ostream& out, int clusterID, int clusterEnd, const CompactAlignment& alignment, const vector<string>& referenceNames, const vector<string>& fragmentIndices, vector<unsigned char>& fragmentLibIndices)
{
	out << clusterID << "\t";
	out << clusterEnd << "\t";
	out << (int)fragmentLibIndices[alignment.readID.fragmentIndex] << "\t";
	out << fragmentIndices[alignment.readID.fragmentIndex] << "\t";
	out << alignment.readID.readEnd << "\t";
	out << referenceNames[alignment.refStrand.referenceIndex] << "\t";
	out << ((alignment.refStrand.strand == PlusStrand) ? "+" : "-") << "\t";
	out << alignment.region.start << "\t";
	out << alignment.region.end << endl;	
}

void ReadTable(const string& filename, unordered_map<string,string>& values)
{
	ifstream file(filename.c_str());
	if (!file.good())
	{
		cerr << "Error: Unable to open file " << filename << endl;
		exit(1);
	}
	
	vector<string> lines;
	
	string line;
	while (getline(file, line))
	{
		lines.push_back(line);
	}
	
	if ((int)lines.size() < 2)
	{
		cerr << "Error: incorrect number of lines for table file " << filename << endl;
		exit(1);
	}
	
	vector<string> fieldNames;
	split(fieldNames, lines[0], is_any_of("\t"));
	
	vector<string> fieldValues;
	split(fieldValues, lines[1], is_any_of("\t"));
	
	for (int fieldIndex = 0; fieldIndex < min(fieldNames.size(),fieldValues.size()); fieldIndex++)
	{
		values[fieldNames[fieldIndex]] = fieldValues[fieldIndex];
	}
}

void CheckHasStat(const string& filename, const unordered_map<string,string>& values, const string& name)
{
	if (values.find(name) == values.end())
	{
		cerr << "Error: no entry in stats file " << filename << " for " << name << endl;
		exit(1);
	}
}

void ReadStats(const string& filename, double& fragmentLengthMean, double& fragmentLengthStdDev)
{
	unordered_map<string,string> values;
	ReadTable(filename, values);
	
	CheckHasStat(filename, values, "fraglength_mean");
	CheckHasStat(filename, values, "fraglength_stddev");
	
	fragmentLengthMean = lexical_cast<double>(values["fraglength_mean"]);
	fragmentLengthStdDev = lexical_cast<double>(values["fraglength_stddev"]);
}

int main(int argc, char* argv[])
{
	vector<int> libraryIDList;
	vector<string> bamFilenameList;
	vector<string> statsFilenameList;
	string clustersFilename;
	double precision;
	int minClusterSize;
	
	try
	{
		TCLAP::CmdLine cmd("Mate Pair Clustering Tool");
		TCLAP::MultiArg<int> libraryIDArg("i","id","Library ID",true,"integer",cmd);
		TCLAP::MultiArg<string> bamFilenameArg("b","bam","Read Sorted Bam Filename",true,"string",cmd);
		TCLAP::MultiArg<string> statsFilenameArg("s","stats","Concordant Stats Filename",true,"string",cmd);
		TCLAP::ValueArg<string> clustersFilenameArg("c","clusters","Output Clusters Filename",true,"","string",cmd);
		TCLAP::ValueArg<double> precisionArg("p","precision","Precision",true,-1,"double",cmd);
		TCLAP::ValueArg<int> minClusterSizeArg("m","minclustersize","Minimum Cluster Size",true,-1,"integer",cmd);
		cmd.parse(argc,argv);
		
		libraryIDList = libraryIDArg.getValue();
		bamFilenameList = bamFilenameArg.getValue();
		statsFilenameList = statsFilenameArg.getValue();
		clustersFilename = clustersFilenameArg.getValue();
		precision = precisionArg.getValue();
		minClusterSize = minClusterSizeArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	if (libraryIDList.size() != bamFilenameList.size() || libraryIDList.size() != statsFilenameList.size())
	{
		cerr << "Require the same number of ids, bam filenames and stats filenames" << endl;
		exit(1);
	}
	
	cout << "Reading concordant alignment stats" << endl;
	
	DebugCheck(libraryIDList.size() <= 255);
	
	vector<double> fragmentLengthMeans(libraryIDList.size());
	vector<double> fragmentLengthStdDevs(libraryIDList.size());
	int maxFragmentLength = 0;
	for (unsigned char libIndex = 0; libIndex < (unsigned char)libraryIDList.size(); libIndex++)
	{
		ReadStats(statsFilenameList[libIndex], fragmentLengthMeans[libIndex], fragmentLengthStdDevs[libIndex]);
		maxFragmentLength = max(maxFragmentLength, (int)(fragmentLengthMeans[libIndex] + 10.0 * fragmentLengthStdDevs[libIndex]));
	}
	
	cout << "Finding pairs of reference sequences connected by pairs of alignments" << endl;
	
	DiscordantAlignments discordantAlignments(maxFragmentLength);
	NameIndex referenceNames;
	
	vector<string> remapFragmentIndices;
	vector<unsigned char> fragmentLibIndices;
	
	for (unsigned char libIndex = 0; libIndex < (unsigned char)libraryIDList.size(); libIndex++)
	{
		FragmentAlignmentsIterator libFragmentsIter;
		StringVec libReferenceNames;
		libFragmentsIter.Open(bamFilenameList[libIndex], libReferenceNames);
		
		CompAlignVec1 alignments;
		while (libFragmentsIter.GetNext(alignments))
		{
			if (alignments.front().concordant)
			{
				continue;
			}
			
			bool mapped = true;
			for (CompAlignVec1::iterator alignIter = alignments.begin(); alignIter != alignments.end(); alignIter++)
			{
				CompactAlignment1& alignment = *alignIter;
				if (!alignment.mapped)
				{
					mapped = false;
				}
			}
			if (!mapped)
			{
				continue;
			}
			
			int fragmentIndex = remapFragmentIndices.size();
			remapFragmentIndices.push_back(alignments.front().fragmentName);
			fragmentLibIndices.push_back(libIndex);
			
			CompAlignVec alignments2;
			for (CompAlignVec1::iterator alignIter = alignments.begin(); alignIter != alignments.end(); alignIter++)
			{
				CompactAlignment1& alignment = *alignIter;
				
				CompactAlignment alignment2;
				
				// Remap reference name index to globel indices
				alignment2.refStrand.referenceIndex = referenceNames.Index(libReferenceNames[alignment.refStrand.referenceIndex]);
				alignment2.refStrand.strand = alignment.refStrand.strand;
				
				// Remap fragment index
				alignment2.readID.fragmentIndex = fragmentIndex;
				alignment2.readID.readEnd = alignment.readEnd;

				alignment2.region = alignment.region;
				
				alignments2.push_back(alignment2);
			}
			
			discordantAlignments.AddFragmentAlignments(alignments2);
		}
		
		libFragmentsIter.Close();
	}
	
	// Initialize clusterer
	cout << "Initializing clusterer" << endl;
	MatePairEM clusterer(minClusterSize, precision);
	
	// Open output clusters file
	ofstream clustersFile(clustersFilename.c_str());
	if (!clustersFile)
	{
		cerr << "Error: unable to write to clusters file" << endl;		
		exit(1);
	}
	cout << remapFragmentIndices.size() << endl;
	
	cout << "Creating clusters" << endl;
	
	int clusterID = 0;
	for (DiscordantAlignments::SectorIterator sectorIter = discordantAlignments.SectorsBegin(); sectorIter != discordantAlignments.SectorsEnd(); sectorIter++)
	{
		CompAlignVec alignments1;
		CompAlignVec alignments2;
		discordantAlignments.RetrieveAlignments(sectorIter, alignments1, alignments2);
		
		IntegerVecMap fragments1;
		IntegerVecMap fragments2;
		
		GetFragmentAlignments(alignments1, fragments1);
		GetFragmentAlignments(alignments2, fragments2);
		
		FilterUnmatched(fragments1, fragments2);
		FilterUnmatched(fragments2, fragments1);
		
		FilterOverlapping(fragments1, alignments1, maxFragmentLength);
		FilterOverlapping(fragments2, alignments2, maxFragmentLength);
		
		if (fragments1.size() < minClusterSize || fragments2.size() < minClusterSize)
		{
			continue;
		}
		
		PairIndex alignPairs;
		GetAlignPairs(fragments1, fragments2, alignments1, alignments2, alignPairs);
		
		MatePairEM::MatePairVec matePairs;
		IntegerVec fragmentIndices;
		
		for (int alignPairIndex = 0; alignPairIndex < alignPairs.Size(); alignPairIndex++)
		{
			int alignIndex1 = alignPairs.Get(alignPairIndex).first;
			int alignIndex2 = alignPairs.Get(alignPairIndex).second;
			
			const CompactAlignment& alignment1 = alignments1[alignIndex1];
			const CompactAlignment& alignment2 = alignments2[alignIndex2];
			
			DebugCheck(alignment1.readID.fragmentIndex == alignment2.readID.fragmentIndex);
			
			int libIndex = fragmentLibIndices[alignment1.readID.fragmentIndex];
			
			MatePairEM::MatePair matePair;
			clusterer.CreateMatePair(alignPairIndex, alignment1.region, alignment1.refStrand.strand, alignment2.region, alignment2.refStrand.strand, 
									 fragmentLengthMeans[libIndex], fragmentLengthStdDevs[libIndex], matePair);
			
			matePairs.push_back(matePair);
			
			fragmentIndices.push_back(alignment1.readID.fragmentIndex);
		}
		
		IntegerTable matePairClusters;
		clusterer.DoClustering(matePairs, matePairClusters);
		
		for (int clusterIndex = 0; clusterIndex < matePairClusters.size(); clusterIndex++)
		{
			const IntegerVec& cluster = matePairClusters[clusterIndex];
			
			if (cluster.size() < minClusterSize)
			{
				continue;
			}
			
			unordered_set<int> clusterFragmentIndices;
			for (IntegerVecConstIter elementIter = cluster.begin(); elementIter != cluster.end(); elementIter++)
			{
				IntegerPair alignPair = alignPairs.Get(*elementIter);
				int fragmentIndex = fragmentIndices[*elementIter];
				
				// For fragments with multiple alignments supporting the same cluster, randomly select one alignment
				if (clusterFragmentIndices.find(fragmentIndex) != clusterFragmentIndices.end())
				{
					continue;
				}
				
				clusterFragmentIndices.insert(fragmentIndex);
				
				int alignIndex1 = alignPair.first;
				int alignIndex2 = alignPair.second;
				
				const CompactAlignment& alignment1 = alignments1[alignIndex1];
				const CompactAlignment& alignment2 = alignments2[alignIndex2];
				
				OutputClusterMember(clustersFile, clusterID, 0, alignment1, referenceNames.Get(), remapFragmentIndices, fragmentLibIndices);
				OutputClusterMember(clustersFile, clusterID, 1, alignment2, referenceNames.Get(), remapFragmentIndices, fragmentLibIndices);
			}

			clusterID++;
		}
	}
		
	clustersFile.close();
	
	cout << "Created " << clusterID << " clusters" << endl;
}

