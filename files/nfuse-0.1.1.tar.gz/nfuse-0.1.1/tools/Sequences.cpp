/*
 *  Sequences.cpp
 *
 *  Created by Andrew McPherson on 07/16/11.
 *
 */

#include "Sequences.h"
#include "DebugCheck.h"

#include <fstream>
#include <algorithm>
#include <boost/unordered_map.hpp>

using namespace std;
using namespace boost;

void Sequences::Read(const string& fastaFilename)
{
	ifstream fastaFile(fastaFilename.c_str());
	if (!fastaFile.good())
	{
		cerr << "Error: unable to open file " << fastaFilename << endl;
		exit(1);
	}
	
	string id;
	string sequence;
	
	string line;
	while (getline(fastaFile, line))
	{
		if (line.size() == 0)
		{
			continue;
		}
		
		if (line[0] == '>')
		{
			if (!id.empty())
			{
				mSequences[id] = sequence;
				mNames.push_back(id);
			}
			
			id = line.substr(1);
			sequence = string(mPadding,'N');
		}
		else
		{
			sequence.append(line);
		}
	}
	
	sequence.append(string(mPadding,'N'));
	
	if (!id.empty())
	{
		mSequences[id] = sequence;
		mNames.push_back(id);
	}
}

void Sequences::Get(const string& id, int start, int end, string& sequence) const
{
	if (mSequences.find(id) == mSequences.end())
	{
		cerr << "Error: Unable to find sequence " << id << endl;
		exit(1);
	}
	
	const string& fullSequence = mSequences.find(id)->second;
	int length = end - start + 1;
	
	sequence = fullSequence.substr(start - 1 + mPadding, length);
}

const char* Sequences::Get(const string& id, int pos) const
{
	if (mSequences.find(id) == mSequences.end())
	{
		cerr << "Error: Unable to find sequence " << id << endl;
		exit(1);
	}
	
	const string& fullSequence = mSequences.find(id)->second;
	
	return fullSequence.c_str() + pos - 1 + mPadding;
}

void Sequences::GetRandomSequence(int length, string& sequence) const
{
	while (true)
	{
		int nameIndex = rand() % mNames.size();
		const string& seqName = mNames[nameIndex];
		int seqLength = mSequences.find(seqName)->second.size();
		
		int start = rand() % seqLength;
		int end = start + length;
		
		if (end > seqLength)
		{
			continue;
		}
		
		sequence = mSequences.find(seqName)->second.substr(start, length);
		
		if (sequence.find_first_of("Nn") != string::npos)
		{
			continue;
		}
		
		if (rand() % 2 == 1)
		{
			ReverseComplement(sequence);
		}
		
		break;
	}
}

