/*
 *  SimpleAligner.h
 *
 *  Created by Andrew McPherson on 05/09/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef SIMPLEALIGNER_H_
#define SIMPLEALIGNER_H_

#include "Common.h"
#include "Matrix.h"

#include <string>
#include <vector>

using namespace std;

class SimpleAligner
{
public:
	SimpleAligner(int matchScore, int misMatchScore, int gapScore);
	
	int EndToEndAlign(const string& reference, const string& sequence, const string& quality);
	void PartialAlign(const string& reference, const string& sequence, const string& quality, IntegerVec& scores);
	pair<int,int> Align(const string& reference, const string& sequence);
	void AlignBanded(const string& reference, const string& sequence, int bandWidth, int& score, int& length);
	void AlignBandedFwd(const char* refStart, const char* seqStart, const char* seqEnd, int bandWidth, int& score, int& length);
	void AlignBandedRev(const char* refStart, const char* seqStart, const char* seqEnd, int bandWidth, int& score, int& length);
	int AlignBandedSSE2BW7ScoreFwd(const char* refStart, const char* seqStart, const char* seqEnd);
	int AlignBandedSSE2BW15ScoreFwd(const char* refStart, const char* seqStart, const char* seqEnd);
	int AlignBandedSSE2BW7ScoreRev(const char* refStart, const char* seqStart, const char* seqEnd);
	int AlignBandedSSE2BW15ScoreRev(const char* refStart, const char* seqStart, const char* seqEnd);
	void AlignPrint(const string& seq1, const string& seq2);

private:
	int mMatchScore;
	int mMisMatchScore;
	int mGapScore;
	int mBandWidth;
	
	vector<int> mCurrent;
	vector<int> mPrevious;
	
	vector<int> mD0;
	vector<int> mD1;
	vector<int> mP0;
	vector<int> mP1;
	vector<int> mQ0;
	vector<int> mQ1;
	
	vector<unsigned char> mScoreBuffer8;
	vector<short int> mScoreBuffer16;
};

#endif

