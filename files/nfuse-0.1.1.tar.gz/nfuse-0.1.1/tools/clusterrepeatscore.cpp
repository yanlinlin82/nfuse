/*
 *  clustermatepairs.cpp
 *
 *  Created by Andrew McPherson on 28/09/09.
 *
 */

#include "Common.h"
#include "DebugCheck.h"
#include "Sequences.h"
#include "SimpleAligner.h"
#include "Parsers.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

using namespace boost;
using namespace std;


struct CompactPosition
{
	RefStrand refStrand;
	int position;
};

typedef vector<CompactPosition> CompPosVec;
typedef vector<CompactPosition>::iterator CompPosVecIter;
typedef vector<CompactPosition>::const_iterator CompPosVecConstIter;

int main(int argc, char* argv[])
{
	int matchScore;
	int misMatchScore;
	int gapScore;
	int searchLength;
	string referenceFasta;
	
	try
	{
		TCLAP::CmdLine cmd("Mate Realignment Tool");
		TCLAP::ValueArg<int> matchScoreArg("m","match","Match Score",true,0,"int",cmd);
		TCLAP::ValueArg<int> misMatchScoreArg("x","mismatch","Mismatch Score",true,0,"int",cmd);
		TCLAP::ValueArg<int> gapScoreArg("g","gap","Gap Score",true,0,"int",cmd);
		TCLAP::ValueArg<int> searchLengthArg("s","searchlength","Search Length",true,-1,"integer",cmd);
		TCLAP::ValueArg<string> referenceFastaArg("r","reference","Reference Sequences Fasta",true,"","string",cmd);
		cmd.parse(argc,argv);
		
		matchScore = matchScoreArg.getValue();
		misMatchScore = misMatchScoreArg.getValue();
		gapScore = gapScoreArg.getValue();
		searchLength = searchLengthArg.getValue();
		referenceFasta = referenceFastaArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	SimpleAligner aligner(matchScore, misMatchScore, gapScore);
	
	Sequences referenceSequences;
	referenceSequences.Read(referenceFasta);
	
	ClusterReader clusterReader(cin);
	
	int clusterID;
	LocationVec clusterLocations(2);
	IntegerVec fragmentIndices;
	while (clusterReader.Next(clusterID, clusterLocations, fragmentIndices))
	{
		for (int clusterEnd = 0; clusterEnd <= 1; clusterEnd++)
		{
			const string& refName = clusterLocations[clusterEnd].refName;
			int strand = clusterLocations[clusterEnd].strand;
			int midpoint = (clusterLocations[clusterEnd].start + clusterLocations[clusterEnd].end) / 2;
			int start = (strand == PlusStrand) ? midpoint : midpoint - searchLength;
			int end = (strand == PlusStrand) ? midpoint + searchLength : midpoint;
			
			string searchSequence;
			referenceSequences.Get(refName, start, end, searchSequence);
			
			int otherClusterEnd = 1 - clusterEnd;
			const string& otherRefName = clusterLocations[otherClusterEnd].refName;
			int otherStrand = clusterLocations[otherClusterEnd].strand;
			int otherStart = clusterLocations[otherClusterEnd].start;
			int otherEnd = clusterLocations[otherClusterEnd].end;
			
			string otherSequence;
			referenceSequences.Get(otherRefName, otherStart, otherEnd, otherSequence);
			
			if (strand == otherStrand)
			{
				ReverseComplement(searchSequence);				
			}
			
			int score = aligner.Align(searchSequence, otherSequence).first;
			
			int maxScore = otherSequence.size() * matchScore;
			double percent = (double) score / (double) maxScore;
			
			cout << clusterID << "\t" << clusterEnd << "\t" << score << "\t" << percent << endl;
		}
	}
}

