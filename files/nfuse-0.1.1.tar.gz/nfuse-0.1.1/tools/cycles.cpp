/*
 *  cycles.cpp
 */

#include "Common.h"
#include "DebugCheck.h"
#include "ShortestPath.h"
#include "BreakpointGraph.h"
#include "Parsers.h"
#include "Indexer.h"

#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <tclap/CmdLine.h>
#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/unordered_set.hpp>

using namespace boost;
using namespace std;


bool FindPath(BreakpointGraph* breakpointGraph, int clusterID, double clusterScore, int visitMax, double scoreMax, unordered_set<pair<unsigned int,int> > blocked, vector<pair<unsigned int,int> >& cycle, double& cycleScore, int& numVisited)
{
	breakpointGraph->Reset();
	
	unsigned int startVertex;
	unsigned int endVertex;
	if (!breakpointGraph->SetCycleSearch(clusterID, startVertex, endVertex))
	{
		return false;
	}
	
	for (unordered_set<pair<unsigned int,int> >::const_iterator blockedIter = blocked.begin(); blockedIter != blocked.end(); blockedIter++)
	{
		breakpointGraph->BlockVertex(blockedIter->first, blockedIter->second);
	}
	
	vector<unsigned int> path;
	double pathScore;
	if (ShortestPath(breakpointGraph, startVertex, endVertex, visitMax, scoreMax - clusterScore, path, pathScore, numVisited))
	{
		cycleScore = pathScore + clusterScore;
		
		if (path.size() <= 2)
		{
			return false;
		}
		
		for (vector<unsigned int>::const_iterator vertexIter = path.begin(); vertexIter != path.end(); vertexIter++)
		{
			cycle.push_back(pair<unsigned int,int>(breakpointGraph->GetClusterID(*vertexIter),breakpointGraph->GetClusterEnd(*vertexIter)));
		}
		
		return true;
	}
	else
	{
		return false;
	}
}

bool PrintCycle(const vector<pair<unsigned int,int> >& cycle, double cycleScore, int numVisited)
{
	cerr << "Found cycle in " << numVisited << endl;
	
	cout << cycleScore << "\t";
	
	for (vector<pair<unsigned int,int> >::const_iterator clusterIDIter = cycle.begin(); clusterIDIter != cycle.end(); clusterIDIter++)
	{
		cout << clusterIDIter->first << "\t" << clusterIDIter->second << "\t";
	}
	
	cout << endl;	
}

int main(int argc, char* argv[])
{
	string clustersFilename;
	string probsFilename;
	int singleClusterID;
	string listOfClusterIDsFilename;
	double distanceLambda;
	int visitMax;
	double scoreMax;
	
	try
	{
		TCLAP::CmdLine cmd("Search for cycles in the breakpoint graph");
		TCLAP::ValueArg<string> clustersFilenameArg("c","clusters","Clusters Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> probsFilenameArg("p","probs","Cluster Probabilities Filename",true,"","string",cmd);
		TCLAP::ValueArg<int> singleClusterIDArg("i","idstart","Starting Cluster ID",false,-1,"integer",cmd);
		TCLAP::ValueArg<string> listOfClusterIDsFilenameArg("l","listofids","List of Starting Cluster IDs",false,"","string",cmd);
		TCLAP::ValueArg<double> distanceLambdaArg("y","lambda","Distance Falloff Parameter Lambda",false,2000.0,"float",cmd);
		TCLAP::ValueArg<int> visitMaxArg("v","visitmax","Maximum Number of Vertices to Visit",false,100000,"integer",cmd);
		TCLAP::ValueArg<double> scoreMaxArg("s","scoremax","Maximum Score for Cycles",false,30.0,"float",cmd);
		cmd.parse(argc,argv);
		
		clustersFilename = clustersFilenameArg.getValue();
		probsFilename = probsFilenameArg.getValue();
		singleClusterID = singleClusterIDArg.getValue();
		listOfClusterIDsFilename = listOfClusterIDsFilenameArg.getValue();
		distanceLambda = distanceLambdaArg.getValue();
		visitMax = visitMaxArg.getValue();
		scoreMax = scoreMaxArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	IntegerVec startClustersIDs;
	
	if (singleClusterID != -1)
	{
		startClustersIDs.push_back(singleClusterID);
	}
	else if (listOfClusterIDsFilename != "")
	{
		ifstream listOfClusterIDsFile(listOfClusterIDsFilename.c_str());
		CheckFile(listOfClusterIDsFile, listOfClusterIDsFilename);
		
		// Parse file contents
		string line;
		int lineNumber = 0;
		while (getline(listOfClusterIDsFile, line))
		{
			lineNumber++;
			
			if (line.length() == 0)
			{
				cerr << "Error: Empty clusters line " << lineNumber << " of " << listOfClusterIDsFilename << endl;
				exit(1);
			}
			
			int clusterID = lexical_cast<int>(line);
			
			startClustersIDs.push_back(clusterID);
		}
		
		listOfClusterIDsFile.close();
	}
	
	cerr << "Reading clusters" << endl;
	
	CompactLocationVecMap dnaClusters;
	NameIndex references;
	ReadClusters(clustersFilename, dnaClusters, references);
	
	cerr << "Reading cluster probabilities" << endl;
	
	DoubleMap dnaClusterProb;
	ReadDoubleMap(probsFilename, dnaClusterProb);
	
	cerr << "Creating breakpoint graph" << endl;
	
	BreakpointGraph breakpointGraph(distanceLambda, distanceLambda);
	for (CompactLocationVecMapConstIter dnaClusterIter = dnaClusters.begin(); dnaClusterIter != dnaClusters.end(); dnaClusterIter++)
	{
		DebugCheck(dnaClusterIter->second.size() == 2);
		
		unsigned int refID1 = dnaClusterIter->second[0].refStrand.referenceIndex;
		int strand1 = dnaClusterIter->second[0].refStrand.strand;
		unsigned int position1 = (strand1 == PlusStrand) ? dnaClusterIter->second[0].region.end : dnaClusterIter->second[0].region.start;
		
		unsigned int refID2 = dnaClusterIter->second[1].refStrand.referenceIndex;
		int strand2 = dnaClusterIter->second[1].refStrand.strand;
		unsigned int position2 = (strand2 == PlusStrand) ? dnaClusterIter->second[1].region.end : dnaClusterIter->second[1].region.start;
		
		breakpointGraph.AddBreakpoint(dnaClusterIter->first, refID1, strand1, position1, refID2, strand2, position2, -log(dnaClusterProb[dnaClusterIter->first]));
	}
	breakpointGraph.ConstructGraph();
	
	if (startClustersIDs.empty())
	{
		for (DoubleMapConstIter dnaClusterIter = dnaClusterProb.begin(); dnaClusterIter != dnaClusterProb.end(); dnaClusterIter++)
		{
			if (dnaClusterIter->second > 0.1)
			{
				startClustersIDs.push_back(dnaClusterIter->first);
			}
		}
	}
	
	cerr << "Starting search on " << startClustersIDs.size() << " clusters" << endl;
	
	for (IntegerVecConstIter clusterIDIter = startClustersIDs.begin(); clusterIDIter != startClustersIDs.end(); clusterIDIter++)
	{
		int clusterID = *clusterIDIter;
		
		unordered_set<pair<unsigned int,int> > blockedEmpty;
		
		vector<pair<unsigned int,int> > cycle;
		double cycleScore;
		int numVisited;
		
		if (!FindPath(&breakpointGraph, clusterID, -log(dnaClusterProb[clusterID]), visitMax, scoreMax, blockedEmpty, cycle, cycleScore, numVisited))
		{
			cerr << "No Cycle" << endl;
			continue;
		}
		else
		{
			PrintCycle(cycle, cycleScore, numVisited);			
		}
		
/*		for (vector<pair<unsigned int,int> >::const_iterator clusterIDIter = cycle.begin(); clusterIDIter != cycle.end(); clusterIDIter++)
		{
			if (clusterID == clusterIDIter->first)
			{
				continue;
			}
			
			unordered_set<pair<unsigned int,int> > blocked;
			blocked.insert(*clusterIDIter);
			
			vector<pair<unsigned int,int> > altCycle;
			double altCycleScore;
			int altNumVisited;
			
			if (FindPath(&breakpointGraph, clusterID, -log(dnaClusterProb[clusterID]), visitMax, scoreMax, blocked, altCycle, altCycleScore, altNumVisited))
			{
				PrintCycle(altCycle, altCycleScore, altNumVisited);			
			}
		}
*/
	}
}


