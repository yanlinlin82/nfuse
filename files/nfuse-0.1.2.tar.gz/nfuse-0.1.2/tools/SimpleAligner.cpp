/*
 *  SimpleAligner.cpp
 *
 *  Created by Andrew McPherson on 05/09/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#include "SimpleAligner.h"
#include "DebugCheck.h"

#include <iostream>
#include <list>
#include <xmmintrin.h>
#include <emmintrin.h>
#include <mmintrin.h>

using namespace std;


SimpleAligner::SimpleAligner(int matchScore, int misMatchScore, int gapScore)
: mMatchScore(matchScore), mMisMatchScore(misMatchScore), mGapScore(gapScore), mScoreBuffer8(2000), mScoreBuffer16(2000)
{
}

/*
 --ma <int>
 Sets the match bonus. In --local mode <int> is added to the alignment score for each position where a read character aligns
 to a reference character and the characters match. Not used in --end-to-end mode. Default: 2.
 
 --mp MX,MN
 Sets the maximum (MX) and minimum (MN) mismatch penalties, both integers. A number less than or equal to MX and greater than
 or equal to MN is subtracted from the alignment score for each position where a read character aligns to a reference character,
 the characters do not match, and neither is an N. If --ignore-quals is specified, the number subtracted quals MX. Otherwise, 
 the number subtracted is MN + floor( (MX-MN)(MIN(Q, 40.0)/40.0) ) where Q is the Phred quality value. Default: MX = 6, MN = 2.
 
 --np <int>
 Sets penalty for positions where the read, reference, or both, contain an ambiguous character such as N. Default: 1.
 
 --rdg <int1>,<int2>
 Sets the read gap open (<int1>) and extend (<int2>) penalties. A read gap of length N gets a penalty of <int1> + N * <int2>. 
 Default: 5, 3.
 
 --rfg <int1>,<int2>
 Sets the reference gap open (<int1>) and extend (<int2>) penalties. A reference gap of length N gets a penalty of <int1> + N * <int2>. 
 Default: 5, 3.
 
 --score-min <func>
 Sets a function governing the minimum alignment score needed for an alignment to be considered "valid" (i.e. good enough to report). 
 This is a function of read length. For instance, specifying L,0,-0.6 sets the minimum-score function f to f(x) = 0 + -0.6 * x, where
 x is the read length. See also: setting function options. The default in --end-to-end mode is L,-0.6,-0.6 and the default in --local mode is G,20,8.
*/

int SimpleAligner::EndToEndAlign(const string& reference, const string& sequence, const string& quality)
{
	const int ma = 0;
	const int mx = 6;
	const int mn = 2;
	const int rdgo = 5;
	const int rdge = 3;
	const int rfgo = 5;
	const int rfge = 3;
	
	int minscore = -(mx + rdgo + rdge + rfgo + rfge) * sequence.length();
	
	int matrixLength = reference.size() + 1;
	int matrixHeight = sequence.size() + 1;
	
	if (matrixLength != mD0.size())
	{
		mD0.resize(matrixLength);
		mD1.resize(matrixLength);
		mP0.resize(matrixLength);
		mP1.resize(matrixLength);
		mQ0.resize(matrixLength);
		mQ1.resize(matrixLength);
	}
	
	int score = numeric_limits<int>::min();
	
	for (int j = 0; j < matrixHeight; j++)
	{
		int seqPos = j - 1;
		
		for (int i = 0; i < matrixLength; i++) 
		{
			int refPos = i - 1;
			
			if (j == 0)
			{
				mP1[i] = minscore;
				mQ1[i] = minscore;
				mD1[i] = 0;
			}
			else if (i == 0)
			{
				mP1[i] = minscore;
				mQ1[i] = minscore;
				mD1[i] = -rdgo - j * rdge;
			}
			else
			{
				double q = (double)(quality[seqPos] - 33);
				int mmp = (int)(mn + floor((mx-mn)*(min(q,40.0)/40.0)));
				int ms = (reference[refPos] == sequence[seqPos]) ? ma : -mmp;
				
				mP1[i] = max(mD1[i-1] - rfgo - rfge, mP1[i-1] - rfge);
				mQ1[i] = max(mD0[i] - rdgo - rdge, mQ0[i] - rdge);
				mD1[i] = max(mD0[i-1] + ms, max(mP1[i], mQ1[i]));
				
				if (j + 1 == matrixHeight && mD1[i] > score)
				{
					score = mD1[i];
				}
			}
		}
		
		swap(mP1, mP0);
		swap(mQ1, mQ0);
		swap(mD1, mD0);
	}
	
	return score;
}

void SimpleAligner::PartialAlign(const string& reference, const string& sequence, const string& quality, IntegerVec& scores)
{
	const int ma = 0;
	const int mx = 6;
	const int mn = 2;
	const int rdgo = 5;
	const int rdge = 3;
	const int rfgo = 5;
	const int rfge = 3;
	
	int minscore = -(mx + rdgo + rdge + rfgo + rfge) * sequence.length();
	
	int matrixLength = reference.size() + 1;
	int matrixHeight = sequence.size() + 1;
	
	if (matrixLength != mD0.size())
	{
		mD0.resize(matrixLength);
		mD1.resize(matrixLength);
		mP0.resize(matrixLength);
		mP1.resize(matrixLength);
		mQ0.resize(matrixLength);
		mQ1.resize(matrixLength);
	}
	
	scores.resize(sequence.length());
	
	for (int j = 0; j < matrixHeight; j++)
	{
		int seqPos = j - 1;
		
		int score = numeric_limits<int>::min();
		
		for (int i = 0; i < matrixLength; i++) 
		{
			int refPos = i - 1;
			
			if (j == 0)
			{
				mP1[i] = minscore;
				mQ1[i] = minscore;
				mD1[i] = 0;
			}
			else if (i == 0)
			{
				mP1[i] = minscore;
				mQ1[i] = minscore;
				mD1[i] = -rdgo - j * rdge;
			}
			else
			{
				double q = (double)(quality[seqPos] - 33);
				int mmp = (int)(mn + floor((mx-mn)*(min(q,40.0)/40.0)));
				int ms = (reference[refPos] == sequence[seqPos]) ? ma : -mmp;
				
				mP1[i] = max(mD1[i-1] - rfgo - rfge, mP1[i-1] - rfge);
				mQ1[i] = max(mD0[i] - rdgo - rdge, mQ0[i] - rdge);
				mD1[i] = max(mD0[i-1] + ms, max(mP1[i], mQ1[i]));
				
				if (mD1[i] > score)
				{
					score = mD1[i];
				}
			}
		}
		
		swap(mP1, mP0);
		swap(mQ1, mQ0);
		swap(mD1, mD0);
		
		if (seqPos >= 0)
		{
			scores[seqPos] = score;
		}
	}
}

pair<int,int> SimpleAligner::Align(const string& reference, const string& sequence)
{
	int matrixLength = reference.size() + 1;
	int matrixHeight = sequence.size() + 1;
	
	if (matrixLength != mCurrent.size())
	{
		mCurrent.resize(matrixLength);
		mPrevious.resize(matrixLength);
	}
	
	int score = 0;
	int length = 0;
	
	for (int j = 0; j < matrixHeight; j++)
	{
		int seqPos = j - 1;
		
		for (int i = 0; i < matrixLength; i++) 
		{
			int refPos = i - 1;
			
			if (j == 0)
			{
				mCurrent[i] = 0;
			}
			else if (i == 0)
			{
				mCurrent[i] = mPrevious[i] + mGapScore;
			}
			else
			{
				int matchScore = mPrevious[i-1] + ((reference[refPos] == sequence[seqPos]) ? mMatchScore : mMisMatchScore);
				int gapRefScore = mCurrent[i-1] + mGapScore;
				int gapReadScore = mPrevious[i] + mGapScore;
				int bestScore = max(matchScore,max(gapRefScore,gapReadScore));
				
				if (bestScore > score)
				{
					score = bestScore;
					length = seqPos + 1;
				}
				
				mCurrent[i] = bestScore;
			}
		}
		
		swap(mCurrent, mPrevious);
	}
	
	return pair<int,int>((int)score,(int)length);
}

struct convertsse
{
	union
	{
		__m128i sse;
		unsigned char array8[16];
		short int array16[8];
	};
	
	void print16()
	{
		for (int i = 0; i < 8; i++)
		{
			cout << array16[i] << "\t";
		}
		cout << endl;
	}
};

struct matprint
{
	matprint()
	{
		matrix[pair<int,int>(0,0)] = 0;
		matrix[pair<int,int>(0,1)] = -1;
		matrix[pair<int,int>(1,0)] = -1;
		diag = 1;
		
	}
	
	void add(int a, int b, int score)
	{
		matrix[pair<int,int>(a,b)] = score;
	}
	
	void next8(__m128i nextScoreOdd, __m128i nextScoreEven)
	{
		convertsse nodd;
		nodd.sse = nextScoreOdd;
		convertsse neven;
		neven.sse = nextScoreEven;
		
		for (int i = 0; i <= 15; i++)
		{
			int a = diag - i + 7;
			int b = diag + i - 7;
			if (a < 0 || b < 0)
			{
				continue;
			}
			//			cout << a << "\t" << b << "\t" << nodd.array[i] - 0x30 << endl;
			matrix[pair<int,int>(a,b)] = nodd.array8[i] - 0x30;
		}
		
		for (int i = 0; i <= 15; i++)
		{
			int a = diag - i + 8;
			int b = diag + i - 7;
			if (a < 0 || b < 0)
			{
				continue;
			}
			//			cout << a << "\t" << b << "\t" << nodd.array[i] - 0x30 << endl;
			matrix[pair<int,int>(a,b)] = neven.array8[i] - 0x30;
		}
		
		diag++;
	}
	
	void next16(__m128i nextScoreOdd, __m128i nextScoreEven)
	{
		convertsse nodd;
		nodd.sse = nextScoreOdd;
		convertsse neven;
		neven.sse = nextScoreEven;
		
		for (int i = 0; i <= 7; i++)
		{
			int a = diag - i + 3;
			int b = diag + i - 3;
			if (a < 0 || b < 0)
			{
				continue;
			}
			//			cout << a << "\t" << b << "\t" << nodd.array[i] - 0x30 << endl;
			matrix[pair<int,int>(a,b)] = nodd.array16[i];
		}
		
		for (int i = 0; i <= 7; i++)
		{
			int a = diag - i + 4;
			int b = diag + i - 3;
			if (a < 0 || b < 0)
			{
				continue;
			}
			//			cout << a << "\t" << b << "\t" << nodd.array[i] - 0x30 << endl;
			matrix[pair<int,int>(a,b)] = neven.array16[i];
		}
		
		diag++;
	}
	
	void printfwd(int bandWidth, const char* refStart, const char* seqStart, const char* seqEnd)
	{
		int matrixLength = seqEnd - seqStart + 1 + bandWidth;
		int matrixHeight = seqEnd - seqStart + 1;
		
		cout << "\t\t";
		for (int j = 1; j < matrixLength; j++)
		{
			cout << refStart[j-1] << "\t";
		}
		cout << endl;
		
		for (int i = 0; i < matrixHeight; i++)
		{
			if (i == 0)
			{
				cout << "\t";
			}
			else
			{
				cout << seqEnd[-i] << "\t";
			}
			
			for (int j = 0; j < matrixLength; j++)
			{
				if (matrix.find(pair<int,int>(j,i)) == matrix.end())
				{
					cout << " \t";
				}
				else
				{
					cout << matrix.find(pair<int,int>(j,i))->second << "\t";
				}
			}
			
			cout << endl;
		}
	}
	
	void print(int maxsize)
	{
		for (int i = 0; i < maxsize; i++)
		{
			for (int j = 0; j < maxsize; j++)
			{
				if (matrix.find(pair<int,int>(i,j)) == matrix.end())
				{
					cout << " \t";
				}
				else
				{
					cout << matrix.find(pair<int,int>(i,j))->second << "\t";
				}
			}
			
			cout << endl;
		}
	}
	
	unordered_map<pair<int,int>,int> matrix;
	int diag;
};

int SimpleAligner::AlignBandedSSE2BW15ScoreFwd(const char* refStart, const char* seqStart, const char* seqEnd)
{
	unsigned char* scorePtr = &mScoreBuffer8.front() + mScoreBuffer8.size() - 16;
	
	__m128i ones = {0x0101010101010101,0x0101010101010101};
	
	// offset is 0x30
	
	__m128i scoreOdd = {0x3000000000000000,0};
	__m128i scoreEven = {0x2f00000000000000,0x000000000000002f};
	
	__m128i maxScore = {0,0};
	
	const char* fwdPtr = refStart - 7;
	const char* revPtr = seqEnd - 8;
	
	while (revPtr >= seqStart - 15)
	{
		__m128i fwdOdd = _mm_loadu_si128((__m128i*)fwdPtr);
		__m128i revOdd = _mm_loadu_si128((__m128i*)revPtr);
		
		__m128i cmpOdd = _mm_cmpeq_epi8(fwdOdd,revOdd);
		
		// matchOdd = scoreOdd + cmpOdd ? 1 : -1
		__m128i matchOdd = _mm_sub_epi8(_mm_add_epi8(scoreOdd,_mm_and_si128(cmpOdd,ones)),_mm_andnot_si128(cmpOdd,ones));
		
		// gapOdd = scoreEven - 1
		__m128i gapOdd = _mm_sub_epi8(scoreEven,ones);
		
		// clamp matchOdd
		matchOdd = _mm_sub_epi8(matchOdd,_mm_cmpeq_epi8(matchOdd,_mm_sub_epi8(_mm_xor_si128(ones,ones),ones)));
		
		// clamp gapOdd
		gapOdd = _mm_sub_epi8(gapOdd,_mm_cmpeq_epi8(gapOdd,_mm_sub_epi8(_mm_xor_si128(ones,ones),ones)));
		
		// max
		__m128i nextScoreOdd = _mm_max_epu8(matchOdd,_mm_max_epu8(_mm_srli_si128(gapOdd,1),gapOdd));
		
		revPtr--;
		
		__m128i fwdEven = _mm_loadu_si128((__m128i*)fwdPtr);
		__m128i revEven = _mm_loadu_si128((__m128i*)revPtr);
		
		__m128i cmpEven = _mm_cmpeq_epi8(fwdEven,revEven);
		
		// matchEven = scoreEven + cmpEven ? 1 : -1
		__m128i matchEven = _mm_sub_epi8(_mm_add_epi8(scoreEven,_mm_and_si128(cmpEven,ones)),_mm_andnot_si128(cmpEven,ones));
		
		// gapEven = scoreOdd - 1
		__m128i gapEven = _mm_sub_epi8(nextScoreOdd,ones);
		
		// clamp matchEven
		matchEven = _mm_sub_epi8(matchEven,_mm_cmpeq_epi8(matchEven,_mm_sub_epi8(_mm_xor_si128(ones,ones),ones)));
		
		// clamp gapEven
		gapEven = _mm_sub_epi8(gapEven,_mm_cmpeq_epi8(gapEven,_mm_sub_epi8(_mm_xor_si128(ones,ones),ones)));
		
		// max
		__m128i nextScoreEven = _mm_max_epu8(matchEven,_mm_max_epu8(_mm_slli_si128(gapEven,1),gapEven));
		
		fwdPtr++;
		
		scoreOdd = nextScoreOdd;
		scoreEven = nextScoreEven;
		
		maxScore = _mm_max_epu8(maxScore,nextScoreOdd);
		maxScore = _mm_slli_si128(maxScore,1);
		maxScore = _mm_max_epu8(maxScore,nextScoreEven);
		
		_mm_storeu_si128((__m128i*)scorePtr,maxScore);
		scorePtr--;
	}
	
	int bestScore = 0;
	int previousBestScore = 0;
	
	int increaseCount = 0;
	int plateauCount = 0;
	
	int bestChangepointScore = 0;
	int bestChangepointLength = 0;
	
	int scoreStart = mScoreBuffer8.size() - 8;
	for (int i = scoreStart; i > scoreStart - (seqEnd - seqStart); i--)
	{
		int score = (int)mScoreBuffer8[i] - 0x30;
		bestScore = max(bestScore, score);
		
		if (bestScore > previousBestScore)
		{
			increaseCount++;
		}
		else
		{
			plateauCount++;
		}
		
		int changepointScore = increaseCount - plateauCount;
		
		if (changepointScore > bestChangepointScore)
		{
			bestChangepointScore = changepointScore;
			bestChangepointLength = scoreStart + 1 - i;
		}
		
		previousBestScore = bestScore;
	}
	
	return bestChangepointScore;
}

int SimpleAligner::AlignBandedSSE2BW7ScoreFwd(const char* refStart, const char* seqStart, const char* seqEnd)
{
	short int* scorePtr = &mScoreBuffer16.front() + mScoreBuffer16.size() - 8;
	
	__m128i ones = {0x0001000100010001,0x0001000100010001};
	__m128i shiftRight = {0,0x8800000000000000};
	__m128i shiftLeft = {0x0000000000008800,0};
	
	// offset is 0x30
	
	__m128i scoreOdd = {0x0000880088008800,0x8800880088008800};
	__m128i scoreEven = {0xffff880088008800,0x880088008800ffff};
	
	__m128i maxScore = {0,0};
	
	const char* fwdPtr = refStart - 3;
	const char* revPtr = seqEnd - 4;
	
	while (revPtr >= seqStart - 7)
	{
		__m128i fwdOdd = _mm_loadu_si128((__m128i*)fwdPtr);
		__m128i revOdd = _mm_loadu_si128((__m128i*)revPtr);
		
		__m128i cmpOdd8 = _mm_cmpeq_epi8(fwdOdd,revOdd);
		__m128i cmpOdd = _mm_unpacklo_epi8(cmpOdd8,cmpOdd8);
		
		// matchOdd = scoreOdd + cmpOdd ? 1 : -1
		__m128i matchOdd = _mm_sub_epi16(_mm_add_epi16(scoreOdd,_mm_and_si128(cmpOdd,ones)),_mm_andnot_si128(cmpOdd,ones));
		
		// gapOdd = scoreEven - 1
		__m128i gapOdd = _mm_sub_epi16(scoreEven,ones);
		
		// max
		__m128i nextScoreOdd = _mm_max_epi16(matchOdd,_mm_max_epi16(_mm_or_si128(_mm_srli_si128(gapOdd,2),shiftRight),gapOdd));
		
		revPtr--;
		
		__m128i fwdEven = _mm_loadu_si128((__m128i*)fwdPtr);
		__m128i revEven = _mm_loadu_si128((__m128i*)revPtr);
		
		__m128i cmpEven8 = _mm_cmpeq_epi8(fwdEven,revEven);
		__m128i cmpEven = _mm_unpacklo_epi8(cmpEven8,cmpEven8);
		
		// matchEven = scoreEven + cmpEven ? 1 : -1
		__m128i matchEven = _mm_sub_epi16(_mm_add_epi16(scoreEven,_mm_and_si128(cmpEven,ones)),_mm_andnot_si128(cmpEven,ones));
		
		// gapEven = scoreOdd - 1
		__m128i gapEven = _mm_sub_epi16(nextScoreOdd,ones);
		
		// max
		__m128i nextScoreEven = _mm_max_epi16(matchEven,_mm_max_epi16(_mm_or_si128(_mm_slli_si128(gapEven,2),shiftLeft),gapEven));
		
		fwdPtr++;
		
		scoreOdd = nextScoreOdd;
		scoreEven = nextScoreEven;
		
		maxScore = _mm_max_epi16(maxScore,nextScoreOdd);
		maxScore = _mm_slli_si128(maxScore,2);
		maxScore = _mm_max_epi16(maxScore,nextScoreEven);
		
		_mm_storeu_si128((__m128i*)scorePtr,maxScore);
		scorePtr--;
	}
	
	int bestScore = 0;
	int previousBestScore = 0;
	
	int increaseCount = 0;
	int plateauCount = 0;
	
	int bestChangepointScore = 0;
	int bestChangepointLength = 0;
	
	int scoreStart = mScoreBuffer16.size() - 4;
	for (int i = scoreStart; i > scoreStart - (seqEnd - seqStart); i--)
	{
		int score = mScoreBuffer16[i];
		bestScore = max(bestScore, score);
		
		if (bestScore > previousBestScore)
		{
			increaseCount++;
		}
		else
		{
			plateauCount++;
		}
		
		int changepointScore = increaseCount - plateauCount;
		
		if (changepointScore > bestChangepointScore)
		{
			bestChangepointScore = changepointScore;
			bestChangepointLength = scoreStart + 1 - i;
		}
		
		previousBestScore = bestScore;
	}
	
	return bestChangepointScore;
}

int SimpleAligner::AlignBandedSSE2BW15ScoreRev(const char* refStart, const char* seqStart, const char* seqEnd)
{
	unsigned char* scorePtr = &mScoreBuffer8.front();
	
	__m128i ones = {0x0101010101010101,0x0101010101010101};
	
	// offset is 0x30
	
	__m128i scoreOdd = {0x3000000000000000,0};
	__m128i scoreEven = {0x2f00000000000000,0x000000000000002f};
	
	__m128i maxScore = {0,0};
	
	const char* fwdPtr = seqStart - 7;
	const char* revPtr = refStart - 7;
	
	while (fwdPtr <= seqEnd - 1)
	{
		__m128i fwdOdd = _mm_loadu_si128((__m128i*)fwdPtr);
		__m128i revOdd = _mm_loadu_si128((__m128i*)revPtr);
		
		__m128i cmpOdd = _mm_cmpeq_epi8(fwdOdd,revOdd);
		
		// matchOdd = scoreOdd + cmpOdd ? 1 : -1
		__m128i matchOdd = _mm_sub_epi8(_mm_add_epi8(scoreOdd,_mm_and_si128(cmpOdd,ones)),_mm_andnot_si128(cmpOdd,ones));
		
		// gapOdd = scoreEven - 1
		__m128i gapOdd = _mm_sub_epi8(scoreEven,ones);
		
		// clamp matchOdd
		matchOdd = _mm_sub_epi8(matchOdd,_mm_cmpeq_epi8(matchOdd,_mm_sub_epi8(_mm_xor_si128(ones,ones),ones)));
		
		// clamp gapOdd
		gapOdd = _mm_sub_epi8(gapOdd,_mm_cmpeq_epi8(gapOdd,_mm_sub_epi8(_mm_xor_si128(ones,ones),ones)));
		
		// max
		__m128i nextScoreOdd = _mm_max_epu8(matchOdd,_mm_max_epu8(_mm_srli_si128(gapOdd,1),gapOdd));
		
		revPtr--;
		
		__m128i fwdEven = _mm_loadu_si128((__m128i*)fwdPtr);
		__m128i revEven = _mm_loadu_si128((__m128i*)revPtr);
		
		__m128i cmpEven = _mm_cmpeq_epi8(fwdEven,revEven);
		
		// matchEven = scoreEven + cmpEven ? 1 : -1
		__m128i matchEven = _mm_sub_epi8(_mm_add_epi8(scoreEven,_mm_and_si128(cmpEven,ones)),_mm_andnot_si128(cmpEven,ones));
		
		// gapEven = scoreOdd - 1
		__m128i gapEven = _mm_sub_epi8(nextScoreOdd,ones);
		
		// clamp matchEven
		matchEven = _mm_sub_epi8(matchEven,_mm_cmpeq_epi8(matchEven,_mm_sub_epi8(_mm_xor_si128(ones,ones),ones)));
		
		// clamp gapEven
		gapEven = _mm_sub_epi8(gapEven,_mm_cmpeq_epi8(gapEven,_mm_sub_epi8(_mm_xor_si128(ones,ones),ones)));
		
		// max
		__m128i nextScoreEven = _mm_max_epu8(matchEven,_mm_max_epu8(_mm_slli_si128(gapEven,1),gapEven));
		
		fwdPtr++;
		
		scoreOdd = nextScoreOdd;
		scoreEven = nextScoreEven;
		
		maxScore = _mm_srli_si128(maxScore,1);
		maxScore = _mm_max_epu8(maxScore,nextScoreOdd);
		maxScore = _mm_max_epu8(maxScore,nextScoreEven);
		
		_mm_storeu_si128((__m128i*)scorePtr,maxScore);
		scorePtr++;
	}
	
	int bestScore = 0;
	int previousBestScore = 0;
	
	int increaseCount = 0;
	int plateauCount = 0;
	
	int bestChangepointScore = 0;
	int bestChangepointLength = 0;
	
	for (int i = 7; i < 7 + (seqEnd - seqStart); i++)
	{
		int score = (int)mScoreBuffer8[i] - 0x30;
		bestScore = max(bestScore, score);
		
		if (bestScore > previousBestScore)
		{
			increaseCount++;
		}
		else
		{
			plateauCount++;
		}
		
		int changepointScore = increaseCount - plateauCount;
		
		if (changepointScore > bestChangepointScore)
		{
			bestChangepointScore = changepointScore;
			bestChangepointLength = i - 6;
		}
		
		previousBestScore = bestScore;
	}
	
	return bestChangepointScore;
}

int SimpleAligner::AlignBandedSSE2BW7ScoreRev(const char* refStart, const char* seqStart, const char* seqEnd)
{
	short int* scorePtr = &mScoreBuffer16.front();
	
	__m128i ones = {0x0001000100010001,0x0001000100010001};
	__m128i shiftRight = {0,0x8800000000000000};
	__m128i shiftLeft = {0x0000000000008800,0};
	
	// offset is 0x30
	
	__m128i scoreOdd = {0x0000880088008800,0x8800880088008800};
	__m128i scoreEven = {0xffff880088008800,0x880088008800ffff};
	
	__m128i maxScore = {0,0};
	
	const char* fwdPtr = seqStart - 3;
	const char* revPtr = refStart - 3;
	
	while (fwdPtr <= seqEnd - 1)
	{
		__m128i fwdOdd = _mm_loadu_si128((__m128i*)fwdPtr);
		__m128i revOdd = _mm_loadu_si128((__m128i*)revPtr);
		
		__m128i cmpOdd8 = _mm_cmpeq_epi8(fwdOdd,revOdd);
		__m128i cmpOdd = _mm_unpacklo_epi8(cmpOdd8,cmpOdd8);
		
		// matchOdd = scoreOdd + cmpOdd ? 1 : -1
		__m128i matchOdd = _mm_sub_epi16(_mm_add_epi16(scoreOdd,_mm_and_si128(cmpOdd,ones)),_mm_andnot_si128(cmpOdd,ones));
		
		// gapOdd = scoreEven - 1
		__m128i gapOdd = _mm_sub_epi16(scoreEven,ones);
		
		// max
		__m128i nextScoreOdd = _mm_max_epi16(matchOdd,_mm_max_epi16(_mm_or_si128(_mm_srli_si128(gapOdd,2),shiftRight),gapOdd));
		
		revPtr--;
		
		__m128i fwdEven = _mm_loadu_si128((__m128i*)fwdPtr);
		__m128i revEven = _mm_loadu_si128((__m128i*)revPtr);
		
		__m128i cmpEven8 = _mm_cmpeq_epi8(fwdEven,revEven);
		__m128i cmpEven = _mm_unpacklo_epi8(cmpEven8,cmpEven8);
		
		// matchEven = scoreEven + cmpEven ? 1 : -1
		__m128i matchEven = _mm_sub_epi16(_mm_add_epi16(scoreEven,_mm_and_si128(cmpEven,ones)),_mm_andnot_si128(cmpEven,ones));
		
		// gapEven = scoreOdd - 1
		__m128i gapEven = _mm_sub_epi16(nextScoreOdd,ones);
		
		// max
		__m128i nextScoreEven = _mm_max_epi16(matchEven,_mm_max_epi16(_mm_or_si128(_mm_slli_si128(gapEven,2),shiftLeft),gapEven));
		
		fwdPtr++;
		
		scoreOdd = nextScoreOdd;
		scoreEven = nextScoreEven;
		
		maxScore = _mm_srli_si128(maxScore,2);
		maxScore = _mm_max_epi16(maxScore,nextScoreOdd);
		maxScore = _mm_max_epi16(maxScore,nextScoreEven);
		
		_mm_storeu_si128((__m128i*)scorePtr,maxScore);
		scorePtr++;
	}
	
	int bestScore = 0;
	int previousBestScore = 0;
	
	int increaseCount = 0;
	int plateauCount = 0;
	
	int bestChangepointScore = 0;
	int bestChangepointLength = 0;
	
	for (int i = 3; i < 3 + (seqEnd - seqStart); i++)
	{
		int score = (int)mScoreBuffer16[i];
		bestScore = max(bestScore, score);
		
		if (bestScore > previousBestScore)
		{
			increaseCount++;
		}
		else
		{
			plateauCount++;
		}
		
		int changepointScore = increaseCount - plateauCount;
		
		if (changepointScore > bestChangepointScore)
		{
			bestChangepointScore = changepointScore;
			bestChangepointLength = i - 2;
		}
		
		previousBestScore = bestScore;
	}
	
	return bestChangepointScore;
}

void SimpleAligner::AlignBanded(const string& reference, const string& sequence, int bandWidth, int& score, int& length)
{
	int matrixLength = reference.size() + 1;
	int matrixHeight = sequence.size() + 1;
	
	if (matrixLength != mCurrent.size())
	{
		mCurrent.resize(matrixLength);
		mPrevious.resize(matrixLength);
	}
	
	int badScore = mMisMatchScore * sequence.size();
	
	int bestScore = 0;
	int previousBestScore = 0;
	
	int increaseCount = 0;
	int plateauCount = 0;
	
	int bestChangepointScore = 0;
	int bestChangepointLength = 0;
	
	for (int j = 0; j < matrixHeight; j++)
	{
		int seqPos = j - 1;
		
		int istart = j - bandWidth;
		int iend = j + bandWidth;
		
		if (istart > 0)
		{
			mCurrent[istart-1] = badScore;
		}
		
		for (int i = max(0,istart); i <= min(matrixLength-1,iend); i++) 
		{
			int refPos = i - 1;
			
			if (i == 0 && j == 0)
			{
				mCurrent[i] = 0;
			}
			else if (j == 0)
			{
				mCurrent[i] = mCurrent[i-1] + mGapScore;
			}
			else if (i == 0)
			{
				mCurrent[i] = mPrevious[i] + mGapScore;
			}
			else
			{
				int matchScore = mPrevious[i-1] + ((reference[refPos] == sequence[seqPos]) ? mMatchScore : mMisMatchScore);
				int gapRefScore = mCurrent[i-1] + mGapScore;
				int gapReadScore = mPrevious[i] + mGapScore;
				int maxScore = max(matchScore,max(gapRefScore,gapReadScore));
				
				bestScore = max(bestScore, maxScore);
				
				mCurrent[i] = maxScore;
			}
		}
		
		if (iend + 1 < matrixLength)
		{
			mCurrent[iend + 1] = badScore;
		}

		swap(mCurrent, mPrevious);
		
		if (j > 0)
		{
			if (bestScore > previousBestScore)
			{
				increaseCount++;
			}
			else
			{
				plateauCount++;
			}
			
			int changepointScore = increaseCount - plateauCount;
			
			if (changepointScore > bestChangepointScore)
			{
				bestChangepointScore = changepointScore;
				bestChangepointLength = seqPos + 1;
			}
			
			previousBestScore = bestScore;
		}
	}
	
	score = bestChangepointScore;
	length = bestChangepointLength;
}

void SimpleAligner::AlignBandedFwd(const char* refStart, const char* seqStart, const char* seqEnd, int bandWidth, int& score, int& length)
{
	int matrixLength = seqEnd - seqStart + 1 + bandWidth;
	int matrixHeight = seqEnd - seqStart + 1;
	
	if (matrixLength != mCurrent.size())
	{
		mCurrent.resize(matrixLength);
		mPrevious.resize(matrixLength);
	}
	
	int badScore = mMisMatchScore * (seqEnd - seqStart);
	
	int bestScore = 0;
	int previousBestScore = 0;
	
	int increaseCount = 0;
	int plateauCount = 0;
	
	int bestChangepointScore = 0;
	int bestChangepointLength = 0;
	
	for (int j = 0; j < matrixHeight; j++)
	{
		int seqPos = j - 1;
		
		int istart = j - bandWidth;
		int iend = j + bandWidth;
		
		if (istart > 0)
		{
			mCurrent[istart-1] = badScore;
		}
		
		for (int i = max(0,istart); i <= iend; i++) 
		{
			DebugCheck(i < mCurrent.size());
			
			int refPos = i - 1;
			
			if (i == 0 && j == 0)
			{
				mCurrent[i] = 0;
			}
			else if (j == 0)
			{
				mCurrent[i] = mCurrent[i-1] + mGapScore;
			}
			else if (i == 0)
			{
				mCurrent[i] = mPrevious[i] + mGapScore;
			}
			else
			{
				int matchScore = mPrevious[i-1] + ((refStart[refPos] == seqEnd[-seqPos - 1]) ? mMatchScore : mMisMatchScore);
				int gapRefScore = mCurrent[i-1] + mGapScore;
				int gapReadScore = mPrevious[i] + mGapScore;
				int maxScore = max(matchScore,max(gapRefScore,gapReadScore));
				
				bestScore = max(bestScore, maxScore);
				
				mCurrent[i] = maxScore;
			}
		}
		
		if (iend + 1 < matrixLength)
		{
			mCurrent[iend + 1] = badScore;
		}
		
		swap(mCurrent, mPrevious);
		
		if (j > 0)
		{
			if (bestScore > previousBestScore)
			{
				increaseCount++;
			}
			else
			{
				plateauCount++;
			}
			
			int changepointScore = increaseCount - plateauCount;
			
			if (changepointScore > bestChangepointScore)
			{
				bestChangepointScore = changepointScore;
				bestChangepointLength = seqPos + 1;
			}
			
			previousBestScore = bestScore;
		}
	}
	
	score = bestChangepointScore;
	length = bestChangepointLength;
}

void SimpleAligner::AlignBandedRev(const char* refStart, const char* seqStart, const char* seqEnd, int bandWidth, int& score, int& length)
{
	int matrixLength = seqEnd - seqStart + 1 + bandWidth;
	int matrixHeight = seqEnd - seqStart + 1;
	
	if (matrixLength != mCurrent.size())
	{
		mCurrent.resize(matrixLength);
		mPrevious.resize(matrixLength);
	}
	
	int badScore = mMisMatchScore * (seqEnd - seqStart);
	
	int bestScore = 0;
	int previousBestScore = 0;
	
	int increaseCount = 0;
	int plateauCount = 0;
	
	int bestChangepointScore = 0;
	int bestChangepointLength = 0;
	
	for (int j = 0; j < matrixHeight; j++)
	{
		int seqPos = j - 1;
		
		int istart = j - bandWidth;
		int iend = j + bandWidth;
		
		if (istart > 0)
		{
			mCurrent[istart-1] = badScore;
		}
		
		for (int i = max(0,istart); i <= iend; i++) 
		{
			DebugCheck(i < mCurrent.size());
			
			int refPos = i - 1;
			
			if (i == 0 && j == 0)
			{
				mCurrent[i] = 0;
			}
			else if (j == 0)
			{
				mCurrent[i] = mCurrent[i-1] + mGapScore;
			}
			else if (i == 0)
			{
				mCurrent[i] = mPrevious[i] + mGapScore;
			}
			else
			{
				int matchScore = mPrevious[i-1] + ((refStart[-refPos] == seqStart[seqPos]) ? mMatchScore : mMisMatchScore);
				int gapRefScore = mCurrent[i-1] + mGapScore;
				int gapReadScore = mPrevious[i] + mGapScore;
				int maxScore = max(matchScore,max(gapRefScore,gapReadScore));
				
				bestScore = max(bestScore, maxScore);
				
				mCurrent[i] = maxScore;
			}
		}
		
		if (iend + 1 < matrixLength)
		{
			mCurrent[iend + 1] = badScore;
		}
		
		swap(mCurrent, mPrevious);
		
		if (j > 0)
		{
			if (bestScore > previousBestScore)
			{
				increaseCount++;
			}
			else
			{
				plateauCount++;
			}
			
			int changepointScore = increaseCount - plateauCount;
			
			if (changepointScore > bestChangepointScore)
			{
				bestChangepointScore = changepointScore;
				bestChangepointLength = seqPos + 1;
			}
			
			previousBestScore = bestScore;
		}
	}
	
	score = bestChangepointScore;
	length = bestChangepointLength;
}

void SimpleAligner::AlignPrint(const string& seq1, const string& seq2)
{
	int matrixLength = seq1.size() + 1;
	int matrixHeight = seq2.size() + 1;
	
	Matrix<int> matrix;
	Matrix<Cell> backTrace;
	
	matrix.Resize(matrixLength, matrixHeight);
	backTrace.Resize(matrixLength, matrixHeight);
	
	int bestScore = 0;
	int previousBestScore = 0;
	
	int increaseCount = 0;
	int plateauCount = 0;
	
	int bestChangepointScore = 0;
	int bestChangepointLength = 0;
	Cell bestChangepointCell;
	
	for (int i = 0; i < matrixLength; i++) 
	{
		Cell bestCell;
		
		int seq1Pos = i - 1;
		
		for (int j = 0; j < matrixHeight; j++)
		{
			int seq2Pos = j - 1;
			
			if (i == 0 && j == 0)
			{
				matrix(i,j) = 0;
			}
			else if (j == 0)
			{
				matrix(i,j) = matrix(i-1,j) + mGapScore;
				backTrace(i,j) = Cell(i,j-1);
			}
			else if (i == 0)
			{
				matrix(i,j) = matrix(i,j-1) + mGapScore;
				backTrace(i,j) = Cell(i,j-1);
			}
			else
			{
				int matchScore = matrix(i-1,j-1) + ((seq1[seq1Pos] == seq2[seq2Pos]) ? mMatchScore : mMisMatchScore);
				int gapRefScore = matrix(i-1,j) + mGapScore;
				int gapReadScore = matrix(i,j-1) + mGapScore;
				int maxScore = max(matchScore,max(gapRefScore,gapReadScore));
				
				if (matchScore == maxScore)
				{
					backTrace(i,j) = Cell(i-1,j-1);
				}
				
				if (gapRefScore == maxScore)
				{
					backTrace(i,j) = Cell(i-1,j);
				}
				
				if (gapReadScore == maxScore)
				{
					backTrace(i,j) = Cell(i,j-1);
				}
				
				if (maxScore > bestScore)
				{
					bestScore = maxScore;
					bestCell = Cell(i,j);
				}
				
				matrix(i,j) = maxScore;
			}
		}
		
		if (bestScore > previousBestScore)
		{
			increaseCount++;
		}
		else
		{
			plateauCount++;
		}
		
		int changepointScore = increaseCount - plateauCount;
		
		if (changepointScore > bestChangepointScore)
		{
			bestChangepointScore = changepointScore;
			bestChangepointLength = seq1Pos + 1;
			bestChangepointCell = bestCell;
		}
		
		previousBestScore = bestScore;
	}
	
	IntegerPairVec matches;
	
	Cell cell = bestChangepointCell;
	while (cell.j > 0)
	{
		Cell nextCell = backTrace(cell);
		
		int seq1Pos = cell.i - 1;
		int seq2Pos = cell.j - 1;
		
		if (cell.i - 1 == nextCell.i && cell.j - 1 == nextCell.j)
		{
			matches.push_back(IntegerPair(seq1Pos,seq2Pos));
		}
		
		cell = nextCell;
	}
	
	reverse(matches.begin(), matches.end());
	
	string seq1Gapped;
	string seq2Gapped;
	string seqMatches;
	IntegerPair last(-1,-1);
	for (IntegerPairVecConstIter matchIter = matches.begin(); matchIter != matches.end(); matchIter++)
	{
		for (int seq1Pos = last.first + 1; seq1Pos < matchIter->first; seq1Pos++)
		{
			seq1Gapped.push_back(seq1[seq1Pos]);
			seq2Gapped.append("-");
			seqMatches.append(" ");
		}
		
		for (int seq2Pos = last.second + 1; seq2Pos < matchIter->second; seq2Pos++)
		{
			seq1Gapped.append("-");
			seq2Gapped.push_back(seq2[seq2Pos]);
			seqMatches.append(" ");
		}
		
		seq1Gapped.push_back(seq1[matchIter->first]);
		seq2Gapped.push_back(seq2[matchIter->second]);
		seqMatches.append(seq1[matchIter->first] == seq2[matchIter->second] ? "|" : " ");
		
		last = *matchIter;
	}
	
	cout << seq1Gapped << endl;
	cout << seqMatches << endl;	
	cout << seq2Gapped << endl;
}

