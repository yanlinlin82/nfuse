/*
 *  setcover.cpp
 *  tools
 *
 *  Created by Andrew McPherson on 10-08-24.
 *
 */

#include "Common.h"
#include "DebugCheck.h"
#include "QuaterpartiteEdges.h"
#include "Parsers.h"
#include "ILPSolver.h"
#include "ReweightSetCover.h"
#include "ReweightSetCover.inl"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <tclap/CmdLine.h>
#include <boost/algorithm/string.hpp>
#include <boost/bimap/bimap.hpp>
#include <boost/bimap/vector_of.hpp>
#include <boost/bimap/multiset_of.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/unordered_set.hpp>

using namespace boost;
using namespace boost::bimaps;
using namespace std;


template <typename TSelectedType>
void SelectClusters(const IntegerVec& clusterIndices, const IntegerTable& clusters, TSelectedType& selected)
{
	for (IntegerVecConstIter clusterIndexIter = clusterIndices.begin(); clusterIndexIter != clusterIndices.end(); clusterIndexIter++)
	{
		selected[*clusterIndexIter] = clusters[*clusterIndexIter];
	}
}

void Append(const IntegerVecMap& clusters1, IntegerTable& clusters2)
{
	for (IntegerVecMapConstIter clusterIter = clusters1.begin(); clusterIter != clusters1.end(); clusterIter++)
	{
		clusters2[clusterIter->first] = clusterIter->second;
	}
}

int CountReads(const IntegerVecMap& clusters)
{
	int count = 0;
	for (IntegerVecMapConstIter clusterIter = clusters.begin(); clusterIter != clusters.end(); clusterIter++)
	{
		count += clusterIter->second.size();
	}
	return count;
}

int main(int argc, char* argv[])
{
	string dnaClustersFilename;
	string rnaClustersFilename;
	string overlapsFilename;
	double weight1;
	double weight2;
	double weight3;
	double weight4;
	int dnaMinClusterSize;
	int rnaMinClusterSize;
	string dnaOutClustersFilename;
	string rnaOutClustersFilename;
	int timeout;
	
	try
	{
		TCLAP::CmdLine cmd("ILP for rna/dna maximum parsimony");
		TCLAP::ValueArg<string> dnaClustersFilenameArg("d","dna","DNA clusters filename",true,"","string",cmd);
		TCLAP::ValueArg<string> rnaClustersFilenameArg("r","rna","RNA clusters filename",true,"","string",cmd);
		TCLAP::ValueArg<string> overlapsFilenameArg("o","overlaps","DNA-RNA overlaps filename",true,"","string",cmd);
		TCLAP::ValueArg<double> weight1Arg("1","weight1","Weight for DNA cluster with RNA support",true,-1,"string",cmd);
		TCLAP::ValueArg<double> weight2Arg("2","weight2","Weight for DNA cluster without RNA support",true,-1,"string",cmd);
		TCLAP::ValueArg<double> weight3Arg("3","weight3","Weight for RNA cluster with DNA support",true,-1,"string",cmd);
		TCLAP::ValueArg<double> weight4Arg("4","weight4","Weight for RNA cluster without DNA support",true,-1,"string",cmd);
		TCLAP::ValueArg<string> dnaOutClustersFilenameArg("a","outdna","Output DNA clusters filename",true,"","string",cmd);
		TCLAP::ValueArg<string> rnaOutClustersFilenameArg("b","outrna","Output RNA clusters filename",true,"","string",cmd);
		TCLAP::ValueArg<int> dnaMinClusterSizeArg("m","dnaminclustersize","Minimum DNA Cluster Size",true,-1,"integer",cmd);
		TCLAP::ValueArg<int> rnaMinClusterSizeArg("n","rnaminclustersize","Minimum RNA Cluster Size",true,-1,"integer",cmd);
		TCLAP::ValueArg<int> timeoutArg("t","timout","Max Time for any Subproblem (milliseconds)",true,-1,"integer",cmd);
		cmd.parse(argc,argv);
		
		dnaClustersFilename = dnaClustersFilenameArg.getValue();
		rnaClustersFilename = rnaClustersFilenameArg.getValue();
		overlapsFilename = overlapsFilenameArg.getValue();
		weight1 = weight1Arg.getValue();
		weight2 = weight2Arg.getValue();
		weight3 = weight3Arg.getValue();
		weight4 = weight4Arg.getValue();
		dnaMinClusterSize = dnaMinClusterSizeArg.getValue();
		rnaMinClusterSize = rnaMinClusterSizeArg.getValue();
		dnaOutClustersFilename = dnaOutClustersFilenameArg.getValue();
		rnaOutClustersFilename = rnaOutClustersFilenameArg.getValue();
		timeout = timeoutArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	cout << "Reading DNA clusters" << endl;
	
	IntegerTable dnaClusters;	
	ReadClusters(dnaClustersFilename, dnaClusters);
	
	cout << "Reading RNA clusters" << endl;
	
	IntegerTable rnaClusters;	
	ReadClusters(rnaClustersFilename, rnaClusters);
	
	cout << "Reading DNA/RNA overlaps" << endl;
	
	IntegerVecMap dnaRnaOverlaps;
	IntegerVecMap rnaDnaOverlaps;
	ReadOverlaps(overlapsFilename, dnaRnaOverlaps, rnaDnaOverlaps);
	
	cout << "Finding components" << endl;

	IntegerTable dnaClusterComponents;
	IntegerTable rnaClusterComponents;
	QuaterpartiteEdges edges(dnaClusters, rnaClusters, dnaRnaOverlaps);
	edges.CalculateComponents(dnaClusterComponents, rnaClusterComponents);
	
	cout << "Calculating for each component" << endl;
	IntegerTable dnaSolutionClusters(dnaClusters.size());
	IntegerTable rnaSolutionClusters(rnaClusters.size());
	ILPSolver ilpSolver(dnaRnaOverlaps, rnaDnaOverlaps, weight1, weight2, weight3, weight4, timeout);
	double objective = 0.0;
	for (int componentIndex = 0; componentIndex < dnaClusterComponents.size(); componentIndex++)
	{
		if (componentIndex % 10000 == 0)
		{
			cerr << ".";
			cerr.flush();
		}

		IntegerVecMap compDnaClusters;
		IntegerVecMap compRnaClusters;		
		SelectClusters(dnaClusterComponents[componentIndex], dnaClusters, compDnaClusters);
		SelectClusters(rnaClusterComponents[componentIndex], rnaClusters, compRnaClusters);

		IntegerVecMap ilpDnaSolution;
		IntegerVecMap ilpRnaSolution;		
		double compILPObjective = ilpSolver.Solve(compDnaClusters, compRnaClusters, ilpDnaSolution, ilpRnaSolution, true);
				
		Append(ilpDnaSolution, dnaSolutionClusters);
		Append(ilpRnaSolution, rnaSolutionClusters);
		
		objective += compILPObjective;
	}
	
	cout << "Writing out clusters" << endl;

	WriteClusters(dnaClustersFilename, dnaOutClustersFilename, dnaSolutionClusters, dnaMinClusterSize);
	WriteClusters(rnaClustersFilename, rnaOutClustersFilename, rnaSolutionClusters, rnaMinClusterSize);
	
	cout << "Objective: " << objective << endl;
}

