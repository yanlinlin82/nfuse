/*
 *  clustermatepairs.cpp
 *
 *  Created by Andrew McPherson on 28/09/09.
 *
 */

#include "DebugCheck.h"
#include "Indexer.h"
#include "DiscordantAlignments3.h"
#include "MatePairEM2.h"
#include "AlignmentStream2.h"
#include "RegionDB.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

using namespace boost;
using namespace std;


bool IsExcluded(const RawAlignmentVec& alignments, const RegionDB& excludedRegions)
{
	bool excluded[] = {false,false};
	for (RawAlignmentVecConstIter alignmentIter = alignments.begin(); alignmentIter != alignments.end(); alignmentIter++)
	{
		if (excludedRegions.Contained(alignmentIter->reference, alignmentIter->region.start, alignmentIter->region.end))
		{
			excluded[alignmentIter->readEnd] = true;
		}
	}
	
	if (excluded[0] && excluded[1])
	{
		return true;
	}
	
	return false;
}

bool IsConcordant(const RawAlignmentVec& alignments, int maxFragmentLength)
{
	for (RawAlignmentVecConstIter alignmentIter1 = alignments.begin(); alignmentIter1 != alignments.end(); alignmentIter1++)
	{
		for (RawAlignmentVecConstIter alignmentIter2 = alignmentIter1 + 1; alignmentIter2 != alignments.end(); alignmentIter2++)
		{
			if (alignmentIter1->readEnd == alignmentIter2->readEnd)
			{
				continue;
			}
			
			if (alignmentIter1->reference != alignmentIter2->reference)
			{
				continue;
			}
			
			if (alignmentIter1->strand == PlusStrand && alignmentIter2->strand == MinusStrand)
			{
				int inferredLength = alignmentIter2->region.end - alignmentIter1->region.start + 1;
				
				if (inferredLength >= 0 && inferredLength < maxFragmentLength)
				{
					return true;
				}
			}
			
			if (alignmentIter2->strand == PlusStrand && alignmentIter1->strand == MinusStrand)
			{
				int inferredLength = alignmentIter1->region.end - alignmentIter2->region.start + 1;
				
				if (inferredLength >= 0 && inferredLength < maxFragmentLength)
				{
					return true;
				}
			}
		}
	}
	
	return false;
}

void CreateCompactAlignments(const RawAlignmentVec& alignments, CompAlignVec& compactAlignments, NameIndex& refNameIndex, int fragmentIndex)
{
	for (RawAlignmentVecConstIter alignmentIter = alignments.begin(); alignmentIter != alignments.end(); alignmentIter++)
	{
		compactAlignments.push_back(CompactAlignment());
		compactAlignments.back().readID.fragmentIndex = fragmentIndex;
		compactAlignments.back().readID.readEnd = alignmentIter->readEnd;
		compactAlignments.back().refStrand.referenceIndex = refNameIndex.Index(alignmentIter->reference);
		compactAlignments.back().refStrand.strand = alignmentIter->strand;
		compactAlignments.back().region.start = alignmentIter->region.start;
		compactAlignments.back().region.end = alignmentIter->region.end;
	}
}

void OutputClusterMember(ostream& out, int clusterID, int clusterEnd, const CompactAlignment& alignment, const vector<string>& referenceNames, const vector<int>& fragmentIndices, const vector<unsigned char>& fragmentLibIndices, const vector<string>& libraryIDList)
{
	out << clusterID << "\t";
	out << clusterEnd << "\t";
	out << libraryIDList[fragmentLibIndices[alignment.readID.fragmentIndex]] << "\t";
	out << fragmentIndices[alignment.readID.fragmentIndex] << "\t";
	out << alignment.readID.readEnd << "\t";
	out << referenceNames[alignment.refStrand.referenceIndex] << "\t";
	out << ((alignment.refStrand.strand == PlusStrand) ? "+" : "-") << "\t";
	out << alignment.region.start << "\t";
	out << alignment.region.end << endl;	
}

void ReadTable(const string& filename, unordered_map<string,string>& values)
{
	ifstream file(filename.c_str());
	if (!file.good())
	{
		cerr << "Error: Unable to open file " << filename << endl;
		exit(1);
	}
	
	vector<string> lines;
	
	string line;
	while (getline(file, line))
	{
		lines.push_back(line);
	}
	
	if ((int)lines.size() < 2)
	{
		cerr << "Error: incorrect number of lines for table file " << filename << endl;
		exit(1);
	}
	
	vector<string> fieldNames;
	split(fieldNames, lines[0], is_any_of("\t"));
	
	vector<string> fieldValues;
	split(fieldValues, lines[1], is_any_of("\t"));
	
	for (int fieldIndex = 0; fieldIndex < min(fieldNames.size(),fieldValues.size()); fieldIndex++)
	{
		values[fieldNames[fieldIndex]] = fieldValues[fieldIndex];
	}
}

void CheckHasStat(const string& filename, const unordered_map<string,string>& values, const string& name)
{
	if (values.find(name) == values.end())
	{
		cerr << "Error: no entry in stats file " << filename << " for " << name << endl;
		exit(1);
	}
}

void ReadStats(const string& filename, double& fragmentLengthMean, double& fragmentLengthStdDev)
{
	unordered_map<string,string> values;
	ReadTable(filename, values);
	
	CheckHasStat(filename, values, "fraglength_mean");
	CheckHasStat(filename, values, "fraglength_stddev");
	
	fragmentLengthMean = lexical_cast<double>(values["fraglength_mean"]);
	fragmentLengthStdDev = lexical_cast<double>(values["fraglength_stddev"]);
}

int main(int argc, char* argv[])
{
	vector<string> libraryIDList;
	vector<string> bamFilenameList;
	vector<string> statsFilenameList;
	string clustersFilename;
	double precision;
	int minClusterSize;
	string excludedFilename;
	
	try
	{
		TCLAP::CmdLine cmd("Mate Pair Clustering Tool");
		TCLAP::MultiArg<string> libraryIDArg("i","id","Library ID",true,"integer",cmd);
		TCLAP::MultiArg<string> bamFilenameArg("b","bam","Read Sorted Bam Filename",true,"string",cmd);
		TCLAP::MultiArg<string> statsFilenameArg("s","stats","Concordant Stats Filename",true,"string",cmd);
		TCLAP::ValueArg<string> clustersFilenameArg("c","clusters","Output Clusters Filename",true,"","string",cmd);
		TCLAP::ValueArg<double> precisionArg("p","precision","Precision",true,-1,"double",cmd);
		TCLAP::ValueArg<int> minClusterSizeArg("m","minclustersize","Minimum Cluster Size",true,-1,"integer",cmd);
		TCLAP::ValueArg<string> excludedFilenameArg("x","exclude","Excluded Regions Filename",false,"","string",cmd);
		cmd.parse(argc,argv);
		
		libraryIDList = libraryIDArg.getValue();
		bamFilenameList = bamFilenameArg.getValue();
		statsFilenameList = statsFilenameArg.getValue();
		clustersFilename = clustersFilenameArg.getValue();
		precision = precisionArg.getValue();
		minClusterSize = minClusterSizeArg.getValue();
		excludedFilename = excludedFilenameArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	if (libraryIDList.size() != bamFilenameList.size() || libraryIDList.size() != statsFilenameList.size())
	{
		cerr << "Require the same number of ids, bam filenames and stats filenames" << endl;
		exit(1);
	}
	
	RegionDB excludedRegions;
	if (!excludedFilename.empty())
	{
		excludedRegions.Add(excludedFilename);
	}	
	
	cout << "Reading concordant alignment stats" << endl;
	
	DebugCheck(libraryIDList.size() <= 255);
	
	vector<double> fragmentLengthMeans(libraryIDList.size());
	vector<double> fragmentLengthStdDevs(libraryIDList.size());
	for (unsigned char libIndex = 0; libIndex < (unsigned char)libraryIDList.size(); libIndex++)
	{
		ReadStats(statsFilenameList[libIndex], fragmentLengthMeans[libIndex], fragmentLengthStdDevs[libIndex]);
	}
	
	cout << "Finding pairs of reference sequences connected by pairs of alignments" << endl;
	
	DiscordantAlignments discordantAlignments;
	NameIndex refNameIndex;
	
	vector<int> remapFragmentIndices;
	vector<unsigned char> fragmentLibIndices;
	
	for (unsigned char libIndex = 0; libIndex < (unsigned char)libraryIDList.size(); libIndex++)
	{
		AlignmentStream* alignmentStream = new BamAlignmentStream(bamFilenameList[libIndex]);
		FragmentAlignmentStream fragmentAlignmentStream(alignmentStream);
		
		RawAlignmentVec alignments;
		while (fragmentAlignmentStream.GetNextAlignments(alignments))
		{
			if (IsExcluded(alignments, excludedRegions))
			{
				continue;
			}
			
			int maxFragmentLength = (int)(fragmentLengthMeans[libIndex] + 40.0 * fragmentLengthStdDevs[libIndex]);
			
			if (IsConcordant(alignments, maxFragmentLength))
			{
				continue;
			}
			
			int fragmentIndex = remapFragmentIndices.size();
			remapFragmentIndices.push_back(lexical_cast<int>(alignments.front().fragment));
			fragmentLibIndices.push_back(libIndex);
			
			CompAlignVec compactAlignments;
			CreateCompactAlignments(alignments, compactAlignments, refNameIndex, fragmentIndex);
			
			discordantAlignments.AddFragmentAlignments(compactAlignments, fragmentLengthMeans[libIndex], fragmentLengthStdDevs[libIndex]);
		}
		
		delete alignmentStream;
	}
	
	// Initialize clusterer
	cout << "Initializing clusterer" << endl;
	MatePairEM clusterer;
	
	// Open output clusters file
	ofstream clustersFile(clustersFilename.c_str());
	if (!clustersFile)
	{
		cerr << "Error: unable to write to clusters file" << endl;		
		exit(1);
	}
	
	cout << "Creating clusters" << endl;
	
	int clusterID = 0;
	for (discordantAlignments.StartSectorIteration(); !discordantAlignments.FinishedSectorIteration(); discordantAlignments.NextSectorIteration())
	{
		CompAlignVec alignments1;
		CompAlignVec alignments2;
		discordantAlignments.RetrieveSectorAlignments(alignments1, alignments2);
		
		if (alignments1.size() < minClusterSize)
		{
			continue;
		}
		
		if (alignments1.size() == 1)
		{
			OutputClusterMember(clustersFile, clusterID, 0, alignments1.front(), refNameIndex.Get(), remapFragmentIndices, fragmentLibIndices, libraryIDList);
			OutputClusterMember(clustersFile, clusterID, 1, alignments2.front(), refNameIndex.Get(), remapFragmentIndices, fragmentLibIndices, libraryIDList);
			clusterID++;
			continue;
		}
		
		MatePairEM::MatePairVec matePairs;
		IntegerVec fragmentIndices;
		
		int minx = alignments1[0].region.start;
		int maxx = alignments1[0].region.start;
		int miny = alignments2[0].region.start;
		int maxy = alignments2[0].region.start;
		
		for (int alignPairIndex = 0; alignPairIndex < alignments1.size(); alignPairIndex++)
		{
			const CompactAlignment& alignment1 = alignments1[alignPairIndex];
			const CompactAlignment& alignment2 = alignments2[alignPairIndex];
			
			DebugCheck(alignment1.readID.fragmentIndex == alignment2.readID.fragmentIndex);
			DebugCheck(alignment1.readID.readEnd != alignment2.readID.readEnd);
			
			int libIndex = fragmentLibIndices[alignment1.readID.fragmentIndex];
			
			MatePairEM::MatePair matePair;
			clusterer.CreateMatePair(alignPairIndex, alignment1.region, alignment1.refStrand.strand, alignment2.region, alignment2.refStrand.strand, 
									 fragmentLengthMeans[libIndex], fragmentLengthStdDevs[libIndex], matePair);
			
			matePairs.push_back(matePair);
			
			fragmentIndices.push_back(alignment1.readID.fragmentIndex);
			
			minx = min(minx, alignments1[alignPairIndex].region.start);
			maxx = max(maxx, alignments1[alignPairIndex].region.start);
			miny = min(miny, alignments2[alignPairIndex].region.start);
			maxy = max(maxy, alignments2[alignPairIndex].region.start);
		}
		
		int area = sqrt((double)( maxx - minx ) * (double)( maxy - miny ));
		
		cout << "chr" << refNameIndex.Get(alignments1[0].refStrand.referenceIndex) << ":" << minx << "-" << maxx << "\t";
		cout << "chr" << refNameIndex.Get(alignments2[0].refStrand.referenceIndex) << ":" << miny << "-" << maxy << "\t";
		cout << alignments1.size() << "\t";
		cout << area << "\t";
		cout.flush();
		
		clock_t init, final;
		init=clock();
		IntegerTable matePairClusters;
		DoubleTable likelihoods;
		clusterer.DoClustering(matePairs, matePairClusters, likelihoods);
		final=clock()-init;
		cout << (double)final / ((double)CLOCKS_PER_SEC);
		cout << endl;
		
		for (int clusterIndex = 0; clusterIndex < matePairClusters.size(); clusterIndex++)
		{
			const IntegerVec& cluster = matePairClusters[clusterIndex];
			
			if (cluster.size() < minClusterSize)
			{
				continue;
			}
			
			unordered_set<int> clusterFragmentIndices;
			for (int elementIndex = 0; elementIndex < cluster.size(); elementIndex++)
			{
				int alignPairIndex = cluster[elementIndex];
				
				double likelihood = likelihoods[clusterIndex][elementIndex];
				
				const CompactAlignment& alignment1 = alignments1[alignPairIndex];
				const CompactAlignment& alignment2 = alignments2[alignPairIndex];
				
				DebugCheck(alignment1.readID.fragmentIndex == alignment2.readID.fragmentIndex);
				DebugCheck(alignment1.readID.readEnd != alignment2.readID.readEnd);
				
				// For fragments with multiple alignments supporting the same cluster, randomly select one alignment
				//if (clusterFragmentIndices.find(alignment1.readID.fragmentIndex) != clusterFragmentIndices.end())
				{
					//	continue;
				}
				
				clusterFragmentIndices.insert(alignment1.readID.fragmentIndex);
				
				OutputClusterMember(clustersFile, clusterID, 0, alignment1, refNameIndex.Get(), remapFragmentIndices, fragmentLibIndices, libraryIDList);
				OutputClusterMember(clustersFile, clusterID, 1, alignment2, refNameIndex.Get(), remapFragmentIndices, fragmentLibIndices, libraryIDList);
			}
			
			clusterID++;
		}
	}
	
	clustersFile.close();
	
	cout << "Created " << clusterID << " clusters" << endl;
}

