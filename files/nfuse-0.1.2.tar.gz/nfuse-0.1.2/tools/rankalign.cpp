/*
 *  rankalign.cpp
 *
 *  Created by Andrew McPherson
 *
 */

#include "Common.h"
#include "DebugCheck.h"
#include "Parsers.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/math/distributions.hpp>
#include <boost/math/distributions/normal.hpp>
#include <boost/math/distributions/negative_binomial.hpp>

using namespace boost;
using namespace std;



void Normalize(unordered_map<int,unordered_map<int,double> >& counts)
{
	for (unordered_map<int,unordered_map<int,double> >::iterator alignedLengthIter = counts.begin(); alignedLengthIter != counts.end(); alignedLengthIter++)
	{
		double total = 0.0;
		for (unordered_map<int,double>::const_iterator countIter = alignedLengthIter->second.begin(); countIter != alignedLengthIter->second.end(); countIter++)
		{
			total += countIter->second;
		}
		
		for (unordered_map<int,double>::iterator countIter = alignedLengthIter->second.begin(); countIter != alignedLengthIter->second.end(); countIter++)
		{
			countIter->second /= total;
		}
	}
}

void FillZeroes(unordered_map<int,unordered_map<int,double> >& counts, int minScore, int maxScore)
{
	for (unordered_map<int,unordered_map<int,double> >::iterator alignedLengthIter = counts.begin(); alignedLengthIter != counts.end(); alignedLengthIter++)
	{
		for (int score = minScore; score <= maxScore; score++)
		{
			alignedLengthIter->second.insert(make_pair(score,0.0));
		}	
	}
}

void BinScores(const string& filename, unordered_map<int,unordered_map<int,double> >& counts, int& minScore, int& maxScore)
{
	minScore = numeric_limits<int>::max();
	maxScore = numeric_limits<int>::min();
	
	ifstream file(filename.c_str());
	if (!file.good())
	{
		cerr << "Error: Unable to open file " << filename << endl;
		exit(1);
	}
	
	string line;
	
	while (getline(file, line))
	{
		vector<string> fields;
		split(fields, line, is_any_of("\t"));
		
		if (fields.size() < 2)
		{
			cerr << "Error: Format error for pairs file on line:" << endl << line << endl;
			exit(1);
		}
		
		int alignedLength = lexical_cast<int>(fields[0]);
		int score = -lexical_cast<int>(fields[1]);
		
		counts.insert(make_pair(alignedLength,unordered_map<int,double>())).first->second.insert(make_pair(score,0.0)).first->second++;
		
		minScore = min(minScore,score);
		maxScore = max(maxScore,score);
	}
	
	file.close();
	
	Normalize(counts);
}

void BinScores(const AlignmentScoreVec& alignmentScores, unordered_map<int,unordered_map<int,double> >& counts, int& minScore, int& maxScore)
{
	minScore = numeric_limits<int>::max();
	maxScore = numeric_limits<int>::min();
	
	for (AlignmentScoreVecConstIter alignIter = alignmentScores.begin(); alignIter != alignmentScores.end(); alignIter++)
	{
		int score = alignIter->score;
		int alignedLength = alignIter->alignedLength;
		
		counts.insert(make_pair(alignedLength,unordered_map<int,double>())).first->second.insert(make_pair(score,0.0)).first->second++;
		
		minScore = min(minScore,score);
		maxScore = max(maxScore,score);
	}
	
	Normalize(counts);
}

void KNNClassify(const unordered_map<int,double>& positives, const unordered_map<int,double>& negatives, int minScore, int maxScore, unordered_map<int,double>& probability)
{
	double kfactor = 0.05;
	
	for (int score = minScore; score <= maxScore; score++)
	{
		double positive = positives.find(score)->second;
		double negative = negatives.find(score)->second;
		int offset = 1;
		while (positive + negative < kfactor)
		{
			if (score - offset >= minScore)
			{
				positive += positives.find(score - offset)->second;
				negative += negatives.find(score - offset)->second;
			}
			
			if (score + offset <= maxScore)
			{
				positive += positives.find(score + offset)->second;
				negative += negatives.find(score + offset)->second;
			}
			
			offset++;
		}
		
		probability[score] = positive / (positive + negative);
	}
}

double SumProduct(const unordered_map<int,double>& prob1, const unordered_map<int,double>& prob2, int minScore, int maxScore)
{
	double sum = 0.0;
	for (int score = minScore; score <= maxScore; score++)
	{
		sum += prob1.find(score)->second * prob2.find(score)->second;
	}
	return sum;
}

void ScaleProbability(unordered_map<int,double>& probability, double scale, int minScore, int maxScore)
{
	for (int score = minScore; score <= maxScore; score++)
	{
		probability[score] = min(1.0, probability[score] / scale);
	}	
}

int main(int argc, char* argv[])
{
	string concordantFilename;
	string alignmentFilename;
	
	try
	{
		TCLAP::CmdLine cmd("Alignment ranking tool");
		TCLAP::ValueArg<string> concordantFilenameArg("c","conc","Concordant Alignment Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> alignmentFilenameArg("a","align","Spanning Alignment Filename",true,"","string",cmd);
		cmd.parse(argc,argv);
		
		concordantFilename = concordantFilenameArg.getValue();
		alignmentFilename = alignmentFilenameArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	cerr << "Reading spanning alignment scores" << endl;
	
	AlignmentScoreVec alignmentScores;
	ReadAlignmentScores(alignmentFilename, alignmentScores);
	
	cerr << "Estimating spanning alignment score density" << endl;
	
	int minSpanningScore;
	int maxSpanningScore;
	unordered_map<int,unordered_map<int,double> > spanningHistogram;
	BinScores(alignmentScores, spanningHistogram, minSpanningScore, maxSpanningScore);
	
	cerr << "Reading concordant alignment scores and estimating density" << endl;
	
	int minConcordantScore;
	int maxConcordantScore;
	unordered_map<int,unordered_map<int,double> > concordantHistogram;
	BinScores(concordantFilename, concordantHistogram, minConcordantScore, maxConcordantScore);
	
	int minScore = min(minSpanningScore,minConcordantScore);
	int maxScore = max(maxSpanningScore,maxConcordantScore);
	FillZeroes(spanningHistogram,minScore,maxScore);
	FillZeroes(concordantHistogram,minScore,maxScore);
	
	cerr << "Calculating classifier probability" << endl;
	
	unordered_map<int,unordered_map<int,double> > knnClassifiers;
	for (unordered_map<int,unordered_map<int,double> >::const_iterator alignedLengthIter = spanningHistogram.begin(); alignedLengthIter != spanningHistogram.end(); alignedLengthIter++)
	{
		int alignedLength = alignedLengthIter->first;
		
		unordered_map<int,double> knnClassifier;
		KNNClassify(concordantHistogram[alignedLength], spanningHistogram[alignedLength], minScore, maxScore, knnClassifier);
		
		double sampledGivenPositive = SumProduct(concordantHistogram[alignedLength], knnClassifier, minScore, maxScore);
		
		ScaleProbability(knnClassifier, sampledGivenPositive, minScore, maxScore);
		
		swap(knnClassifiers[alignedLength], knnClassifier);
	}
	
	cerr << "Estimating posterior" << endl;
	
	unordered_map<int,double> posteriors[2];
	for (AlignmentScoreVecConstIter alignIter = alignmentScores.begin(); alignIter != alignmentScores.end(); alignIter++)
	{
		posteriors[alignIter->readID.readEnd][alignIter->readID.fragmentIndex] = knnClassifiers[alignIter->alignedLength][alignIter->score];
	}
	
	unordered_map<int,double>::const_iterator posteriorIter0 = posteriors[0].begin();
	unordered_map<int,double>::const_iterator posteriorIter1 = posteriors[1].begin();
	while (posteriorIter0 != posteriors[0].end() && posteriorIter1 != posteriors[1].end())
	{
		DebugCheck(posteriorIter0->first == posteriorIter1->first);
		cout << posteriorIter0->first << "\t" << posteriorIter0->second * posteriorIter1->second << endl;
		posteriorIter0++;
		posteriorIter1++;
	}
}


