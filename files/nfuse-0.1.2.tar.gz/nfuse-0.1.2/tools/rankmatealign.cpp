/*
 *  rankmatealign.cpp
 *
 *  Created by Andrew McPherson
 *
 */

#include "Common.h"
#include "DebugCheck.h"
#include "Parsers.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/math/distributions.hpp>
#include <boost/math/distributions/normal.hpp>
#include <boost/math/distributions/negative_binomial.hpp>

using namespace boost;
using namespace std;


class ExtremeValueDistribution
{
public:
	void Create(const IntegerVec& X, int xMin, int xMax, int maxTrials)
	{
		if (X.empty())
		{
			return;
		}
		
		mXMin = xMin;
		mXMax = xMax;
		
		// Create smoothed distribution using kernel density estimating
		mPDFs.push_back(unordered_map<int,double>());
		CreateSmoothPDF(X, mPDFs.back(), mXMin, mXMax);
		
		// Create cumulative
		unordered_map<int,double> CDF;
		CreateCDF(mPDFs.back(), mXMin, mXMax, CDF);
		
		// Create remaining sample distributions
		for (int trial = 2; trial <= maxTrials; trial++)
		{
			// Create cumulative of previous
			unordered_map<int,double> prevCDF;
			CreateCDF(mPDFs.back(), mXMin, mXMax, prevCDF);
			
			// Create next evd
			unordered_map<int,double> nextPDF;
			for (int x = mXMin; x <= mXMax; x++)
			{
				nextPDF[x] = mPDFs.back()[x] * (CDF[x] + mPDFs.front()[x]) + prevCDF[x] * mPDFs.front()[x];
			}
			
			mPDFs.push_back(unordered_map<int,double>());
			swap(mPDFs.back(),nextPDF);
		}
	}
	
	double Probability(int x, int trials) const
	{
		if (trials > mPDFs.size())
		{
			cerr << "Error: Too many samples requested" << endl;
			exit(1);
		}
		
		if (x < mXMin || x > mXMax)
		{
			return 0.0;
		}
		
		return mPDFs[trials-1].find(x)->second;
	}
	
private:
	void CreateSmoothPDF(const IntegerVec& X, unordered_map<int,double>& PDF, int& xMin, int& xMax)
	{
		unordered_map<int,int> counts;
		for (IntegerVecConstIter xIter = X.begin(); xIter != X.end(); xIter++)
		{
			xMin = min(xMin,*xIter);
			xMax = max(xMax,*xIter);
			counts.insert(make_pair(*xIter,0)).first->second++;
		}
		
		double bw = 1.0;
		math::normal_distribution<double> normaldist(0.0,bw);
		double n = (double)X.size();
		
		for (int x = xMin; x <= xMax; x++)
		{
			double prob = 0.0;
			for (unordered_map<int,int>::const_iterator countIter = counts.begin(); countIter != counts.end(); countIter++)
			{
				double m = (double)countIter->second;
				double k = pdf(normaldist, (double)(x - countIter->first));
				
				prob += m * k / (n * bw);
			}
			
			PDF[x] = prob;
		}
	}
	
	void CreateCDF(const unordered_map<int,double>& PDF, int xMin, int xMax, unordered_map<int,double>& CDF)
	{
		double sum = 0.0;
		for (int x = xMin; x <= xMax; x++)
		{
			CDF[x] = sum;
			sum += PDF.find(x)->second;
		}
	}
	
	vector<unordered_map<int,double> > mPDFs;
	int mXMin;
	int mXMax;
};

class AlignedLengthSpecificEVD
{
public:
	void Create(const IntegerVecMap& samples, int minScore, int maxScore, int maxTrials)
	{
		for (IntegerVecMapConstIter samplesIter = samples.begin(); samplesIter != samples.end(); samplesIter++)
		{
			mEVDs[samplesIter->first].Create(samplesIter->second, minScore, maxScore, maxTrials);
		}
	}
	
	double Probability(int alignedlength, int x, int trials) const
	{
		return mEVDs.find(alignedlength)->second.Probability(x,trials);
	}
	
private:
	map<int,ExtremeValueDistribution> mEVDs;
};

class ScoreDensity
{
public:
	
	void Estimate(istream& in)
	{
		unordered_map<int,unordered_map<int,int> > counts;
		
		string line;
		while (getline(in, line))
		{
			vector<string> fields;
			split(fields, line, is_any_of("\t"));
			
			if (fields.size() < 2)
			{
				cerr << "Error: Format error for pairs file on line:" << endl << line << endl;
				exit(1);
			}
			
			int alignedLength = lexical_cast<int>(fields[0]);
			int score = lexical_cast<int>(fields[1]);
			
			counts.insert(make_pair(alignedLength,unordered_map<int,int>())).first->second.insert(make_pair(-score,0)).first->second++;
		}
		
		for (unordered_map<int,unordered_map<int,int> >::const_iterator alignedLengthIter = counts.begin(); alignedLengthIter != counts.end(); alignedLengthIter++)
		{
			FitNegativeBinomial(alignedLengthIter->second, mSize[alignedLengthIter->first], mProb[alignedLengthIter->first]);
		}
	}
	
	double Probability(int alignedLength, int score)
	{
		return pdf(math::negative_binomial(mSize[alignedLength], mProb[alignedLength]), -score);
	}
	
private:
	
	void FitNegativeBinomial(const unordered_map<int,int>& counts, double& size, double& prob)
	{
		double sum = 0.0;
		double sumSq = 0.0;
		double total = 0.0;
		for (unordered_map<int,int>::const_iterator countIter = counts.begin(); countIter != counts.end(); countIter++)
		{
			double score = (double)countIter->first;
			double count = (double)countIter->second;
			
			sum += score * count;
			sumSq += score * score * count;
			total += count;
		}
		
		double mean = sum / total;
		double variance = sumSq / total - mean * mean;
		
		size = mean * mean / (variance - mean);
		prob = size / (size + mean);
	}
	
	unordered_map<int,double> mSize;
	unordered_map<int,double> mProb;
};

double Sum(const DoubleVec& values)
{
	double sum = 0.0;
	for (DoubleVecConstIter valueIter = values.begin(); valueIter != values.end(); valueIter++)
	{
		sum += *valueIter;
	}
	return sum;
}

int main(int argc, char* argv[])
{
	string nullSamplesFilename;
	string concordantFilename;
	string mateAlignmentFilename;
	
	try
	{
		TCLAP::CmdLine cmd("Mate alignment ranking tool");
		TCLAP::ValueArg<string> nullSamplesFilenameArg("n","nullsample","Null Distribution Samples",true,"","string",cmd);
		TCLAP::ValueArg<string> concordantFilenameArg("c","conc","Concordant Alignment Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> mateAlignmentFilenameArg("m","mate","Mate Alignment Filename",true,"","string",cmd);
		cmd.parse(argc,argv);
		
		nullSamplesFilename = nullSamplesFilenameArg.getValue();
		concordantFilename = concordantFilenameArg.getValue();
		mateAlignmentFilename = mateAlignmentFilenameArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	cerr << "Reading mate alignment scores" << endl;
	
	MateAlignmentScoreVec mateAlignmentScores;
	ReadMateAlignmentScores(mateAlignmentFilename, mateAlignmentScores);
	
	int minScore = numeric_limits<int>::max();
	int maxScore = numeric_limits<int>::min();
	int maxAlignmentCount = numeric_limits<int>::min();
	for (MateAlignmentScoreVecConstIter mateAlignmentScoreIter = mateAlignmentScores.begin(); mateAlignmentScoreIter != mateAlignmentScores.end(); mateAlignmentScoreIter++)
	{
		minScore = min(minScore,mateAlignmentScoreIter->score);
		maxScore = max(maxScore,mateAlignmentScoreIter->score);
		maxAlignmentCount = max(maxAlignmentCount,mateAlignmentScoreIter->alignmentCount);
	}
	
	cerr << "Creating extreme value distributions" << endl;
	
	IntegerVecMap nullSamples;
	ReadIntegerVecMap(nullSamplesFilename, nullSamples);
	
	AlignedLengthSpecificEVD evd;
	evd.Create(nullSamples, minScore, maxScore, maxAlignmentCount);
	
	cerr << "Estimating concordant score density" << endl;
	
	ifstream concordantFile(concordantFilename.c_str());
	CheckFile(concordantFile, concordantFilename);
	
	ScoreDensity concordantScoreDensity;
	concordantScoreDensity.Estimate(concordantFile);
	
	cerr << "Initializing EM" << endl;
	
	DoubleVec nullProb;
	DoubleVec alignProb;
	DoubleVec responsibility;
	for (int mateAlignIndex = 0; mateAlignIndex < mateAlignmentScores.size(); mateAlignIndex++)
	{
		nullProb.push_back(evd.Probability(mateAlignmentScores[mateAlignIndex].alignedLength, mateAlignmentScores[mateAlignIndex].score, mateAlignmentScores[mateAlignIndex].alignmentCount));
		alignProb.push_back(concordantScoreDensity.Probability(mateAlignmentScores[mateAlignIndex].alignedLength, mateAlignmentScores[mateAlignIndex].score));
		
		responsibility.push_back(nullProb.back() > alignProb.back() ? 1.0 : 0.0);
	}
	
	for (int iteration = 1; iteration <= 10; iteration++)
	{
		cerr << "EM Iteration " << iteration << endl;
		
		double sumResp = Sum(responsibility);
		double numValues = (double)responsibility.size();
		
		double pi = sumResp / numValues;
		
		for (int mateAlignIndex = 0; mateAlignIndex < mateAlignmentScores.size(); mateAlignIndex++)
		{
			responsibility[mateAlignIndex] = nullProb[mateAlignIndex] * pi / (nullProb[mateAlignIndex] * pi + alignProb[mateAlignIndex] * (1 - pi));
		}
		
		cerr << "prior: \t" << pi << endl;
	}
	
	for (int mateAlignIndex = 0; mateAlignIndex < mateAlignmentScores.size(); mateAlignIndex++)
	{
		cout << mateAlignmentScores[mateAlignIndex].fragmentIndex << "\t" << responsibility[mateAlignIndex] << endl;
	}
}

