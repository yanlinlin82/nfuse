/*
 *  clustermatepairs.cpp
 *
 *  Created by Andrew McPherson on 28/09/09.
 *
 */

#include "Common.h"
#include "DebugCheck.h"
#include "Indexer.h"
#include "ReadStream.h"
#include "AlignmentStream.h"
#include "Sequences.h"
#include "SimpleAligner.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

using namespace boost;
using namespace std;


void GetRandomSequence(int length, string& sequence)
{
	char ntchars[] = {'A','C','T','G'};
	
	while (sequence.length() < length)
	{
		sequence = sequence + ntchars[rand() % 4];
	}
}

void RandomSequenceTests16()
{
	cout << "16 bit score test" << endl;
	
	SimpleAligner aligner1(1, -1, -1);
	
	srand(1);
	while (true)
	{
		int length1 = rand() % 15 + 5;
		
		string seq1;
		GetRandomSequence(length1, seq1);
		
		int length2 = rand() % 15 + 5;
		
		string seq2;
		GetRandomSequence(length2, seq2);
		
		string reference = seq1;
		string sequence = seq2;
		
		int score;
		int length;
		aligner1.AlignBanded(seq1, seq2, 7, score, length);
		
		int scoreFwdSSE;
		{
			string refPad = string(8,'X') + reference + string(8+max(0,(int)(sequence.length()-reference.length())),'X');
			string seqPad = string(8,'Y') + sequence + string(8+max(0,(int)(reference.length()-sequence.length())),'Y');
			reverse(seqPad.begin(), seqPad.end());
			
			const char* refStart = refPad.c_str() + 8;
			const char* seqStart = seqPad.c_str() + seqPad.length() - sequence.length() - 8;
			const char* seqEnd = seqPad.c_str() + seqPad.length() - 8;
			
			scoreFwdSSE = aligner1.AlignBandedSSE2BW7ScoreFwd(refStart, seqStart, seqEnd);
		}
		
		int scoreRevSSE;
		{
			string refPad = string(8,'X') + reference + string(8+max(0,(int)(sequence.length()-reference.length())),'X');
			string seqPad = string(8,'Y') + sequence + string(8+max(0,(int)(reference.length()-sequence.length())),'Y');
			reverse(refPad.begin(), refPad.end());
			
			const char* refStart = refPad.c_str() + refPad.length() - 9;
			const char* seqStart = seqPad.c_str() + 8;
			const char* seqEnd = seqPad.c_str() + sequence.length() + 8;
			
			scoreRevSSE = aligner1.AlignBandedSSE2BW7ScoreRev(refStart, seqStart, seqEnd);
		}
		
		int scoreFwd;
		int lengthFwd;
		{
			string refPad = string(8,'X') + reference + string(8+max(0,(int)(sequence.length()-reference.length())),'X');
			string seqPad = string(8,'Y') + sequence + string(8+max(0,(int)(reference.length()-sequence.length())),'Y');
			reverse(seqPad.begin(), seqPad.end());
			
			const char* refStart = refPad.c_str() + 8;
			const char* seqStart = seqPad.c_str() + seqPad.length() - sequence.length() - 8;
			const char* seqEnd = seqPad.c_str() + seqPad.length() - 8;
			
			aligner1.AlignBandedFwd(refStart, seqStart, seqEnd, 7, scoreFwd, lengthFwd);
		}
		
		int scoreRev;
		int lengthRev;
		{
			string refPad = string(8,'X') + reference + string(8+max(0,(int)(sequence.length()-reference.length())),'X');
			string seqPad = string(8,'Y') + sequence + string(8+max(0,(int)(reference.length()-sequence.length())),'Y');
			reverse(refPad.begin(), refPad.end());
			
			const char* refStart = refPad.c_str() + refPad.length() - 9;
			const char* seqStart = seqPad.c_str() + 8;
			const char* seqEnd = seqPad.c_str() + sequence.length() + 8;
			
			aligner1.AlignBandedRev(refStart, seqStart, seqEnd, 7, scoreRev, lengthRev);
		}
		
		if (
			scoreFwd != score ||
			scoreRev != score ||
			scoreFwdSSE != score ||
			scoreRevSSE != score
			)
		{
			cout << seq1 << "\t" << seq2 << endl;
			cout << score << "\t" << scoreFwd << "\t" << scoreRev << "\t" << scoreFwdSSE << "\t" << scoreRevSSE << endl;
			exit(1);
		}
	}
}

void RandomSequenceTests8()
{
	cout << "8 bit score test" << endl;
	
	SimpleAligner aligner1(1, -1, -1);
	
	srand(1);
	while (true)
	{
		int length1 = rand() % 15 + 5;
		
		string seq1;
		GetRandomSequence(length1, seq1);
		
		int length2 = rand() % 15 + 5;
		
		string seq2;
		GetRandomSequence(length2, seq2);
		
		string reference = seq1;
		string sequence = seq2;
		
		int score;
		int length;
		aligner1.AlignBanded(seq1, seq2, 15, score, length);
		
		int scoreFwdSSE;
		{
			string refPad = string(8,'X') + reference + string(8+max(0,(int)(sequence.length()-reference.length())),'X');
			string seqPad = string(8,'Y') + sequence + string(8+max(0,(int)(reference.length()-sequence.length())),'Y');
			reverse(seqPad.begin(), seqPad.end());
			
			const char* refStart = refPad.c_str() + 8;
			const char* seqStart = seqPad.c_str() + seqPad.length() - sequence.length() - 8;
			const char* seqEnd = seqPad.c_str() + seqPad.length() - 8;
			
			scoreFwdSSE = aligner1.AlignBandedSSE2BW15ScoreFwd(refStart, seqStart, seqEnd);
		}
		
		int scoreRevSSE;
		{
			string refPad = string(8,'X') + reference + string(8+max(0,(int)(sequence.length()-reference.length())),'X');
			string seqPad = string(8,'Y') + sequence + string(8+max(0,(int)(reference.length()-sequence.length())),'Y');
			reverse(refPad.begin(), refPad.end());
			
			const char* refStart = refPad.c_str() + refPad.length() - 9;
			const char* seqStart = seqPad.c_str() + 8;
			const char* seqEnd = seqPad.c_str() + sequence.length() + 8;
			
			scoreRevSSE = aligner1.AlignBandedSSE2BW15ScoreRev(refStart, seqStart, seqEnd);
		}
		
		int scoreFwd;
		int lengthFwd;
		{
			string refPad = string(8,'X') + reference + string(8+max(0,(int)(sequence.length()-reference.length())),'X');
			string seqPad = string(8,'Y') + sequence + string(8+max(0,(int)(reference.length()-sequence.length())),'Y');
			reverse(seqPad.begin(), seqPad.end());
			
			const char* refStart = refPad.c_str() + 8;
			const char* seqStart = seqPad.c_str() + seqPad.length() - sequence.length() - 8;
			const char* seqEnd = seqPad.c_str() + seqPad.length() - 8;
			
			aligner1.AlignBandedFwd(refStart, seqStart, seqEnd, 15, scoreFwd, lengthFwd);
		}
		
		int scoreRev;
		int lengthRev;
		{
			string refPad = string(8,'X') + reference + string(8+max(0,(int)(sequence.length()-reference.length())),'X');
			string seqPad = string(8,'Y') + sequence + string(8+max(0,(int)(reference.length()-sequence.length())),'Y');
			reverse(refPad.begin(), refPad.end());
			
			const char* refStart = refPad.c_str() + refPad.length() - 9;
			const char* seqStart = seqPad.c_str() + 8;
			const char* seqEnd = seqPad.c_str() + sequence.length() + 8;
			
			aligner1.AlignBandedRev(refStart, seqStart, seqEnd, 15, scoreRev, lengthRev);
		}
		
		if (
			scoreFwd != score ||
			scoreRev != score ||
			scoreFwdSSE != score ||
			scoreRevSSE != score
			)
		{
			cout << seq1 << "\t" << seq2 << endl;
			cout << score << "\t" << scoreFwd << "\t" << scoreRev << "\t" << scoreFwdSSE << "\t" << scoreRevSSE << endl;
			exit(1);
		}
	}
}

int main(int argc, char* argv[])
{
	int matchScore;
	int misMatchScore;
	int gapScore;
	string referenceFasta;
	string readSeqsFilename;
	string readSeqs2Filename;
	
	int maxAlignments = 40;
	
	try
	{
		TCLAP::CmdLine cmd("Mate Realignment Tool");
		TCLAP::ValueArg<int> matchScoreArg("m","match","Match Score",true,0,"int",cmd);
		TCLAP::ValueArg<int> misMatchScoreArg("x","mismatch","Mismatch Score",true,0,"int",cmd);
		TCLAP::ValueArg<int> gapScoreArg("g","gap","Gap Score",true,0,"int",cmd);
		TCLAP::ValueArg<string> referenceFastaArg("r","reference","Reference Sequences Fasta",true,"","string",cmd);
		TCLAP::ValueArg<string> readSeqsFilenameArg("s","seq","Sequences",true,"","string",cmd);
		cmd.parse(argc,argv);
		
		matchScore = matchScoreArg.getValue();
		misMatchScore = misMatchScoreArg.getValue();
		gapScore = gapScoreArg.getValue();
		referenceFasta = referenceFastaArg.getValue();
		readSeqsFilename = readSeqsFilenameArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	cerr << "Reading reference fasta" << endl;
	
	Sequences referenceSequences;
	referenceSequences.Read(referenceFasta);
	
	cerr << "Reading fastq sequences" << endl;

	IReadStream* readSeqsStream = IReadStream::Create(readSeqsFilename);
	if (!readSeqsStream)
	{
		cout << "Error: unable to read sequences" << endl;
		exit(1);
	}
	
	unordered_map<ReadID,string> readSequences[2];
	
	RawRead rawRead;
	while (readSeqsStream->GetNextRead(rawRead))
	{
		ReadID readID;
		readID.fragmentIndex = lexical_cast<int>(rawRead.fragment);
		readID.readEnd = rawRead.readEnd;

		string paddedSequence = string(16,'X') + rawRead.sequence + string(16,'X');
		
		readSequences[0][readID] = paddedSequence;
		reverse(readSequences[0][readID].begin(), readSequences[0][readID].end());
		
		readSequences[1][readID] = paddedSequence;
		ReverseComplement(readSequences[1][readID]);
		reverse(readSequences[1][readID].begin(), readSequences[1][readID].end());
	}
	
	cerr << "Realigning" << endl;
	
	SimpleAligner aligner(matchScore, misMatchScore, gapScore);
	
	FragmentAlignmentStream fragmentAlignments(cin);
	
	RawAlignmentVec alignments;
	while (fragmentAlignments.GetNextAlignments(alignments))
	{
		bool hasEnd[2] = {false,false};
		for (RawAlignmentVecConstIter alignmentIter = alignments.begin(); alignmentIter != alignments.end(); alignmentIter++)
		{
			hasEnd[alignmentIter->readEnd] = true;
		}
		
		if (!hasEnd[0] || !hasEnd[1])
		{
			continue;
		}
		
		ReadID readID[2];
		const char* seqStartPtr[2][2];
		const char* seqEndPtr[2][2];
		
		for (int readEnd = 0; readEnd <= 1; readEnd++)
		{
			for (int strand = 0; strand <= 1; strand++)
			{
				readID[readEnd].fragmentIndex = lexical_cast<int>(alignments.front().fragment);
				readID[readEnd].readEnd = readEnd;
				
				if (readSequences[strand].find(readID[readEnd]) == readSequences[strand].end())
				{
					cerr << "Error: Could not find sequence for read " << readID[readEnd].fragmentIndex << endl;
					exit(1);
				}	
				
				seqStartPtr[strand][readEnd] = readSequences[strand][readID[readEnd]].c_str() + 16;
				seqEndPtr[strand][readEnd] = readSequences[strand][readID[readEnd]].c_str() + readSequences[strand][readID[readEnd]].length() - 16;
			}
		}
		
		map<int,vector<int> > alignmentScores[2];
		
		for (int alignmentIndex = 0; alignmentIndex < alignments.size(); alignmentIndex++)
		{
			const RawAlignment& alignment = alignments[alignmentIndex];
			
			int score;
			if (alignment.strand == PlusStrand)
			{
				const char* refPtr = referenceSequences.Get(alignment.reference, alignment.region.start);
				score = aligner.AlignBandedSSE2BW7ScoreFwd(refPtr, seqStartPtr[0][alignment.readEnd], seqEndPtr[0][alignment.readEnd]);
			}
			else
			{
				const char* refPtr = referenceSequences.Get(alignment.reference, alignment.region.end);
				score = aligner.AlignBandedSSE2BW7ScoreRev(refPtr, seqStartPtr[1][alignment.readEnd], seqEndPtr[1][alignment.readEnd]);
			}
			
			alignmentScores[alignment.readEnd][score].push_back(alignmentIndex);
		}
		
		if (alignmentScores[0].rbegin()->second.size() * alignmentScores[1].rbegin()->second.size() > maxAlignments)
		{
			continue;
		}
		
		for (int readEnd = 0; readEnd <= 1; readEnd++)
		{
			int topScore = alignmentScores[readEnd].rbegin()->first;
			const vector<int>& topScoring = alignmentScores[readEnd].rbegin()->second;
			for (vector<int>::const_iterator alignIter = topScoring.begin(); alignIter != topScoring.end(); alignIter++)
			{
				const RawAlignment alignment = alignments[*alignIter];
				
				int score;
				int length;
				int alignmentStart;
				int alignmentEnd;
				if (alignment.strand == PlusStrand)
				{
					const char* refPtr = referenceSequences.Get(alignment.reference, alignment.region.start);
					aligner.AlignBandedFwd(refPtr, seqStartPtr[0][alignment.readEnd], seqEndPtr[0][alignment.readEnd], 7, score, length);
					alignmentStart = alignment.region.start;
					alignmentEnd = alignment.region.start + length - 1;
				}
				else
				{
					const char* refPtr = referenceSequences.Get(alignment.reference, alignment.region.end);
					aligner.AlignBandedRev(refPtr, seqStartPtr[1][alignment.readEnd], seqEndPtr[1][alignment.readEnd], 7, score, length);
					alignmentStart = alignment.region.end - length + 1;
					alignmentEnd = alignment.region.end;
				}
				
				DebugCheck(alignment.readEnd == readEnd);
				//DebugCheck(topScore == score);
				
				cout << alignment.fragment << "\t";
				cout << alignment.readEnd << "\t";
				cout << alignment.reference << "\t";
				cout << ((alignment.strand == PlusStrand) ? "+" : "-") << "\t";
				cout << alignmentStart << "\t";
				cout << alignmentEnd << "\t";
				cout << score << endl;
			}
		}
	}
}

