/*
 *  Parsers.cpp
 *  tools
 *
 *  Created by Andrew McPherson on 10-09-02.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "Parsers.h"
#include "Common.h"
#include "DebugCheck.h"
#include "Indexer.h"

#include <map>
#include <fstream>
#include <iostream>
#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/unordered_set.hpp>

using namespace boost;
using namespace std;


void ReadClusterMembership(const string& clustersFilename, IntegerVecMap& clusters)
{
	ifstream clustersFile(clustersFilename.c_str());
	if (!clustersFile)
	{
		cerr << "Error: unable to read from clusters file " << clustersFilename << endl;		
		exit(1);
	}
	
	int nextLibIndex = 0;
	unordered_map<string,int> libNameLookup;
	
	libNameLookup.insert(make_pair("",nextLibIndex));
	nextLibIndex++;
	
	int nextFragmentIndex = 0;
	unordered_map<pair<int,int>,int> fragmentLookup;
	
	string line;
	int lineNumber = 0;
	while (getline(clustersFile, line))
	{
		lineNumber++;
		
		if (line.length() == 0)
		{
			cerr << "Error: Empty clusters line " << lineNumber << " of " << clustersFilename << endl;
			exit(1);
		}
		
		vector<string> clusterFields;
		split(clusterFields, line, is_any_of("\t"));
		
		if (clusterFields.size() < 3)
		{
			cerr << "Error: Format error for clusters line " << lineNumber << " of " << clustersFilename << endl;
			exit(1);
		}
		
		int clusterID = lexical_cast<int>(clusterFields[0]);
		if (clusterID < 0)
		{
			cerr << "Error: Invalid cluster ID for line " << lineNumber << " of " << clustersFilename << endl;
			exit(1);
		}
		
		int clusterEnd = lexical_cast<int>(clusterFields[1]);
		if (clusterEnd != 0)
		{
			continue;
		}		
		
		int fragmentID = lexical_cast<int>(clusterFields[2]);
		
		int libIndex = 0;
		if (clusterFields.size() > 9)
		{
			const string& libName = clusterFields[8];
			
			pair<unordered_map<string,int>::const_iterator,bool> libLookupResult = libNameLookup.insert(make_pair(libName, nextLibIndex));
			if (libLookupResult.second)
			{
				nextLibIndex++;
			}
			libIndex = libLookupResult.first->second;
		}
		
		pair<unordered_map<pair<int,int>,int>::const_iterator,bool> fragmentLookupResult = fragmentLookup.insert(make_pair(make_pair(libIndex, fragmentID), nextFragmentIndex));
		if (fragmentLookupResult.second)
		{
			nextFragmentIndex++;
		}
		int fragmentIndex = fragmentLookupResult.first->second;
		
		clusters[clusterID].push_back(fragmentIndex);
	}
	
	clustersFile.close();
}

void ReadClusters(const string& clustersFilename, CompactLocationVecMap& clusters, NameIndex& references)
{
	// Open clusters file
	ifstream clustersFile(clustersFilename.c_str());
	CheckFile(clustersFile, clustersFilename);
	
	ClusterReader clusterReader(clustersFile);
	int clusterID;
	LocationVec clusterLocations(2);
	IntegerVec fragmentIndices;
	while (clusterReader.Next(clusterID, clusterLocations, fragmentIndices))
	{
		for (int clusterEnd = 0; clusterEnd <= 1; clusterEnd++)
		{
			ClusterEndID clusterEndID;
			clusterEndID.clusterID = clusterID;
			clusterEndID.clusterEnd = clusterEnd;
			
			CompactLocation location;
			location.refStrand.referenceIndex = references.Index(clusterLocations[clusterEnd].refName);
			location.refStrand.strand = clusterLocations[clusterEnd].strand;
			location.region.start = clusterLocations[clusterEnd].start;
			location.region.end = clusterLocations[clusterEnd].end;
			
			clusters[clusterID].push_back(location);
		}
	}
	
	clustersFile.close();
}

void WriteClusters(const string& inClustersFilename, const string& outClustersFilename, const IntegerSet& clusters)
{
	// Open output clusters file
	ofstream outClustersFile(outClustersFilename.c_str());
	if (!outClustersFile)
	{
		cerr << "Error: unable to write to clusters file " << outClustersFilename << endl;		
		exit(1);
	}
	
	// Open input clusters file
	ifstream inClustersFile(inClustersFilename.c_str());
	if (!inClustersFile)
	{
		cerr << "Error: unable to read from clusters file " << inClustersFilename << endl;		
		exit(1);
	}
	
	// Parse file contents
	string line;
	int lineNumber = 0;
	while (getline(inClustersFile, line))
	{
		lineNumber++;
		
		if (line.length() == 0)
		{
			cerr << "Error: Empty clusters line " << lineNumber << " of " << outClustersFilename << endl;
			exit(1);
		}
		
		vector<string> clusterFields;
		split(clusterFields, line, is_any_of("\t"));
		
		if (clusterFields.size() < 3)
		{
			cerr << "Error: Format error for clusters line " << lineNumber << " of " << outClustersFilename << endl;
			exit(1);
		}
		
		int clusterID = lexical_cast<int>(clusterFields[0]);
		
		if (clusterID < 0)
		{
			cerr << "Error: Invalid cluster ID for line " << lineNumber << " of " << outClustersFilename << endl;
			exit(1);
		}
		
		// Output cluster line if the fragment index is in this output cluster
		if (clusters.find(clusterID) != clusters.end())
		{
			outClustersFile << line << endl;
		}
	}
	
	outClustersFile.close();
	inClustersFile.close();
}

void ReadCorroboration(const string& corroborationFilename, IntegerVecPairVec& corroboration)
{
	// Open corroboration file
	ifstream corroborationFile(corroborationFilename.c_str());
	if (!corroborationFile)
	{
		cerr << "Error: unable to read from corroboration file " << corroborationFilename << endl;		
		exit(1);
	}
	
	// Parse file contents
	string line;
	int lineNumber = 0;
	while (getline(corroborationFile, line))
	{
		lineNumber++;
		
		if (line.length() == 0)
		{
			cerr << "Error: Empty corroboration line " << lineNumber << " of " << corroborationFilename << endl;
			exit(1);
		}
		
		vector<string> corroborationFields;
		split(corroborationFields, line, is_any_of("\t"));
		
		if (corroborationFields.size() < 1)
		{
			cerr << "Error: Format error for corroboration line " << lineNumber << " of " << corroborationFilename << endl;
			exit(1);
		}
		
		IntegerVec rnaClusterIDs;
		if (corroborationFields[0] != "")
		{
			int rnaClusterID = lexical_cast<int>(corroborationFields[0]);
			rnaClusterIDs.push_back(rnaClusterID);
		}
		
		IntegerVec dnaClusterIDs;
		for (int fieldIndex = 1; fieldIndex < (int)corroborationFields.size(); fieldIndex++)
		{
			dnaClusterIDs.push_back(lexical_cast<int>(corroborationFields[fieldIndex]));
		}
		
		corroboration.push_back(IntegerVecPair());
		swap(corroboration.back().first, rnaClusterIDs);
		swap(corroboration.back().second, dnaClusterIDs);		
	}
	
	corroborationFile.close();
}

void IntepretAlignString(const string& alignString, Location& alignRegion)
{
	string::size_type colonDividerPos = alignString.find_first_of(":");
	if (colonDividerPos == string::npos || colonDividerPos == 0)
	{
		cerr << "Error: Unable to interpret strand for " << alignString << endl;
		exit(1);
	}
	
	char strand = alignString[colonDividerPos - 1];
	
	if (strand == '+')
	{
		alignRegion.strand = PlusStrand;
	}
	else if (strand == '-')
	{
		alignRegion.strand = MinusStrand;
	}
	else
	{
		cerr << "Error: Unable to interpret strand for " << alignString << endl;
		exit(1);
	}
	
	vector<string> alignFields;
	split(alignFields, alignString, is_any_of("+-:"));
	
	if (alignFields.size() != 4)
	{
		cerr << "Error: Unable to interpret alignment string " << alignString << endl;
		exit(1);
	}
	
	alignRegion.refName = alignFields[0];
	alignRegion.start = lexical_cast<int>(alignFields[2]);
	alignRegion.end = lexical_cast<int>(alignFields[3]);
}

void ReadAlignRegionPairs(const string& filename, LocationVecMap& alignRegionPairs)
{
	ifstream alignRegionPairsFile(filename.c_str());
	if (!alignRegionPairsFile.good())
	{
		cerr << "Error: Unable to open align region pairs file " << filename << endl;
		exit(1);
	}
	
	string line;
	int lineNumber = 0;
	
	while (getline(alignRegionPairsFile, line))
	{
		lineNumber++;
		
		if (line.length() == 0)
		{
			continue;
		}
		
		vector<string> alignRegionFields;
		split(alignRegionFields, line, is_any_of("\t"));
		
		if (alignRegionFields.size() < 5)
		{
			continue;
		}
		
		int pairID = lexical_cast<int>(alignRegionFields[0]);
		int pairEnd = lexical_cast<int>(alignRegionFields[1]);
		
		DebugCheck(pairEnd == 0 || pairEnd == 1);
		
		Location alignRegion;
		alignRegion.refName = alignRegionFields[2];
		alignRegion.strand = InterpretStrand(alignRegionFields[3]);
		alignRegion.start = lexical_cast<int>(alignRegionFields[4]);
		alignRegion.end = lexical_cast<int>(alignRegionFields[5]);
		
		alignRegionPairs[pairID].resize(2);
		alignRegionPairs[pairID][pairEnd] = alignRegion;
	}
	
	alignRegionPairsFile.close();
}

void ReadDoubleMap(const string& filename, DoubleMap& values)
{
	ifstream file(filename.c_str());
	if (!file.good())
	{
		cerr << "Error: Unable to open file " << filename << endl;
		exit(1);
	}
	
	string line;
	int lineNumber = 0;
	
	while (getline(file, line))
	{
		lineNumber++;
		
		if (line.length() == 0)
		{
			continue;
		}
		
		vector<string> fields;
		split(fields, line, is_any_of("\t"));
		
		if (fields.size() < 2)
		{
			continue;
		}
		
		int id = lexical_cast<int>(fields[0]);
		double value = lexical_cast<long double>(fields[1]);
		
		values[id] = value;
	}
	
	file.close();
}

void ReadAlignmentScores(const string& filename, AlignmentScoreVec& alignmentScores)
{
	ifstream file(filename.c_str());
	if (!file.good())
	{
		cerr << "Error: Unable to open file " << filename << endl;
		exit(1);
	}
	
	string line;
	int lineNumber = 0;
	
	map<int,AlignmentScore> alignmentScoreMap;
	
	while (getline(file, line))
	{
		lineNumber++;
		
		if (line.length() == 0)
		{
			continue;
		}
		
		vector<string> fields;
		split(fields, line, is_any_of("\t"));
		
		if (fields.size() < 5)
		{
			continue;
		}
		
		AlignmentScore alignmentScore;
		alignmentScore.readID.fragmentIndex = lexical_cast<int>(fields[0]);
		alignmentScore.readID.readEnd = lexical_cast<int>(fields[1]);
		alignmentScore.alignedLength = lexical_cast<int>(fields[7]);
		alignmentScore.score = -lexical_cast<int>(fields[8]);
		
		map<int,AlignmentScore>::iterator alignmentScoreIter = alignmentScoreMap.insert(alignmentScoreMap.end(), make_pair(alignmentScore.readID.id, alignmentScore));
		
		if (alignmentScore.score > alignmentScoreIter->second.score)
		{
			alignmentScoreIter->second.score = alignmentScore.score;
			alignmentScoreIter->second.alignedLength = alignmentScore.alignedLength;
		}
	}
	
	file.close();
	
	for (map<int,AlignmentScore>::const_iterator alignmentScoreIter = alignmentScoreMap.begin(); alignmentScoreIter != alignmentScoreMap.end(); alignmentScoreIter++)
	{
		alignmentScores.push_back(alignmentScoreIter->second);
	}
}

void ReadMateAlignmentScores(const string& filename, MateAlignmentScoreVec& mateAlignmentScores)
{
	ifstream file(filename.c_str());
	if (!file.good())
	{
		cerr << "Error: Unable to open file " << filename << endl;
		exit(1);
	}
	
	string line;
	int lineNumber = 0;
	
	map<int,MateAlignmentScore> mateAlignmentScoreMap;
	
	while (getline(file, line))
	{
		lineNumber++;
		
		if (line.length() == 0)
		{
			continue;
		}
		
		vector<string> fields;
		split(fields, line, is_any_of("\t"));
		
		if (fields.size() < 4)
		{
			continue;
		}
		
		MateAlignmentScore mateAlignmentScore;
		mateAlignmentScore.fragmentIndex = lexical_cast<int>(fields[0]);
		mateAlignmentScore.alignedLength = lexical_cast<int>(fields[2]);
		mateAlignmentScore.score = lexical_cast<int>(fields[3]);
		mateAlignmentScore.alignmentCount = 0;
		
		map<int,MateAlignmentScore>::iterator mateAlignmentScoreIter = mateAlignmentScoreMap.insert(mateAlignmentScoreMap.end(), make_pair(mateAlignmentScore.fragmentIndex, mateAlignmentScore));
		
		mateAlignmentScoreIter->second.alignmentCount++;
		
		if (mateAlignmentScore.score > mateAlignmentScoreIter->second.score)
		{
			mateAlignmentScoreIter->second.score = mateAlignmentScore.score;
			mateAlignmentScoreIter->second.alignedLength = mateAlignmentScore.alignedLength;
		}
	}
	
	file.close();
	
	for (map<int,MateAlignmentScore>::const_iterator mateAlignmentScoreIter = mateAlignmentScoreMap.begin(); mateAlignmentScoreIter != mateAlignmentScoreMap.end(); mateAlignmentScoreIter++)
	{
		mateAlignmentScores.push_back(mateAlignmentScoreIter->second);
	}
}

void ReadDoubleVec(const string& filename, DoubleVec& values)
{
	ifstream file(filename.c_str());
	if (!file.good())
	{
		cerr << "Error: Unable to open file " << filename << endl;
		exit(1);
	}
	
	string line;
	int lineNumber = 0;
	
	while (getline(file, line))
	{
		lineNumber++;
		
		if (line.length() == 0)
		{
			continue;
		}
		
		values.push_back(lexical_cast<double>(line));
	}
	
	file.close();
}

void ReadIntegerVecMap(const string& filename, IntegerVecMap& values)
{
	ifstream file(filename.c_str());
	if (!file.good())
	{
		cerr << "Error: Unable to open file " << filename << endl;
		exit(1);
	}
	
	string line;
	int lineNumber = 0;
	
	while (getline(file, line))
	{
		lineNumber++;
		
		if (line.length() == 0)
		{
			continue;
		}
		
		vector<string> fields;
		split(fields, line, is_any_of("\t"));
		
		if (fields.size() < 2)
		{
			continue;
		}
		
		int id = lexical_cast<int>(fields[0]);
		int value = lexical_cast<int>(fields[1]);
		
		values[id].push_back(value);
	}
	
	file.close();
}

bool GetLineTSV(istream& file, StringVec& fields)
{
	string line;
	if (!getline(file, line))
	{
		return false;
	}
	
	split(fields, line, is_any_of("\t"));
	
	return true;
}

void ReadStringPairs(const string& filename, vector<pair<string,string> >& values)
{
	ifstream file(filename.c_str());
	if (!file.good())
	{
		cerr << "Error: Unable to open file " << filename << endl;
		exit(1);
	}
	
	string line;
	int lineNumber = 0;
	
	while (getline(file, line))
	{
		lineNumber++;
		
		if (line.length() == 0)
		{
			continue;
		}
		
		vector<string> fields;
		split(fields, line, is_any_of("\t"));
		
		if (fields.size() < 2)
		{
			continue;
		}
		
		values.push_back(make_pair(fields[0],fields[1]));
	}
	
	file.close();
}

ClusterReader::ClusterReader(istream& clustersFile) : mClustersFile(clustersFile), mLineNumber(0)
{
	if (!mClustersFile)
	{
		cerr << "Error: unable to read clusters" << endl;		
		exit(1);
	}
	
	mLastGetResult = GetLineTSV(mClustersFile, mCurrentFields);

	if (mLastGetResult)
	{
		mLineNumber++;
		mCurrentClusterID = mCurrentFields[0];
	}
}

bool ClusterReader::Next(int& clusterID, LocationVec& clusterLocations, IntegerVec& fragmentIndices)
{
	if (!mLastGetResult)
	{
		return false;
	}
	
	bool clusterInit[2] = {false, false};
	
	fragmentIndices.clear();
	
	while (mLastGetResult && mCurrentFields[0] == mCurrentClusterID)
	{
		Interpret(mCurrentFields, clusterLocations, fragmentIndices, clusterInit);
		mLastGetResult = GetLineTSV(mClustersFile, mCurrentFields);
		mLineNumber++;
	}
	
	int previousID = lexical_cast<int>(mCurrentClusterID);
	
	if (fragmentIndices.empty())
	{
		cerr << "Error: cluster " << previousID << " with no fragments" << endl;
		exit(1);
	}
	
	mCurrentClusterID = mCurrentFields[0];
	
	clusterID = previousID;
	
	return true;
}

void ClusterReader::Interpret(const StringVec& fields, LocationVec& clusterLocations, IntegerVec& fragmentIndices, bool clusterInit[])
{
	if (fields.size() < 8)
	{
		cerr << "Error: Empty clusters line " << mLineNumber << endl;
		exit(1);
	}
	
	int clusterID = lexical_cast<int>(fields[0]);
	int clusterEnd = lexical_cast<int>(fields[1]);
	
	int fragmentIndex = lexical_cast<int>(fields[2]);
	int readEnd = lexical_cast<int>(fields[3]);
	
	clusterLocations[clusterEnd].refName = fields[4];
	clusterLocations[clusterEnd].strand = InterpretStrand(fields[5]);
	
	int start = lexical_cast<int>(fields[6]);
	int end = lexical_cast<int>(fields[7]);
	
	if (!clusterInit[clusterEnd])
	{
		clusterLocations[clusterEnd].start = start;
		clusterLocations[clusterEnd].end = end;
		
		clusterInit[clusterEnd] = true;
	}
	
	clusterLocations[clusterEnd].start = min(clusterLocations[clusterEnd].start, start);
	clusterLocations[clusterEnd].end = min(clusterLocations[clusterEnd].end, end);
	
	if (readEnd == 0)
	{
		fragmentIndices.push_back(fragmentIndex);
	}
}


