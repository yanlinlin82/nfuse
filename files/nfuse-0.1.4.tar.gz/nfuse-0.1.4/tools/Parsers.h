/*
 *  Parsers.h
 */

#ifndef PARSERS_H_
#define PARSERS_H_

#include "Common.h"
#include "Indexer.h"

#include <fstream>
#include <iostream>
#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/unordered_set.hpp>

using namespace boost;
using namespace std;


struct AlignmentScore
{
	ReadID readID;
	int score;
	int alignedLength;
};

typedef vector<AlignmentScore> AlignmentScoreVec;
typedef vector<AlignmentScore>::iterator AlignmentScoreVecIter;
typedef vector<AlignmentScore>::const_iterator AlignmentScoreVecConstIter;

struct MateAlignmentScore
{
	int fragmentIndex;
	int score;
	int alignedLength;
	int alignmentCount;
};

typedef vector<MateAlignmentScore> MateAlignmentScoreVec;
typedef vector<MateAlignmentScore>::iterator MateAlignmentScoreVecIter;
typedef vector<MateAlignmentScore>::const_iterator MateAlignmentScoreVecConstIter;

void ReadClusterMembership(const string& clustersFilename, IntegerVecMap& clusters);
void ReadClusters(const string& clustersFilename, CompactLocationVecMap& clusters, NameIndex& references);
void WriteClusters(const string& inClustersFilename, const string& outClustersFilename, const IntegerSet& clusters);
void ReadCorroboration(const string& corroborationFilename, IntegerVecPairVec& corroboration);
void IntepretAlignString(const string& alignString, Location& alignRegion);
void ReadAlignRegionPairs(const string& filename, LocationVecMap& alignRegionPairs);
void ReadDoubleMap(const string& filename, DoubleMap& values);
void ReadAlignmentScores(const string& filename, AlignmentScoreVec& mateAlignments);
void ReadMateAlignmentScores(const string& filename, MateAlignmentScoreVec& mateAlignments);
void ReadDoubleVec(const string& filename, DoubleVec& values);
void ReadIntegerVecMap(const string& filename, IntegerVecMap& values);
bool GetLineTSV(istream& file, StringVec& fields);
void ReadStringPairs(const string& filename, vector<pair<string,string> >& values);


class ClusterReader
{
public:
	ClusterReader(istream& clustersFile);
	
	bool Next(int& clusterID, LocationVec& clusterLocations, IntegerVec& fragmentIndices);
	
private:
	void Interpret(const StringVec& fields, LocationVec& clusterLocations, IntegerVec& fragmentIndices, bool clusterInit[]);
	
	istream& mClustersFile;
	bool mLastGetResult;
	string mCurrentClusterID;
	StringVec mCurrentFields;
	int mLineNumber;
};

#endif

