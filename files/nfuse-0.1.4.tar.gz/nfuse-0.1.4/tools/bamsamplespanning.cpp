/*
 *  bamsamplespanning.cpp
 *
 *  Created by Andrew McPherson on 17/08/11.
 *
 */

#include "Common.h"
#include "DebugCheck.h"
#include "Parsers.h"
#include "api/BamReader.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/unordered_set.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

using namespace boost;
using namespace std;

using namespace BamTools;


int main(int argc, char* argv[])
{
	string bamFilename;
	int numSamples;
	int maxFragmentLength;
	string ignoreList;
	int minPartialAlignLength;
	
	try
	{
		TCLAP::CmdLine cmd("Sample spanning distribution");
		TCLAP::ValueArg<string> bamFilenameArg("b","bam","Bam Filename",true,"","string",cmd);
		TCLAP::ValueArg<int> numSamplesArg("n","numsamples","Number of Samples",true,0,"integer",cmd);
		TCLAP::ValueArg<int> maxFragmentLengthArg("m","maxfrag","Maximum Fragment Length",true,0,"integer",cmd);
		TCLAP::ValueArg<string> ignoreListArg("i","ignore","Reference Sequences to Ignore (comma separated)",false,"","string",cmd);
		TCLAP::ValueArg<int> minPartialAlignLengthArg("p","partial","Minimum Length of a Partial Alignment",true,0,"integer",cmd);
		cmd.parse(argc,argv);

		bamFilename = bamFilenameArg.getValue();
		numSamples = numSamplesArg.getValue();
		maxFragmentLength = maxFragmentLengthArg.getValue();
		ignoreList = ignoreListArg.getValue();
		minPartialAlignLength = minPartialAlignLengthArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "Error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	unordered_set<string> ignoreReferences;
	if (!ignoreList.empty())
	{
		vector<string> ignoreListFields;
		split(ignoreListFields, ignoreList, is_any_of(","));
		
		for (vector<string>::const_iterator fieldIter = ignoreListFields.begin(); fieldIter != ignoreListFields.end(); fieldIter++)
		{
			ignoreReferences.insert(*fieldIter);
		}
	}
	
	// Initialize RNG for predictability
	srand(11);
	
	BamReader bamReader;
	if (!bamReader.Open(bamFilename))
	{
		cerr << "Error: Unable to open bam file " << bamFilename << endl;
		exit(1);
	}
	
	if (!bamReader.LocateIndex())
	{
		cerr << "Error: Unable to find index for bam file " << bamFilename << endl;
		exit(1);
	}
	
	const RefVector& bamReferences = bamReader.GetReferenceData(); 
	
	int samples = 0;
	while (samples < numSamples)
	{
		int referenceIndex = rand() % bamReferences.size();
		
		if (ignoreReferences.find(bamReferences[referenceIndex].RefName) != ignoreReferences.end())
		{
			continue;
		}
		
		int position = rand() % bamReferences[referenceIndex].RefLength;
		
		int spanningCount = 0;
		
		BamAlignment alignment;
		bamReader.SetRegion(referenceIndex, position - maxFragmentLength, referenceIndex, position + maxFragmentLength);
		while (bamReader.GetNextAlignmentCore(alignment))
		{
			if (!alignment.IsProperPair())
			{
				continue;
			}
			
			int leftPosition = alignment.Position + minPartialAlignLength - 1;
			int rightPosition = alignment.MatePosition + alignment.Length - minPartialAlignLength;
			
			if (leftPosition >= rightPosition)
			{
				continue;
			}
			
			if (leftPosition < position && rightPosition >= position)
			{
				spanningCount++;
			}
		}
		
		cout << spanningCount << endl;
		
		samples++;
	}
}

