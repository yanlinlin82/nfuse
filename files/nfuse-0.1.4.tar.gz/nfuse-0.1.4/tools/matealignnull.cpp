/*
 *  matealignnull.cpp
 *
 *  Created by Andrew McPherson on 28/09/09.
 *
 */

#include "Common.h"
#include "DebugCheck.h"
#include "Indexer.h"
#include "ReadStream.h"
#include "Sequences.h"
#include "AffineGapDP.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

using namespace boost;
using namespace std;


int main(int argc, char* argv[])
{
	int searchLength;
	string referenceFasta;
	
	try
	{
		TCLAP::CmdLine cmd("Mate Realignment Null Distribution");
		TCLAP::ValueArg<int> searchLengthArg("l","length","Search Length",true,-1,"integer",cmd);
		TCLAP::ValueArg<string> referenceFastaArg("r","reference","Reference Sequences Fasta",true,"","string",cmd);
		cmd.parse(argc,argv);
		
		searchLength = searchLengthArg.getValue();
		referenceFasta = referenceFastaArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
		
	cerr << "Read reference fasta" << endl;
	
	Sequences referenceSequences;
	referenceSequences.Read(referenceFasta);
	
	// Initialize RNG for predictability
	srand(1);
	
	FastqReadStream readSeqsStream(cin);
	
	cerr << "Doing null mate alignments" << endl;
	
	AffineGapDP aligner;
	
	RawRead rawRead;
	while (readSeqsStream.GetNextRead(rawRead))
	{
		string referenceSequence;
		referenceSequences.GetRandomSequence(searchLength, referenceSequence);
		
		IntegerVec scores;
		aligner.PartialAlign(referenceSequence, rawRead.sequence, rawRead.quality, scores);

		for (int alignedLength = 10; alignedLength <= (int)rawRead.sequence.size(); alignedLength++)
		{
			cout << alignedLength << "\t" << scores[alignedLength-1] << endl;
		}
	}
}

