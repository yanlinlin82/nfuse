/*
 *  matealignnull.cpp
 *
 *  Created by Andrew McPherson on 28/09/09.
 *
 */

#include "Common.h"
#include "DebugCheck.h"
#include "Indexer.h"
#include "AlignmentStream.h"
#include "Sequences.h"
#include "AffineGapDP.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

using namespace boost;
using namespace std;


int main(int argc, char* argv[])
{
	string alignmentsFilename;
	string referenceFasta;
	
	try
	{
		TCLAP::CmdLine cmd("Read Alignment True Distribution");
		TCLAP::ValueArg<string> alignmentsFilenameArg("a","align","Sam Alignments Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> referenceFastaArg("r","reference","Reference Sequences Fasta",true,"","string",cmd);
		cmd.parse(argc,argv);
		
		alignmentsFilename = alignmentsFilenameArg.getValue();
		referenceFasta = referenceFastaArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
		
	cerr << "Read reference fasta" << endl;
	
	Sequences referenceSequences;
	referenceSequences.Read(referenceFasta);
	
	AffineGapDP aligner;
	
	AlignmentStream* alignmentStream = new SamAlignmentStream(alignmentsFilename);
	FragmentAlignmentStream fragmentAlignments(alignmentStream);
	
	cerr << "Realigning to calculate partial scores" << endl;
	
	RawAlignmentVec alignments;
	while (fragmentAlignments.GetNextAlignments(alignments))
	{
		if (alignments.size() != 2)
		{
			cerr << "Error: Must be paired concordant alignments" << endl;
		}
		
		for (int readEnd = 0; readEnd <= 1; readEnd++)
		{
			int start = alignments[readEnd].region.start - 20;
			int end = alignments[readEnd].region.end + 20;
			
			string referenceSequence;
			referenceSequences.Get(alignments[readEnd].reference, start, end, referenceSequence);
			
			IntegerVec scores;
			aligner.PartialAlign(referenceSequence, alignments[readEnd].sequence, alignments[readEnd].quality, scores);
			
			for (int alignedLength = 10; alignedLength <= (int)alignments[readEnd].sequence.size(); alignedLength++)
			{
				cout << alignedLength << "\t" << scores[alignedLength-1] << endl;
			}
		}
	}
}

