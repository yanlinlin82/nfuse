/*
 *  rankclusters.cpp
 *
 *  Created by Andrew McPherson
 *
 */

#include "Common.h"
#include "DebugCheck.h"
#include "Sequences.h"
#include "Parsers.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/math/distributions/lognormal.hpp>
#include <boost/math/distributions/negative_binomial.hpp>

using namespace boost;
using namespace boost::math;
using namespace std;


void ReadNumMappings(const string& clustersFilename, IntegerMap& numMappings)
{
	ifstream clustersFile(clustersFilename.c_str());
	CheckFile(clustersFile, clustersFilename);
	
	ClusterReader clusterReader(clustersFile);
	
	int clusterID;
	LocationVec clusterLocations(2);
	IntegerVec fragmentIndices;
	while (clusterReader.Next(clusterID, clusterLocations, fragmentIndices))
	{
		for (IntegerVecConstIter fragIter = fragmentIndices.begin(); fragIter != fragmentIndices.end(); fragIter++)
		{
			numMappings.insert(make_pair(*fragIter, 0));
			numMappings.find(*fragIter)->second++;
		}
	}
}

double CalculateClusterProbability(const IntegerVec& fragmentIndices, const DoubleMap& alignProbability, const DoubleMap& mateAlignProbability, const IntegerMap& numMappings, double depthProbability)
{
	DoubleVec fragmentProbability;
	for (IntegerVecConstIter fragIter = fragmentIndices.begin(); fragIter != fragmentIndices.end(); fragIter++)
	{
		fragmentProbability.push_back(alignProbability.find(*fragIter)->second * mateAlignProbability.find(*fragIter)->second / (double)numMappings.find(*fragIter)->second);
	}
	
	DoubleVec previousRow;
	previousRow.push_back(1.0 - fragmentProbability[0]);
	previousRow.push_back(fragmentProbability[0]);
	
	for (int l = 1; l < fragmentIndices.size(); l++)
	{
		DoubleVec nextRow;
		
		double prob0 = previousRow[0] * (1.0 - fragmentProbability[l]);
		nextRow.push_back(prob0);
		
		for (int k = 1; k <= l; k++)
		{
			double prob = previousRow[k-1] * fragmentProbability[l] + previousRow[k] * (1.0 - fragmentProbability[l]);
			nextRow.push_back(prob);
		}
		
		double prob = previousRow[l] * fragmentProbability[l];
		nextRow.push_back(prob);
		
		swap(nextRow, previousRow);
	}
	
	DebugCheck(previousRow.size() == fragmentIndices.size() + 1);
	
	double clusterProb = 0.0;
	for (int n = 1; n <= fragmentIndices.size(); n++)
	{
		clusterProb += previousRow[n] * depthProbability;
	}
	
	return clusterProb;
}

class MapWithDefault
{
public:
	MapWithDefault(double defaultValue, DoubleMap& map) : mDefaultValue(defaultValue), mMap(map) {}
	MapWithDefault(double defaultValue) : mDefaultValue(defaultValue) {}
	
	double operator [](int key) const
	{
		DoubleMapConstIter mapIter = mMap.find(key);
		if (mapIter == mMap.end())
		{
			return mDefaultValue;
		}
		else
		{
			return mapIter->second;
		}
	}
	
private:
	double mDefaultValue;
	DoubleMap mMap;
};

void OutputClusterProbabilities(const string& clustersFilename, const DoubleMap& alignProbability, const DoubleMap& mateAlignProbability, const IntegerMap& numMappings, const MapWithDefault& depthProbabilities)
{
	ifstream clustersFile(clustersFilename.c_str());
	CheckFile(clustersFile, clustersFilename);
	
	ClusterReader clusterReader(clustersFile);
	
	int clusterID;
	LocationVec clusterLocations(2);
	IntegerVec fragmentIndices;
	while (clusterReader.Next(clusterID, clusterLocations, fragmentIndices))
	{
		int clusterSize = (int)fragmentIndices.size();
		double clusterProbability = CalculateClusterProbability(fragmentIndices, alignProbability, mateAlignProbability, numMappings, depthProbabilities[clusterSize]);
		
		cout << clusterID << "\t" << clusterProbability << endl;
	}
}

int main(int argc, char* argv[])
{
	string clustersFilename;
	string alignProbFilename;
	string mateAlignProbFilename;
	string depthProbFilename;
	
	try
	{
		TCLAP::CmdLine cmd("Cluster ranking tool");
		TCLAP::ValueArg<string> clustersFilenameArg("c","clusters","Clusters Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> alignProbFilenameArg("a","align","Alignment Probability Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> mateAlignProbFilenameArg("m","mate","Mate Alignment Probability Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> depthProbFilenameArg("d","depthprob","Depth Probability Filename",false,"","string",cmd);
		cmd.parse(argc,argv);
		
		clustersFilename = clustersFilenameArg.getValue();
		alignProbFilename = alignProbFilenameArg.getValue();
		mateAlignProbFilename = mateAlignProbFilenameArg.getValue();
		depthProbFilename = depthProbFilenameArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	cerr << "Reading alignment probabilities" << endl;
	
	DoubleMap alignProbability;
	ReadDoubleMap(alignProbFilename, alignProbability);
	
	cerr << "Reading mate alignment probabilities" << endl;
	
	DoubleMap mateAlignProbability;
	ReadDoubleMap(mateAlignProbFilename, mateAlignProbability);
	
	cerr << "Reading number of mappings per read" << endl;
	
	IntegerMap numMappings;
	ReadNumMappings(clustersFilename, numMappings);
	
	cerr << "Calculating cluster probabilities" << endl;
	
	if (depthProbFilename.empty())
	{
		OutputClusterProbabilities(clustersFilename, alignProbability, mateAlignProbability, numMappings, MapWithDefault(1.0));
	}
	else
	{
		DoubleMap depthProbability;
		ReadDoubleMap(depthProbFilename, depthProbability);
		OutputClusterProbabilities(clustersFilename, alignProbability, mateAlignProbability, numMappings, MapWithDefault(1.0,depthProbability));
	}
}

