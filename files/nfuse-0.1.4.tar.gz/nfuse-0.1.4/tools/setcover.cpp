/*
 *  setcover.cpp
 *
 *  Created by Andrew McPherson on 10-08-24.
 *
 */

#include "Common.h"
#include "DebugCheck.h"
#include "Parsers.h"
#include "Algorithms.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <tclap/CmdLine.h>

using namespace boost;
using namespace std;


int main(int argc, char* argv[])
{
	string clustersFilename;
	string outClustersFilename;
	
	try
	{
		TCLAP::CmdLine cmd("Set cover for maximum parsimony");
		TCLAP::ValueArg<string> clustersFilenameArg("c","clusters","Clusters Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> outClustersFilenameArg("o","outclust","Output Clusters Filename",true,"","string",cmd);
		cmd.parse(argc,argv);
		
		clustersFilename = clustersFilenameArg.getValue();
		outClustersFilename = outClustersFilenameArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	cout << "Reading clusters" << endl;

	IntegerVecMap clusters;	
	ReadClusterMembership(clustersFilename, clusters);
	
	DoubleMap clusterWeights;
	for (IntegerVecMapConstIter clusterIter = clusters.begin(); clusterIter != clusters.end(); clusterIter++)
	{
		clusterWeights[clusterIter->first] = 1.0;
	}
	
	cout << "Calculating set cover solution" << endl;

	IntegerSet solution;
	SetCover(clusters, clusterWeights, solution);
	
	cout << "Writing out clusters" << endl;

	WriteClusters(clustersFilename, outClustersFilename, solution);
}

