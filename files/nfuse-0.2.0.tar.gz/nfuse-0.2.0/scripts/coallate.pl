#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use List::Util qw[min max];

use lib dirname($0);
use configdata;
use cmdrunner;

my @usage;
push @usage, "Usage: ".basename($0)." [options]\n";
push @usage, "Collate fusions into tabular outputs\n";
push @usage, "  -h, --help      Displays this information\n";
push @usage, "  -c, --config    Configuration Filename\n";
push @usage, "  -o, --output    Output Directory\n";
push @usage, "  -n, --name      Library Name\n";
push @usage, "  -f, --fusions   Fusion Transcript Predictions\n";
push @usage, "  -p, --paths     Path Predictions\n";
push @usage, "  -y, --ycles     Cycle Predictions\n";

my $help;
my $config_filename;
my $output_directory;
my $library_name;
my $rna_results_filename;
my $dna_path_results_filename;
my $dna_cycle_results_filename;

GetOptions
(
	'help'        => \$help,
	'config=s'    => \$config_filename,
	'output=s'    => \$output_directory,
	'name=s'      => \$library_name,
	'fusions=s'   => \$rna_results_filename,
	'paths=s'     => \$dna_path_results_filename,
	'ycles=s'     => \$dna_cycle_results_filename,
);

not defined $help or die @usage and exit;

defined $config_filename or die @usage;
defined $output_directory or die @usage;
defined $library_name or die @usage;

my $config = configdata->new();
$config->read($config_filename);

# Config values
my $percent_identity_threshold	= $config->get_value("percent_identity_threshold");
my $rna_min_spanning_reads		= $config->get_value("rna_min_spanning_reads");
my $rna_min_split_reads			= $config->get_value("rna_min_split_reads");
my $mt_chromosome				= $config->get_value("mt_chromosome");

my $log_directory = $output_directory."/log";
my $log_prefix = $log_directory."/coallate";

mkdir $log_directory if not -e $log_directory;

my $runner = cmdrunner->new();
$runner->name("coallate");
$runner->prefix($log_prefix);

my %dna_cycles;
my $dna_cycles_filename = $output_directory."/dna.cycles";
read_cycles($dna_cycles_filename, \%dna_cycles);

my %dna_paths;
my $dna_paths_filename = $output_directory."/dna.paths";
read_paths($dna_paths_filename, \%dna_paths);

my %dna_annotations;
my %rna_annotations;
my $dna_annotations_filename = $output_directory."/dna.annotations";
my $rna_annotations_filename = $output_directory."/rna.annotations";
read_annotations($dna_annotations_filename, \%dna_annotations);
read_annotations($rna_annotations_filename, \%rna_annotations);

filter_dna_breakpoints(\%dna_annotations);

calculate_lengths(\%dna_annotations, $dna_paths{paths}, "path");
calculate_lengths(\%dna_annotations, $dna_cycles{cycles}, "cycle");

foreach my $rna_cluster_id (keys %{$dna_paths{rna_clusters}})
{
	next unless defined $rna_annotations{$rna_cluster_id};
	
	my $path_id = $dna_paths{rna_clusters}{$rna_cluster_id}{path};
	my $path_score = $dna_paths{paths}{$path_id}{score};
	
	$rna_annotations{$rna_cluster_id}{path_id} = $path_id;
	$rna_annotations{$rna_cluster_id}{path_score} = $path_score;
}

open OUT, ">".$rna_results_filename or die "Error: Unable to open $rna_results_filename: $!\n";
print_cluster_table(\*OUT, \%rna_annotations);
close OUT;

open OUT, ">".$dna_path_results_filename or die "Error: Unable to open $dna_path_results_filename: $!\n";
print_path_clusters(\*OUT, \%dna_annotations, $dna_paths{paths}, "path");
close OUT;

open OUT, ">".$dna_cycle_results_filename or die "Error: Unable to open $dna_cycle_results_filename: $!\n";
print_path_clusters(\*OUT, \%dna_annotations, $dna_cycles{cycles}, "cycle");
close OUT;

sub filter_dna_breakpoints
{
	my $dna_anno_ref = shift;
	
	foreach my $cluster_id (keys %{$dna_anno_ref})
	{
		if ($dna_anno_ref->{$cluster_id}{genome_breakseqs_percident} > 0.85)
		{
			delete $dna_anno_ref->{$cluster_id};
			next;
		}
		
		if ($dna_anno_ref->{$cluster_id}{chromosome1} eq $mt_chromosome)
		{
			delete $dna_anno_ref->{$cluster_id};
			next;
		}
		
		if ($dna_anno_ref->{$cluster_id}{repeat_proportion1} == 1 and $dna_anno_ref->{$cluster_id}{repeat_proportion2} == 1 and $dna_anno_ref->{$cluster_id}{repeat_list1} eq $dna_anno_ref->{$cluster_id}{repeat_list2})
		{
			delete $dna_anno_ref->{$cluster_id};
			next;
		}
	}
}

sub calculate_lengths
{
	my $annotations_ref = shift;
	my $paths_ref = shift;
	my $path_type = shift;
	
	foreach my $path_id (keys %{$paths_ref})
	{
		my @path = @{$paths_ref->{$path_id}{$path_type}};
		
		my $start_index = ($path_type eq "path") ? 1 : 0;
		
		my $path_length = 0;
		foreach my $path_node ($start_index..$#path)
		{
			my $cluster_id1 = $path[$path_node-1][0];
			my $cluster_end1 = $path[$path_node-1][1];
			
			my $cluster_id2 = $path[$path_node][0];
			my $cluster_end2 = $path[$path_node][1];

			next if $cluster_id1 == $cluster_id2;
			
			next if not defined $annotations_ref->{$cluster_id1} or not defined $annotations_ref->{$cluster_id2};
			
			my $anno_name1 = "genomic_break_pos".($cluster_end1+1);
			my $anno_name2 = "genomic_break_pos".($cluster_end2+1);
			
			$path_length += abs($annotations_ref->{$cluster_id1}{$anno_name1} - $annotations_ref->{$cluster_id2}{$anno_name2});
		}
		
		$paths_ref->{$path_id}{length} = $path_length;
	}
}

sub print_cluster_table
{
	my $file_ref = shift;
	my $annotations_ref = shift;
		
	my %annotations;
	foreach my $cluster_id (keys %{$annotations_ref})
	{
		foreach my $anno_type (keys %{$annotations_ref->{$cluster_id}})
		{
			$annotations{$anno_type} = 1;
		}
	}
	
	my @annotations_order = sort { $a cmp $b } keys %annotations;
	
	print $file_ref "cluster_id\t";
	foreach my $anno_type (@annotations_order)
	{
		print $file_ref $anno_type."\t";
	}
	print $file_ref "\n";
	
	foreach my $cluster_id (keys %{$annotations_ref})
	{
		print $file_ref $cluster_id."\t";
		foreach my $anno_type (@annotations_order)
		{
			if (defined $annotations_ref->{$cluster_id}{$anno_type})
			{
				print $file_ref $annotations_ref->{$cluster_id}{$anno_type}."\t";
			}
			else
			{
				print $file_ref "-\t";
			}
		}
		print $file_ref "\n";	
	}
}

sub print_path_clusters
{
	my $file_ref = shift;
	my $annotations_ref = shift;
	my $paths_ref = shift;
	my $path_type = shift;
	
	my %annotations;
	foreach my $cluster_id (keys %{$annotations_ref})
	{
		foreach my $anno_type (keys %{$annotations_ref->{$cluster_id}})
		{
			$annotations{$anno_type} = 1;
		}
	}
	
	my @annotations_order = sort { $a cmp $b } keys %annotations;
	
	print $file_ref $path_type."_id\t";
	print $file_ref $path_type."_score\t";
	print $file_ref $path_type."_length\t";
	print $file_ref "cluster_id\t";
	foreach my $anno_type (@annotations_order)
	{
		print $file_ref $anno_type."\t";
	}
	print $file_ref "\n";
	
	foreach my $path_id (sort {$paths_ref->{$a}{score} <=> $paths_ref->{$b}{score}} keys %{$paths_ref})
	{
		my $path_score = $paths_ref->{$path_id}{score};
		my $path_length = $paths_ref->{$path_id}{length};
		my @path = @{$paths_ref->{$path_id}{$path_type}};
		
		my %unique_cluster_ids;
		my $filtered = 0;
		foreach my $path_order (0..scalar(@path)/2-1)
		{
			my $cluster_id = $path[$path_order*2][0];
			$filtered = 1 if not defined $annotations_ref->{$cluster_id};
			$unique_cluster_ids{$cluster_id} = 1;
		}
		
		next if $filtered;
		next if scalar keys %unique_cluster_ids < 0.5 * scalar @path;
		
		foreach my $path_order (0..scalar(@path)/2-1)
		{
			my $cluster_id = $path[$path_order*2][0];
			
			print $file_ref $path_id."\t";
			print $file_ref $path_score."\t";
			print $file_ref $path_length."\t";
			print $file_ref $cluster_id."\t";
			foreach my $anno_type (@annotations_order)
			{
				if (defined $annotations_ref->{$cluster_id}{$anno_type})
				{
					print $file_ref $annotations_ref->{$cluster_id}{$anno_type}."\t";
				}
				else
				{
					print $file_ref "-\t";
				}
			}
			print $file_ref "\n";	
		}
	}
}

sub read_cluster_ids
{
	my $clusters_filename = shift;
	my $gene_clusters_ref = shift;

	open CLU, $clusters_filename or die "Error: Unable to open $clusters_filename: $!\n";
	while (<CLU>)
	{
		chomp;
		my @fields = split /\t/;
		
		my $cluster_id = $fields[0];
		$gene_clusters_ref->{$cluster_id} = 1;
	}
	close CLU;
}

sub create_key
{
	my $key = "";
	foreach my $node (@_)
	{
		$key .= $node->[0].",".$node->[1]." ";
	}
	return $key;
}

sub rotate
{
	my $rotation = shift;
	my @nodes = @_;
	foreach (1..$rotation)
	{
		push @nodes, shift @nodes;
		push @nodes, shift @nodes;
	}
	return @nodes;
}

sub read_cycles
{
	my $cycles_filename = shift;
	my $cycles_ref = shift;
	
	my %scores;
	my %start_dna_cluster_ids;
	my %cycles;
	
	open CY, $cycles_filename or die "Error: Unable to open $cycles_filename: $!\n";
	while (<CY>)
	{
		chomp;
		my @fields = split /\t/;
		
		my $score = shift @fields;
		
		my $start_dna_cluster_id = $fields[0];
		
		my @cycle;
		while (scalar @fields > 0)
		{
			my $dna_cluster_id = shift @fields;
			my $dna_cluster_end = shift @fields;
			
			push @cycle, [$dna_cluster_id,$dna_cluster_end];
		}
		
		my @cycle_keys;
		foreach my $rotation (0..$#cycle)
		{
			push @cycle_keys, create_key(rotate($rotation, @cycle));
			push @cycle_keys, create_key(reverse(rotate($rotation, @cycle)));
		}
		
		my $cycle_key = (sort(@cycle_keys))[0];
		
		$scores{$cycle_key} = $score if not defined $scores{$cycle_key};
		$scores{$cycle_key} = min($scores{$cycle_key},$score);
		push @{$start_dna_cluster_ids{$cycle_key}}, $start_dna_cluster_id;
		$cycles{$cycle_key} = [@cycle];
	}
	close CY;
	
	my @cycle_keys = keys %scores;
	foreach my $cycle_index (0..$#cycle_keys)
	{
		my $cycle_key = $cycle_keys[$cycle_index];
		
		$cycles_ref->{cycles}{$cycle_index}{score} = $scores{$cycle_key};
		$cycles_ref->{cycles}{$cycle_index}{cycle} = $cycles{$cycle_key};
		
		foreach my $start_dna_cluster_id (@{$start_dna_cluster_ids{$cycle_key}})
		{
			$cycles_ref->{start_dna_clusters}{$start_dna_cluster_id}{cycle} = $cycle_index;
		}
	}
}

sub read_paths
{
	my $paths_filename = shift;
	my $paths_ref = shift;
	
	my %scores;
	my %rna_cluster_ids;
	my %paths;
	
	open PA, $paths_filename or die "Error: Unable to open $paths_filename: $!\n";
	while (<PA>)
	{
		chomp;
		my @fields = split /\t/;
		
		my $score = shift @fields;
		
		my $rna_cluster_id = shift @fields;
		
		my @path;
		while (scalar @fields > 0)
		{
			my $dna_cluster_id = shift @fields;
			my $dna_cluster_end = shift @fields;
			
			push @path, [$dna_cluster_id,$dna_cluster_end];
		}
		
		my $path_key = (sort(create_key(@path), create_key(reverse(@path))))[0];
		
		$scores{$path_key} = $score if not defined $scores{$path_key};
		$scores{$path_key} = min($scores{$path_key},$score);
		push @{$rna_cluster_ids{$path_key}}, $rna_cluster_id;
		$paths{$path_key} = [@path];
	}
	close PA;
	
	my @path_keys = keys %scores;
	foreach my $path_index (0..$#path_keys)
	{
		my $path_key = $path_keys[$path_index];
		
		$paths_ref->{paths}{$path_index}{score} = $scores{$path_key};
		$paths_ref->{paths}{$path_index}{path} = $paths{$path_key};
		
		foreach my $rna_cluster_id (@{$rna_cluster_ids{$path_key}})
		{
			$paths_ref->{rna_clusters}{$rna_cluster_id}{path} = $path_index;
		}
	}
}

sub read_clusters_seq
{
	my $clusters_filename = shift;
	my $clusters_hash_ref = shift;
	
	open CLU, $clusters_filename or die "Error: Unable to find $clusters_filename: $!\n";
	while (<CLU>)
	{
		chomp;
		my @fields = split /\t/;
		
		my $cluster_id = $fields[0];
		my $seq = $fields[1];
		my $count = $fields[2];

		$clusters_hash_ref->{$cluster_id}{sequence} = $seq;
		$clusters_hash_ref->{$cluster_id}{span_count} = $seq;
	}
	close CLU;
}

sub read_annotations
{
	my $annotations_filename = shift;
	my $annotations_hash_ref = shift;
	
	open ANO, $annotations_filename or die "Error: Unable to find $annotations_filename: $!\n";
	while (<ANO>)
	{
		chomp;
		my @fields = split /\t/;
		
		my $cluster_id = $fields[0];
		my $anno_type = $fields[1];
		my $anno_value = $fields[2];
		
		$annotations_hash_ref->{$cluster_id}{$anno_type} = $anno_value;
	}
	close ANO;
}

sub read_splitr_seq
{
	my $seqs_filename = shift;
	my $seqs_hash_ref = shift;
	
	open SEQ, $seqs_filename or die "Error: Unable to find $seqs_filename: $!\n";
	while (<SEQ>)
	{
		chomp;
		my @fields = split /\t/;
		
		my $cluster_id = $fields[0];
		
		$seqs_hash_ref->{$cluster_id}{sequence} = $fields[1];
		$seqs_hash_ref->{$cluster_id}{split_count} = $fields[3];
	}
	close SEQ;
}

sub read_span_pval
{
	my $span_pval_filename = shift;
	my $span_pval_hash_ref = shift;
	
	open SPP, $span_pval_filename or die "Error: Unable to find $span_pval_filename: $!\n";
	while (<SPP>)
	{
		chomp;
		my @fields = split /\t/;
		
		my $cluster_id = $fields[0];
		
		$span_pval_hash_ref->{$cluster_id}{span_pvalue} = $fields[1];
	}
	close SPP;
}

sub read_split_pval
{
	my $split_pval_filename = shift;
	my $split_pval_hash_ref = shift;
	
	open SPP, $split_pval_filename or die "Error: Unable to find $split_pval_filename: $!\n";
	while (<SPP>)
	{
		chomp;
		my @fields = split /\t/;
		
		my $cluster_id = $fields[0];
		
		$split_pval_hash_ref->{$cluster_id}{split_pos_pvalue} = $fields[1];
		$split_pval_hash_ref->{$cluster_id}{split_min_pvalue} = $fields[2];
	}
	close SPP;
}

sub read_readthroughs
{
	my $readthroughs_filename = shift;
	my $readthroughs_ref = shift;

	open RT, $readthroughs_filename or die "Error: Unable to open $readthroughs_filename: $!\n";
	while (<RT>)
	{
		chomp;

		$readthroughs_ref->{$_} = 1;
	}
	close RT;
}

