#!/usr/bin/perl

use strict;
use warnings;

my $reads_fastq_1 = shift;
my $reads_fastq_2 = shift;
my $concordant_sam = shift;

defined $reads_fastq_2 or die "Usage: $0 reads_fastq_1 reads_fastq_2 concordant_sam\n";

my %concordant;
if (defined $concordant_sam)
{
	open CONC, $concordant_sam or die "Error: Unable to open $concordant_sam, $!\n";
	while (<CONC>)
	{
		chomp;
		next if /^@/;
		
		my @fields = split /\t/;
		
		my $fragment_index = $fields[0];
		my $flag = $fields[1];
		
		if ($flag & hex('0x0002'))
		{
			$concordant{$fragment_index} = 1;
		}
	}
	close CONC;
}

open FQ1, $reads_fastq_1 or die "Error: Unable to write to $reads_fastq_1: $!\n";
open FQ2, $reads_fastq_2 or die "Error: Unable to write to $reads_fastq_2: $!\n";
while(1)
{
	my $readid1 = <FQ1>;
	my $sequence1 = <FQ1>;
	my $comment1 = <FQ1>;
	my $quality1 = <FQ1>;

	last if not defined $quality1;

	my $readid2 = <FQ2>;
	my $sequence2 = <FQ2>;
	my $comment2 = <FQ2>;
	my $quality2 = <FQ2>;

	last if not defined $quality2;
	
	$readid1 =~ /^@(\d+)\/([12])/;
	my $fragment_index1 = $1;
	
	$readid2 =~ /^@(\d+)\/([12])/;
	my $fragment_index2 = $1;
	
	$fragment_index1 == $fragment_index2 or die "Error: Unmatched reads $readid1 and $readid2\n";
	
	next if defined $concordant{$fragment_index1};
	
	print $readid1;
	print $sequence1;
	print $comment1;
	print $quality1;
	
	print $readid2;
	print $sequence2;
	print $comment2;
	print $quality2;
}
close FQ1;
close FQ2;


