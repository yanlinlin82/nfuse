#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use List::Util qw[min max];

use lib dirname($0);
use gene_models;

my $gene_models_filename = shift;
my $clusters_filename = shift;
my $max_intron = shift;

defined $max_intron or die "Usage: $0 gene_models_filename clusters max_intron\n";

my $gene_models = gene_models->new($gene_models_filename);

sub is_readthrough
{
	my $cluster_ref = shift;

	my $ref_name1 = $cluster_ref->{0}{ref_name};
	my $ref_name2 = $cluster_ref->{1}{ref_name};

	my $strand1 = $cluster_ref->{0}{strand};
	my $strand2 = $cluster_ref->{1}{strand};

	my $pos1 = ($cluster_ref->{"0"}{start} + $cluster_ref->{"0"}{end}) / 2;
	my $pos2 = ($cluster_ref->{"1"}{start} + $cluster_ref->{"1"}{end}) / 2;

	my $chromosome1 = $gene_models->calc_genomic_chromosome($ref_name1);
	my $chromosome2 = $gene_models->calc_genomic_chromosome($ref_name2);

	my $genomic_strand1 = $gene_models->calc_genomic_strand($ref_name1, $strand1);
	my $genomic_strand2 = $gene_models->calc_genomic_strand($ref_name2, $strand2);

	my $genomic_pos1 = $gene_models->calc_genomic_position($cluster_ref->{"0"}{ref_name}, $pos1);
	my $genomic_pos2 = $gene_models->calc_genomic_position($cluster_ref->{"1"}{ref_name}, $pos2);

	my $distance12 = $genomic_pos2 - $genomic_pos1;
	my $distance21 = $genomic_pos1 - $genomic_pos2;

	return 0 if $chromosome1 ne $chromosome2;

	return 1 if $genomic_strand1 eq "+" and $genomic_strand2 eq "-" and $distance12 > 0 and $distance12 <= $max_intron;
	return 1 if $genomic_strand2 eq "+" and $genomic_strand1 eq "-" and $distance21 > 0 and $distance21 <= $max_intron;

	return 0;
}

my %fragment_maxclustersize;

my $current_id;
my %cluster;
my %cluster_fragments;
open CL, $clusters_filename or die;
while (<CL>)
{
	my $line = $_;
	
	chomp;
	my @fields = split /\t/;
	
	my $cluster_id = $fields[0];
	my $cluster_end = $fields[1];
	my $fragment_id = $fields[2];
	my $read_end = $fields[3];
	my $ref_name = $fields[4];
	my $strand = $fields[5];
	my $start = $fields[6];
	my $end = $fields[7];
	
	if (defined $current_id and $current_id != $cluster_id)
	{
		die "Error: Unmatched cluster $current_id\n" if not defined $cluster{"0"} or not defined $cluster{"1"};
		
		if (is_readthrough(\%cluster))
		{
			foreach my $cluster_fragment_id (keys %cluster_fragments)
			{
				$fragment_maxclustersize{$cluster_fragment_id} = 0 if not defined $fragment_maxclustersize{$cluster_fragment_id};
				$fragment_maxclustersize{$cluster_fragment_id} = max($fragment_maxclustersize{$cluster_fragment_id}, scalar keys %cluster_fragments);
			}
		}
		
		%cluster = ();
		%cluster_fragments = ();
	}
	
	my $chromosome = $gene_models->calc_genomic_chromosome($ref_name);
	
	$current_id = $cluster_id;
	$cluster{$cluster_end}{ref_name} = $ref_name;
	$cluster{$cluster_end}{strand} = $strand;
	
	$cluster{$cluster_end}{start} = $start if not defined $cluster{$cluster_end}{start};
	$cluster{$cluster_end}{end} = $end if not defined $cluster{$cluster_end}{end};
	
	$cluster{$cluster_end}{start} = min($cluster{$cluster_end}{start}, $start);
	$cluster{$cluster_end}{end} = max($cluster{$cluster_end}{end}, $end);
	
	$cluster_fragments{$fragment_id} = 1;
}
close CL;

if (defined $current_id)
{
	die "Error: Unmatched cluster $current_id\n" if not defined $cluster{"0"} or not defined $cluster{"1"};
	
	if (is_readthrough(\%cluster))
	{
		foreach my $cluster_fragment_id (keys %cluster_fragments)
		{
			$fragment_maxclustersize{$cluster_fragment_id} = 0 if not defined $fragment_maxclustersize{$cluster_fragment_id};
			$fragment_maxclustersize{$cluster_fragment_id} = max($fragment_maxclustersize{$cluster_fragment_id}, scalar keys %cluster_fragments);
		}
	}
}

$current_id = undef;
%cluster_fragments = ();
my @lines;
open CL, $clusters_filename or die;
while (<CL>)
{
	my $line = $_;
	
	chomp;
	my @fields = split /\t/;
	
	my $cluster_id = $fields[0];
	my $cluster_end = $fields[1];
	my $fragment_id = $fields[2];
	my $read_end = $fields[3];
	my $ref_name = $fields[4];
	my $strand = $fields[5];
	my $start = $fields[6];
	my $end = $fields[7];
	
	if (defined $current_id and $current_id != $cluster_id)
	{
		die "Error: Unmatched cluster $current_id\n" if not defined $cluster{"0"} or not defined $cluster{"1"};
		
		my $allreadthroughreads = 1;
		my $minmaxclustersize;
		foreach my $cluster_fragment_id (keys %cluster_fragments)
		{
			if (not defined $fragment_maxclustersize{$cluster_fragment_id})
			{
				$allreadthroughreads = 0;
				last;
			}
			else
			{
				$minmaxclustersize = $fragment_maxclustersize{$cluster_fragment_id} if not defined $minmaxclustersize;
				$minmaxclustersize = min($minmaxclustersize, $fragment_maxclustersize{$cluster_fragment_id});
			}
		}
		
		my $filtered = 0;
		if ($allreadthroughreads and $minmaxclustersize >= scalar keys %cluster_fragments)
		{
			$filtered = 1;
		}
		
		if (not $filtered)
		{
			foreach my $line (@lines)
			{
				print $line;
			}
		}
		
		%cluster_fragments = ();
		@lines = ();
	}
	
	$current_id = $cluster_id;
	$cluster_fragments{$fragment_id} = 1;
	push @lines, $line;
}

if (defined $current_id)
{
	die "Error: Unmatched cluster $current_id\n" if not defined $cluster{"0"} or not defined $cluster{"1"};
	
	my $allreadthroughreads = 1;
	my $minmaxclustersize;
	foreach my $cluster_fragment_id (keys %cluster_fragments)
	{
		if (not defined $fragment_maxclustersize{$cluster_fragment_id})
		{
			$allreadthroughreads = 0;
			last;
		}
		else
		{
			$minmaxclustersize = $fragment_maxclustersize{$cluster_fragment_id} if not defined $minmaxclustersize;
			$minmaxclustersize = min($minmaxclustersize, $fragment_maxclustersize{$cluster_fragment_id});
		}
	}
	
	my $filtered = 0;
	if ($allreadthroughreads and $minmaxclustersize >= scalar keys %cluster_fragments)
	{
		$filtered = 1;
	}
	
	if (not $filtered)
	{
		foreach my $line (@lines)
		{
			print $line;
		}
	}
}

