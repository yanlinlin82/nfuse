#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use List::Util qw[min max];

my $repeats_filename = shift;
my $repeat_type = shift;
my $overlap_percent = shift;
my $num_sides = shift;

die "Usage: $0 repeats_filename repeat_type overlap_percent num_sides < in > out\n" if not defined $num_sides;

# Read in regions
my @repeats;
my $length_sum = 0;
open REP, $repeats_filename or die "Error: Unable to open $repeats_filename: $!\n";
while (<REP>)
{
	chomp;
	my ($chromosome,$start,$end,$type) = split /\t/;
	
	next if defined $repeat_type and $type ne $repeat_type;
	
	push @repeats, [$chromosome,$start,$end,$type];
	$length_sum += $end - $start;
}
close REP;
my $length_mean = $length_sum / scalar @repeats;

# Bin spacing so that most repeats are contained in only a few bins
my $bin_spacing = $length_mean * 5;

# Binning for gene lookup
my %binned_repeats;
foreach my $repeat (@repeats)
{
	foreach my $bin (get_bins($repeat->[1],$repeat->[2]))
	{
		push @{$binned_repeats{$repeat->[0]}{$bin}}, [$repeat->[1],$repeat->[2],$repeat->[3]];
	}
}

# Classify as repeat cluster
sub is_repeat_cluster
{
	my $cluster_ref = shift;
	
	my %contained;
	
	foreach my $cluster_end (keys %{$cluster_ref})
	{
		my $ref_name = $cluster_ref->{$cluster_end}{ref_name};
		my $start = $cluster_ref->{$cluster_end}{start};
		my $end = $cluster_ref->{$cluster_end}{end};
		
		foreach my $bin (get_bins($start,$end))
		{
			foreach my $repeat (@{$binned_repeats{$ref_name}{$bin}})
			{
				if (overlap($repeat,[$start,$end]) > $overlap_percent)
				{
					$contained{$cluster_end} = 1;
				}
			}
		}
	}
	
	if (keys %contained >= $num_sides)
	{
		return 1;
	}
	
	return 0;
}

my @current_cluster_lines;
my $current_cluster_id;
my %current_cluster;
while (<>)
{
	my $line = $_;
	
	chomp;
	my @fields = split /\t/;
	
	my $cluster_id = $fields[0];
	my $cluster_end = $fields[1];
	my $fragment_id = $fields[2];
	my $read_end = $fields[3];
	my $ref_name = $fields[4];
	my $strand = $fields[5];
	my $start = $fields[6];
	my $end = $fields[7];
	
	if (defined $current_cluster_id and $current_cluster_id != $cluster_id)
	{
		if (not is_repeat_cluster(\%current_cluster))
		{
			print @current_cluster_lines;
		}
		
		@current_cluster_lines = ();
		%current_cluster = ();
	}
	
	$current_cluster_id = $cluster_id;
	
	$current_cluster{$cluster_end}{ref_name} = $ref_name;
	$current_cluster{$cluster_end}{strand} = $strand;
	
	$current_cluster{$cluster_end}{start} = $start if not defined $current_cluster{$cluster_end}{start};
	$current_cluster{$cluster_end}{end} = $end if not defined $current_cluster{$cluster_end}{end};

	$current_cluster{$cluster_end}{start} = min($start, $current_cluster{$cluster_end}{start});
	$current_cluster{$cluster_end}{end} = max($end, $current_cluster{$cluster_end}{end});
	
	push @current_cluster_lines, $line;
}

if (defined $current_cluster_id)
{
	if (not is_repeat_cluster(\%current_cluster))
	{
		print @current_cluster_lines;
	}
}

# Calculate bins overlapped by a region
sub get_bins
{
	my $start = shift;
	my $end = shift;
	
	my $start_bin = int($start / $bin_spacing);
	my $end_bin = int($end / $bin_spacing);
	
	return ($start_bin .. $end_bin);
}

# Check for overlap between regions
sub overlap
{
	my $region1 = $_[0];
	my $region2 = $_[1];
	
	my $overlap_start = max($region1->[0],$region2->[0]);
	my $overlap_end = min($region1->[1],$region2->[1]);
	
	if ($overlap_start > $overlap_end)
	{
		return 0;
	}
	else
	{
		return ($overlap_end - $overlap_start) / ($region2->[1] - $region2->[0]);
	}
}

# Check for overlap between regions
sub contains
{
	my $region1 = $_[0];
	my $region2 = $_[1];
	
	if ($region2->[0] >= $region1->[0] and $region2->[1] <= $region1->[1])
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
