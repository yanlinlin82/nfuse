#!/usr/bin/perl

use strict;
use warnings;

while (<>)
{
	next if /^@/;
	
	chomp;
	my @sam_fields = split /\t/;
	my @pos_fields = split /_/, $sam_fields[0];
	
	if ($pos_fields[1] eq $sam_fields[2] and $sam_fields[3] >= $pos_fields[3] and $sam_fields[3] <= $pos_fields[4])
	{
		next;
	}
	
	print $_."\n";
}

