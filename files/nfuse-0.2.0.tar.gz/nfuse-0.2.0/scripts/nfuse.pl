#!/usr/bin/perl

use strict;
use warnings FATAL => 'all';
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use Cwd qw[abs_path];
use File::Spec;

use lib dirname($0);
use configdata;
use cmdrunner;

my @usage;
push @usage, "Usage: ".basename($0)." [options]\n";
push @usage, "Run the analysis pipeline for fusions.\n";
push @usage, "  -h, --help      Displays this information\n";
push @usage, "  -c, --config    Configuration Filename\n";
push @usage, "  --dnadir        DNA source directory (mutually exclusive of dnafq1, dnafq2)\n";
push @usage, "  --dnafq1        DNA fastq end 1 (mutually exclusive of dnadir)\n";
push @usage, "  --dnafq2        DNA fastq end 2 (mutually exclusive of dnadir)\n";
push @usage, "  --rnadir        RNA source directory (mutually exclusive of rnafq1, rnafq2)\n";
push @usage, "  --rnafq1        RNA fastq end 1 (mutually exclusive of rnadir)\n";
push @usage, "  --rnafq2        RNA fastq end 2 (mutually exclusive of rnadir)\n";
push @usage, "  -o, --output    Output Directory\n";
push @usage, "  -n, --name      Library Name\n";
push @usage, "  -l, --local     Job Local Directory (default: Output Directory)\n";
push @usage, "  -s, --submit    Submitter Type (default: direct)\n";
push @usage, "  -p, --parallel  Maximum Number of Parallel Jobs (default: 1)\n";

my $help;
my $config_filename;
my $dna_source_directory;
my $dna_fastq_1;
my $dna_fastq_2;
my $rna_source_directory;
my $rna_fastq_1;
my $rna_fastq_2;
my $output_directory;
my $library_name;
my $joblocal_directory;
my $submitter_type;
my $max_parallel;

GetOptions
(
	'help'        => \$help,
	'config=s'    => \$config_filename,
	'dnadir=s'    => \$dna_source_directory,
	'dnafq1=s'    => \$dna_fastq_1,
	'dnafq2=s'    => \$dna_fastq_2,
	'rnadir=s'    => \$rna_source_directory,
	'rnafq1=s'    => \$rna_fastq_1,
	'rnafq2=s'    => \$rna_fastq_2,
	'output=s'    => \$output_directory,
	'name=s'      => \$library_name,
	'local=s'     => \$joblocal_directory,
	'submit=s'    => \$submitter_type,
	'parallel=s'  => \$max_parallel,
);

not defined $help or die "@usage";

defined $config_filename or die @usage;
defined $output_directory or die @usage;

mkdir $output_directory if not -d $output_directory;

-d $output_directory or die "Error: unable to make output directory $output_directory\n";
-e $config_filename or die "Error: unable to find config file $config_filename\n";

$output_directory = abs_path($output_directory);
$config_filename = abs_path($config_filename);

# Guess library name
if (not defined $library_name)
{
	$library_name = "";
	my @output_splitdir = File::Spec->splitdir($output_directory);
	while ($library_name eq "" and scalar @output_splitdir > 0)
	{
		$library_name = pop(@output_splitdir);
	}
	defined $library_name or die "Error: Unable to infer library name from output director $output_directory\n";
}

# Job local directory defaults to temp subdirectory of output directory
if (not defined $joblocal_directory)
{
	$joblocal_directory = $output_directory."/tmp";
	mkdir $joblocal_directory if not -d $joblocal_directory;
}

# Submitter type defaults to direct
if (not defined $submitter_type)
{
	$submitter_type = "direct";
}

# Max parallel defaults to 1 for direct submitter
if (not defined $max_parallel)
{
	if ($submitter_type eq "direct")
	{
		$max_parallel = 1;
	}
	else
	{
		$max_parallel = 200;
	}
}

my $config = configdata->new();
$config->read($config_filename);

# Config values
my $gene_models              = $config->get_value("gene_models");
my $genome_fasta             = $config->get_value("genome_fasta");
my $genome_cdna_fasta        = $config->get_value("genome_cdna_fasta");
my $scripts_directory        = $config->get_value("scripts_directory");
my $tools_directory          = $config->get_value("tools_directory");
my $samtools_bin             = $config->get_value("samtools_bin");
my $reads_per_job            = $config->get_value("reads_per_job");
my $rna_min_spanning_reads   = $config->get_value("rna_min_spanning_reads");
my $dna_min_spanning_reads   = $config->get_value("dna_min_spanning_reads");
my $max_intron_length        = $config->get_value("max_intron_length");
my %assemblies               = $config->get_hash("assemblies");
my $mt_chromosome            = $config->get_value("mt_chromosome");
my $dna_concordant_length    = $config->get_value("dna_concordant_length");
my $rna_concordant_length    = $config->get_value("rna_concordant_length");
my $dna_max_fragment_length  = $config->get_value("dna_max_fragment_length");
my $match_score              = $config->get_value("match_score");
my $mismatch_score           = $config->get_value("mismatch_score");
my $gap_score                = $config->get_value("gap_score");
my $matealign_search_length  = $config->get_value("matealign_search_length");
my $num_sample_reads         = $config->get_value("num_sample_reads");
my $null_connect_samples     = $config->get_value("null_connect_samples");
my $breakpoints_per_job      = $config->get_value("breakpoints_per_job");
my $cdna_fasta               = $config->get_value("cdna_fasta");
my $cdna_regions             = $config->get_value("cdna_regions");
my $cdna_chromosomes         = $config->get_value("cdna_chromosomes");
my $exons_fasta              = $config->get_value("exons_fasta");
my $cds_fasta                = $config->get_value("cds_fasta");
my $est_fasta                = $config->get_value("est_fasta");
my @est_split_fastas         = $config->get_list("est_split_fasta");
my $repeats_regions          = $config->get_value("repeats_regions");
my $blat_bin                 = $config->get_value("blat_bin");
my $rscript_bin              = $config->get_value("rscript_bin");
my $rna_seed_length          = $config->get_value("rna_seed_length");
my $remove_job_files         = $config->get_value("remove_job_files");
my $cluster_prob_threshold   = $config->get_value("cluster_prob_threshold");
my $cycles_lambda            = $config->get_value("cycles_lambda");
my $cycles_visitmax          = $config->get_value("cycles_visitmax");
my $paths_lambdafwd          = $config->get_value("paths_lambdafwd");
my $paths_lambdarev          = $config->get_value("paths_lambdarev");
my $paths_visitmax           = $config->get_value("paths_visitmax");
my $remap_end_adjust         = $config->get_value("remap_end_adjust");
my $gmap_bin                 = $config->get_value("gmap_bin");
my $gmap_index_directory     = $config->get_value("gmap_index_directory");
my $bowtie_bin               = $config->get_value("bowtie_bin");
my $bowtie_options           = $config->get_value("bowtie_options");
my $bowtie2_bin              = $config->get_value("bowtie2_bin");
my $bowtie2_options          = $config->get_value("bowtie2_options");
my $dna_seed_length          = $config->get_value("dna_seed_length");
my $dna_quality_offset       = $config->get_value("dna_quality_offset");
my $rna_quality_offset       = $config->get_value("rna_quality_offset");
my $dna_quality_threshold    = $config->get_value("dna_quality_threshold");
my $rna_quality_threshold    = $config->get_value("rna_quality_threshold");

sub verify_file_exists
{
	my $filename = shift;
	
	if (not -e $filename)
	{
		die "Error: Required file $filename does not exist\n";
	}
}

sub verify_directory_exists
{
	my $filename = shift;
	
	if (not -e $filename)
	{
		die "Error: Required directory $filename does not exist\n";
	}
}

# Ensure required directories and files exist
verify_directory_exists($scripts_directory);
verify_directory_exists($output_directory);

# Script and binary paths
my $retrieve_fastq_script = "$scripts_directory/retrieve_fastq.pl";
my $import_fastq_script = "$scripts_directory/import_fastq.pl";
my $alignjob_rna_script = "$scripts_directory/alignjob_rna.pl";
my $alignjob_dna_script = "$scripts_directory/alignjob_dna.pl";
my $samtools_merge_script = "$scripts_directory/samtools_merge.pl";
my $read_stats_script = "$scripts_directory/read_stats.pl";
my $merge_read_stats_script = "$scripts_directory/merge_read_stats.pl";
my $merge_cov_samples_script = "$scripts_directory/merge_cov_samples.pl";
my $merge_clusters_script = "$scripts_directory/merge_clusters.pl";
my $unify_clusters_script = "$scripts_directory/unify_clusters.pl";
my $clustermatepairs_bin = "$tools_directory/clustermatepairs";
my $segregate_mitochondrial_script = "$scripts_directory/segregate_mitochondrial.pl";
my $overlap_clusters_bin = "$tools_directory/overlapclusters";
my $identify_readthroughs_script = "$scripts_directory/identify_readthroughs.pl";
my $create_support_script = "$scripts_directory/create_support.pl";
my $presetcover_bin = "$tools_directory/presetcover";
my $setcover_dnarna_bin = "$tools_directory/setcover_dnarna";
my $connectivity_bin = "$tools_directory/connectivity";
my $decisionmetrics_bin = "$tools_directory/decisionmetrics";
my $initsplitalign_bin = "$tools_directory/initsplitalign";
my $split_candidate_reads_script = "$scripts_directory/split_candidate_reads.pl";
my $dosplitalign_bin = "$tools_directory/dosplitalign";
my $evalsplitalign_bin = "$tools_directory/evalsplitalign";
my $calc_span_stats_script = "$scripts_directory/calc_span_stats.pl";
my $coallate_script = "$scripts_directory/coallate.pl";
my $get_fusion_sequences_script = "$scripts_directory/get_fusion_sequences.pl";
my $get_fusion_sequence_script = "$scripts_directory/get_fusion_sequence.pl";
my $annotate_dna_script = "$scripts_directory/annotate_fusions_dna.pl";
my $annotate_rna_script = "$scripts_directory/annotate_fusions_rna.pl";
my $calc_break_regions_script = "$scripts_directory/calc_break_regions.pl";
my $calc_align_regions_script = "$scripts_directory/calc_align_regions.pl";
my $remap_regions_to_genome_script = "$scripts_directory/remap_regions_to_genome.pl";
my $filter_column_script = "$scripts_directory/filter_column.pl";
my $filter_corroboration_script = "$scripts_directory/filter_corroboration.pl";
my $select_fusion_clusters_script = "$scripts_directory/select_fusion_clusters.pl";
my $select_breakpoint_clusters_script = "$scripts_directory/select_breakpoint_clusters.pl";
my $filter_repeat_clusters_script = "$scripts_directory/filter_repeat_clusters.pl";
my $filter_readthrough_clusters_script = "$scripts_directory/filter_readthrough_clusters.pl";
my $localalign_bin = "$tools_directory/localalign";
my $remove_duplicates_script = "$scripts_directory/remove_duplicates.pl";
my $create_read_fasta_script = "$scripts_directory/create_read_fasta.pl";
my $make_fasta_script = "$scripts_directory/make_fasta.pl";
my $split_fasta_script = "$scripts_directory/split_fasta.pl";
my $split_fastq_script = "$scripts_directory/split_fastq.pl";
my $sample_fastq_script = "$scripts_directory/sample_fastq.pl";
my $get_align_regions_script = "$scripts_directory/get_align_regions.pl";
my $merge_depthsamples_script = "$scripts_directory/merge_depthsamples.pl";
my $evaluate_fraglength_rscript = "$rscript_bin $scripts_directory/evaluate_fraglength_mean.R";
my $evaluate_split_rscript = "$rscript_bin $scripts_directory/evaluate_split.R";
my $fit_negative_binomial_rscript = "$rscript_bin $scripts_directory/fit_negative_binomial.R";
my $calccov_bin = "$tools_directory/calccov";
my $rankalign_bin = "$tools_directory/rankalign";
my $rankclusters_bin = "$tools_directory/rankclusters";
my $filter_clusters_script = "$scripts_directory/filter_clusters.pl";
my $count_cluster_reads_script = "$scripts_directory/count_cluster_reads.pl";
my $prep_local_alignment_seqs_script = "$scripts_directory/prep_local_alignment_seqs.pl";
my $get_path_breakpoints_script = "$scripts_directory/get_path_breakpoints.pl";
my $create_corroboration_script = "$scripts_directory/create_corroboration.pl";
my $create_discordant_fastq_script = "$scripts_directory/create_discordant_fastq.pl";
my $trim_fastq_script = "$scripts_directory/trim_fastq.pl";
my $calculate_prior_concordant_script = "$scripts_directory/calculate_prior_concordant.pl";
my $cycles_bin = "$tools_directory/cycles";
my $paths_bin = "$tools_directory/paths";
my $aligntrue_bin = "$tools_directory/aligntrue";
my $alignnull_bin = "$tools_directory/alignnull";
my $calcpriorgenomic_bin = "$tools_directory/calcpriorgenomic";
my $filter_sam_mapped_script = "$scripts_directory/filter_sam_mapped.pl";
my $extract_alignment_scores_script = "$scripts_directory/extract_alignment_scores.pl";
my $span_align_prob_rscript = "$rscript_bin $scripts_directory/span_align_prob.R";
my $mate_align_prob_rscript = "$rscript_bin $scripts_directory/mate_align_prob.R";
my $calc_fragment_align_prob_script = "$scripts_directory/calc_fragment_align_prob.pl";
my $cluster_size_prob_rscript = "$rscript_bin $scripts_directory/cluster_size_prob.R";
my $connect_prob_rscript = "$rscript_bin $scripts_directory/connect_prob.R";
my $score_stats_rscript = "$rscript_bin $scripts_directory/score_stats.R";
my $qualtrimfastq_bin = "$tools_directory/qualtrimfastq";

$output_directory = abs_path($output_directory);

my $jobs_directory = abs_path($output_directory."/jobs");

mkdir $jobs_directory if not -e $jobs_directory;

my $log_directory = $output_directory."/log";
my $log_prefix = $log_directory."/analysis";

mkdir $log_directory if not -e $log_directory;

my $runner = cmdrunner->new();
$runner->name("analyze");
$runner->prefix($log_prefix);
$runner->maxparallel($max_parallel);
$runner->submitter($submitter_type);
$runner->jobmem(8000000000);

my %dna_info;
my %rna_info;

$dna_info{prefix} = $output_directory."/dna";
$rna_info{prefix} = $output_directory."/rna";
$dna_info{data_type} = "dna";
$rna_info{data_type} = "rna";
$dna_info{seed_length} = $dna_seed_length;
$rna_info{seed_length} = $rna_seed_length;
$dna_info{quality_offset} = $dna_quality_offset;
$rna_info{quality_offset} = $rna_quality_offset;
$dna_info{quality_threshold} = $dna_quality_threshold;
$rna_info{quality_threshold} = $rna_quality_threshold;

my @dna_jobs;
my @rna_jobs;

setup_fastq_filenames(\%dna_info);
setup_fastq_filenames(\%rna_info);

print "Retreiving fastq files\n";
if (defined $dna_source_directory)
{
	retrieve_fastq_padd($dna_source_directory, \%dna_info);
}
elsif (defined $dna_fastq_1 and defined $dna_fastq_2)
{
	import_fastq_padd($dna_fastq_1, $dna_fastq_2, \%dna_info);
}
if (defined $rna_source_directory)
{
	retrieve_fastq_padd($rna_source_directory, \%rna_info);
}
elsif (defined $rna_fastq_1 and defined $rna_fastq_2)
{
	import_fastq_padd($rna_fastq_1, $rna_fastq_2, \%rna_info);
}
$runner->prun();

check_fastq_files(\%dna_info);
check_fastq_files(\%rna_info);

print "Quality trimming fastq\n";
qual_trim_fastq(\%dna_info);
qual_trim_fastq(\%rna_info);
$runner->prun();

print "Splitting fastq files\n";
split_fastq_padd(\%dna_info);
split_fastq_padd(\%rna_info);
sample_fastq_padd(\%dna_info);
$runner->prun();
split_fastq_finish(\%dna_info, \@dna_jobs);
split_fastq_finish(\%rna_info, \@rna_jobs);

wgss_sample_align(\%dna_info);

wgss_align_padd(\%dna_info, \@dna_jobs);
rnaseq_align_padd(\%rna_info, \@rna_jobs);
$runner->prun();

wgss_merge_cluster(\%dna_info, \@dna_jobs);
rnaseq_merge_cluster(\%rna_info, \@rna_jobs);

print "Finding paths\n";
my $dna_paths = $output_directory."/dna.paths";
my $paths_command = "$paths_bin -y $paths_lambdafwd -z $paths_lambdarev -v $paths_visitmax -r #<1 -d #<2 -p #<3 > #>1";
mapmerge($rna_info{clusters_fusions_regions_remap}, [$dna_info{clusters},$dna_info{clusters_prob}], $dna_paths, [$paths_command], 200);

print "Finding cycles\n";
my $dna_cycles = $output_directory."/dna.cycles";
my $dna_paths_breakpoints = $output_directory."/dna.paths.breakpoints";
$runner->run("$get_path_breakpoints_script < #<1 > #>1", [$dna_paths], [$dna_paths_breakpoints]);
my $cycles_command = "$cycles_bin -y $cycles_lambda -v $cycles_visitmax -l #<1 -c #<2 -p #<3 > #>1";
mapmerge($dna_paths_breakpoints, [$dna_info{clusters},$dna_info{clusters_prob}], $dna_cycles, [$cycles_command], 200);

print "Maximum parsimony\n";
$dna_info{clusters_sc_all} = $dna_info{prefix}.".clusters.sc.all";
$rna_info{clusters_sc_all} = $rna_info{prefix}.".clusters.sc.all";
my $dna_rna_corroboration = $output_directory."/dna.rna.corroboration";
$runner->run("$create_corroboration_script #<1 #<2 #<3 > #>1", [$dna_paths,$dna_cycles,$rna_info{readthroughs}], [$dna_rna_corroboration]);
$runner->jobmem(16000000000);
$runner->run("$setcover_dnarna_bin -d #<1 -r #<2 -c #<3 -e 0.001 -a #>1 -b #>2", [$dna_info{clusters},$rna_info{clusters},$dna_rna_corroboration], [$dna_info{clusters_sc_all},$rna_info{clusters_sc_all}]);
$runner->jobmem(8000000000);

print "Selecting rna fusion clusters and supporting dna clusters\n";
my $dna_rna_corroboration_sc = $output_directory."/dna.rna.corroboration.sc";
$dna_info{clusters_sc} = $dna_info{prefix}.".clusters.sc";
$rna_info{clusters_sc} = $rna_info{prefix}.".clusters.sc";
$runner->run("$filter_corroboration_script #<1 #<2 < #<3 > #>1", [$dna_info{clusters_sc_all},$rna_info{clusters_sc_all},$dna_rna_corroboration], [$dna_rna_corroboration_sc]);
$runner->padd("$select_breakpoint_clusters_script #<1 < #<2 > #>1", [$dna_rna_corroboration_sc,$dna_info{clusters_sc_all}], [$dna_info{clusters_sc}]);
$runner->padd("$select_fusion_clusters_script $config_filename #<1 #<3 < #<2 > #>1", [$dna_rna_corroboration_sc,$rna_info{clusters_sc_all},$rna_info{readthroughs}], [$rna_info{clusters_sc}]);
$runner->prun();

rnaseq_split_alignment(\%rna_info, \@rna_jobs);

print "Create sequences for clusters\n";
$dna_info{breakpoints_seq} = $dna_info{prefix}.".breakpoints.seq";
$dna_info{breakpoints_fasta} = $dna_info{prefix}.".breakpoints.fa";
$rna_info{breakpoints_fasta} = $rna_info{prefix}.".breakpoints.fa";
$runner->run("$get_fusion_sequences_script -r $genome_fasta -c #<1 > #>1", [$dna_info{clusters_sc}], [$dna_info{breakpoints_seq}]);
$runner->padd("cut -f1,2 #<1 | $make_fasta_script > #>1", [$dna_info{breakpoints_seq}], [$dna_info{breakpoints_fasta}]);
$runner->padd("cut -f1,2 #<1 | $make_fasta_script > #>1", [$rna_info{splitreads_seq}], [$rna_info{breakpoints_fasta}]);
$runner->prun();

print "Splitting fastas\n";
$dna_info{breakpoints_split_catalog} = $dna_info{prefix}.".breakpoints.split.catalog";
$rna_info{breakpoints_split_catalog} = $rna_info{prefix}.".breakpoints.split.catalog";
$runner->run("$split_fasta_script #<1 $breakpoints_per_job $jobs_directory/dna.breakpoints > #>1", [$dna_info{breakpoints_fasta}], [$dna_info{breakpoints_split_catalog}]);
$runner->run("$split_fasta_script #<1 $breakpoints_per_job $jobs_directory/rna.breakpoints > #>1", [$rna_info{breakpoints_fasta}], [$rna_info{breakpoints_split_catalog}]);
my @dna_breakpoints_split_fastas = readsplitcatalog($dna_info{breakpoints_split_catalog});
my @rna_breakpoints_split_fastas = readsplitcatalog($rna_info{breakpoints_split_catalog});

print "Breakpoint alignments\n";
$dna_info{breakpoints_genome_psl} = $dna_info{prefix}.".breakpoints.genome.psl";
$rna_info{breakpoints_genome_psl} = $rna_info{prefix}.".breakpoints.genome.psl";
$rna_info{breakpoints_genome_nointron_psl} = $rna_info{prefix}.".breakpoints.genome.nointron.psl";
$rna_info{breakpoints_cdna_psl} = $rna_info{prefix}.".breakpoints.cdna.psl";
$rna_info{breakpoints_est_psl} = $rna_info{prefix}.".breakpoints.est.psl";
$rna_info{breakpoints_exons_psl} = $rna_info{prefix}.".breakpoints.exons.psl";
$rna_info{breakpoints_cds_psl} = $rna_info{prefix}.".breakpoints.cds.psl";

my @breakpoint_jobs;
push @breakpoint_jobs, [$dna_info{breakpoints_fasta}, $dna_info{breakpoints_genome_psl}, \@dna_breakpoints_split_fastas, "genome", "", "genome"];
push @breakpoint_jobs, [$rna_info{breakpoints_fasta}, $rna_info{breakpoints_genome_psl}, \@rna_breakpoints_split_fastas, "genome", "", "genome"];
push @breakpoint_jobs, [$rna_info{breakpoints_fasta}, $rna_info{breakpoints_genome_nointron_psl}, \@rna_breakpoints_split_fastas, "genome", "--nosplicing", "genome.nointron"];
push @breakpoint_jobs, [$rna_info{breakpoints_fasta}, $rna_info{breakpoints_cdna_psl}, \@rna_breakpoints_split_fastas, "cdna", "", "cdna"];
push @breakpoint_jobs, [$rna_info{breakpoints_fasta}, $rna_info{breakpoints_est_psl}, \@rna_breakpoints_split_fastas, "est", "", "est"];
push @breakpoint_jobs, [$rna_info{breakpoints_fasta}, $rna_info{breakpoints_exons_psl}, \@rna_breakpoints_split_fastas, "exons", "", "exons"];
push @breakpoint_jobs, [$rna_info{breakpoints_fasta}, $rna_info{breakpoints_cds_psl}, \@rna_breakpoints_split_fastas, "cds", "", "cds"];

do_breakpoint_jobs(@breakpoint_jobs);

print "Annotate results\n";
$dna_info{annotations} = $dna_info{prefix}.".annotations";
$rna_info{annotations} = $rna_info{prefix}.".annotations";
$runner->jobmem(16000000000);
$runner->padd("$annotate_dna_script -c $config_filename -o $output_directory -n $library_name > #>1", [$dna_info{clusters_sc}], [$dna_info{annotations}]);
$runner->padd("$annotate_rna_script -c $config_filename -o $output_directory -n $library_name > #>1", [$rna_info{clusters_sc}], [$rna_info{annotations}]);
$runner->prun();

print "Coallate results\n";
my $rna_results_filename = $output_directory."/rna.results.tsv";
my $dna_path_results_filename = $output_directory."/dna.path.results.tsv";
my $dna_cycle_results_filename = $output_directory."/dna.cycle.results.tsv";
$runner->run("$coallate_script -c $config_filename -o $output_directory -n $library_name -f #>1 -p #>2 -y #>3", [$dna_info{annotations},$rna_info{annotations}], [$rna_results_filename,$dna_path_results_filename,$dna_cycle_results_filename]);

sub readsplitcatalog
{
	my $split_catalog = shift;
	my @split_prefixes;

	open SC, $split_catalog or die "Error: Unable to open $split_catalog: $!\n";
	while (<SC>)
	{
		chomp;
		my @fields = split /\t/;

		push @split_prefixes, $fields[0];
	}
	close SC;

	return @split_prefixes;
}

sub do_breakpoint_jobs
{
	my @merge_jobs;
	foreach my $breakpoint_job (@_)
	{
		my @breakpoint_job_info = @{$breakpoint_job};
		
		my $fasta = shift @breakpoint_job_info;
		my $psl = shift @breakpoint_job_info;
		if (not cmdrunner::uptodate([$fasta], [$psl]))
		{
			my @split_psls = padd_do_breakpoint_alignments(@breakpoint_job_info);
			push @merge_jobs, [\@split_psls, $psl];
		}
	}
	$runner->prun();
	
	foreach my $merge_job (@merge_jobs)
	{
		$runner->padd("cat #<A > #>1", $merge_job->[0], [$merge_job->[1]]);
	}
	$runner->prun();
}

sub padd_do_breakpoint_alignments
{
	my $split_fastas_ref = shift;
	my $ref_name = shift;
	my $parameters = shift;
	my $align_name = shift;
	
	if ($ref_name eq "genome")
	{
		return padd_do_gmap_alignments_genome($split_fastas_ref, $parameters, $align_name);
	}
	elsif ($ref_name eq "est")
	{
		return padd_do_gmap_alignments_est($split_fastas_ref, $parameters, $align_name);
	}
	elsif ($ref_name eq "cds")
	{
		return padd_do_blat_alignments($split_fastas_ref, $cds_fasta, $parameters, $align_name);
	}
	elsif ($ref_name eq "exons")
	{
		return padd_do_blat_alignments($split_fastas_ref, $exons_fasta, $parameters, $align_name);
	}
	else
	{
		return padd_do_gmap_alignments($split_fastas_ref, $ref_name, $parameters, $align_name);
	}
}
	
sub padd_do_gmap_alignments
{
	my $split_fastas_ref = shift;
	my $ref_name = shift;
	my $parameters = shift;
	my $align_name = shift;
	
	my @output_psls;
	foreach my $split_fasta (@{$split_fastas_ref})
	{
		my $output_psl = $split_fasta.".".$align_name.".psl";
		$runner->padd("$gmap_bin -D $gmap_index_directory -d $ref_name -f psl $parameters #<1 > #>1", [$split_fasta], [$output_psl]);
		push @output_psls, $output_psl;
	}
	
	return @output_psls;
}

sub padd_do_blat_alignments
{
	my $split_fastas_ref = shift;
	my $reference = shift;
	my $parameters = shift;
	my $align_name = shift;
	
	my @output_psls;
	foreach my $split_fasta (@{$split_fastas_ref})
	{
		my $output_psl = $split_fasta.".".$align_name.".psl";
		$runner->padd("$blat_bin -noHead $parameters $reference.2bit #<1 #>1", [$split_fasta], [$output_psl]);
		push @output_psls, $output_psl;
	}
	
	return @output_psls;
}

sub padd_do_gmap_alignments_genome
{
	my $split_fastas_ref = shift;
	my $gmap_parameters = shift;
	my $align_name = shift;
	
	my @output_psls;
	foreach my $assembly (keys %assemblies)
	{
		push @output_psls, padd_do_gmap_alignments($split_fastas_ref, $assembly, $gmap_parameters, $align_name.".".$assembly);
	}
	
	return @output_psls;
}

sub padd_do_gmap_alignments_est
{
	my $split_fastas_ref = shift;
	my $gmap_parameters = shift;
	my $align_name = shift;
	
	my @output_psls;
	foreach my $est_split_index (0..$#est_split_fastas)
	{
		push @output_psls, padd_do_gmap_alignments($split_fastas_ref, "est".$est_split_index, $gmap_parameters, $align_name.".".$est_split_index);
	}
	
	return @output_psls;
}

sub mapmerge
{
	my $splitable_input = shift;
	my $common_inputs = shift;
	my $output = shift;
	my $commands = shift;
	my $split_size = shift;
	
	if (cmdrunner::uptodate([$splitable_input,@{$common_inputs}], [$output]))
	{
		return;
	}
	
	my @split_input_filenames;
	my $split_input_file;
	my $split_input_index = 0;
	my $split_input_lines = $split_size;
	
	open IN, $splitable_input or die "Error: Unable to open $splitable_input\n";
	while (<IN>)
	{
		if ($split_input_lines == $split_size)
		{
			if (defined $split_input_file)
			{
				close $split_input_file;
			}
			
			my $split_input_filename = $splitable_input.".".$split_input_index;
			push @split_input_filenames, $split_input_filename;
			open $split_input_file, ">".$split_input_filename or die "Error: Unable to open $split_input_filename\n";
			$split_input_index++;
			$split_input_lines = 0;
		}

		print $split_input_file $_;
		$split_input_lines++;
	}
	close IN;
	
	if (defined $split_input_file)
	{
		close $split_input_file;
	}
	
	my @split_output_filenames;
	foreach my $split_input_filename (@split_input_filenames)
	{
		foreach my $command_index (0..$#{$commands})
		{
			my $split_output_filename = $split_input_filename.".".$command_index.".out";
			push @split_output_filenames, $split_output_filename;
			$runner->padd($commands->[$command_index], [$split_input_filename,@{$common_inputs}], [$split_output_filename]);
		}
	}
	$runner->prun();
	
	$runner->run("cat #<A > #>1", [@split_output_filenames], [$output]);

	unlink @split_input_filenames;
	unlink @split_output_filenames;
}

sub get_stats
{
	my $stats_filename = shift;
	my $stats_outref = shift;
	
	open STATS, $stats_filename or die "Error: Unable to open $stats_filename\n";
	my @stats = <STATS>;
	chomp(@stats);
	close STATS;

	scalar @stats == 2 or die "Error: Stats file $stats_filename does not have 2 lines\n";

	my @keys = split /\t/, $stats[0];
	my @values = split /\t/, $stats[1];

	scalar @keys == scalar @values or die "Error: Stats file $stats_filename with column mismatch\n";

	foreach my $stat_index (0..$#keys)
	{
		my $key = $keys[$stat_index];
		my $value = $values[$stat_index];

		$stats_outref->{$key} = $value;
	}
}

sub setup_fastq_filenames
{
	my $info_ref = shift;
	
	$info_ref->{reads_prefix} = $info_ref->{prefix};
	$info_ref->{reads_raw_end_1_fastq} = $info_ref->{reads_prefix}.".raw.1.fastq";
	$info_ref->{reads_raw_end_2_fastq} = $info_ref->{reads_prefix}.".raw.2.fastq";
	$info_ref->{reads_end_1_fastq} = $info_ref->{reads_prefix}.".1.fastq";
	$info_ref->{reads_end_2_fastq} = $info_ref->{reads_prefix}.".2.fastq";
	$info_ref->{reads_names_filename} = $info_ref->{reads_prefix}.".names";
	$info_ref->{reads_index_filename} = $info_ref->{reads_prefix}.".fqi";
	$info_ref->{reads_sources_filename} = $info_ref->{reads_prefix}.".sources";
}

sub retrieve_fastq_padd
{
	my $source_directory = shift;
	my $info_ref = shift;
	
	-d $source_directory or die "Error: Unable to find source directory $source_directory\n";
	$source_directory = abs_path($source_directory);
	$runner->padd("$retrieve_fastq_script -c $config_filename -d $source_directory -1 $info_ref->{reads_raw_end_1_fastq} -2 $info_ref->{reads_raw_end_2_fastq} -i $info_ref->{reads_index_filename} -n $info_ref->{reads_names_filename} -s $info_ref->{reads_sources_filename}", [], []);
}

sub import_fastq_padd
{
	my $fastq_1 = shift;
	my $fastq_2 = shift;
	my $info_ref = shift;
	
	-e $fastq_1 or die "Error: Unable to find source file $fastq_1\n";
	-e $fastq_2 or die "Error: Unable to find source file $fastq_2\n";
	$fastq_1 = abs_path($fastq_1);
	$fastq_2 = abs_path($fastq_2);
	$runner->padd("$import_fastq_script --in1 #<1 --in2 #<2 --out1 #>1 --out2 #>2 --index #>3 -n #>4", [$fastq_1,$fastq_2], [$info_ref->{reads_raw_end_1_fastq},$info_ref->{reads_raw_end_2_fastq},$info_ref->{reads_index_filename},$info_ref->{reads_names_filename}]);
}

sub check_fastq_files
{
	my $info_ref = shift;
	
	if (not -e $info_ref->{reads_raw_end_1_fastq} or not -e $info_ref->{reads_raw_end_2_fastq} or not -e $info_ref->{reads_names_filename})
	{
		die "Error: no fastq files imported for $info_ref->{data_type}\n";
	}
}

sub qual_trim_fastq
{
	my $info_ref = shift;
	
	$runner->padd("$qualtrimfastq_bin -o $info_ref->{quality_offset} -l $info_ref->{seed_length} -q $info_ref->{quality_threshold} #<1 #<2 #>1 #>2", [$info_ref->{reads_raw_end_1_fastq},$info_ref->{reads_raw_end_2_fastq}], [$info_ref->{reads_end_1_fastq},$info_ref->{reads_end_2_fastq}]);
}

sub split_fastq_padd
{
	my $info_ref = shift;
	
	$info_ref->{reads_split_prefix} = $jobs_directory."/".$info_ref->{data_type}.".";
	$info_ref->{reads_end_1_split_suffix} = ".1.fastq";
	$info_ref->{reads_end_2_split_suffix} = ".2.fastq";
	$info_ref->{reads_end_1_split_catalog} = $output_directory."/".$info_ref->{data_type}.".1.split.catalog";
	$info_ref->{reads_end_2_split_catalog} = $output_directory."/".$info_ref->{data_type}.".2.split.catalog";
	$runner->padd("$split_fastq_script #<1 $reads_per_job $info_ref->{reads_split_prefix} $info_ref->{reads_end_1_split_suffix} > #>1", [$info_ref->{reads_end_1_fastq}], [$info_ref->{reads_end_1_split_catalog}]);
	$runner->padd("$split_fastq_script #<1 $reads_per_job $info_ref->{reads_split_prefix} $info_ref->{reads_end_2_split_suffix} > #>1", [$info_ref->{reads_end_2_fastq}], [$info_ref->{reads_end_2_split_catalog}]);
}

sub sample_fastq_padd
{
	my $info_ref = shift;
	
	$info_ref->{sample_end_1_fastq} = $output_directory."/".$info_ref->{data_type}.".sample.1.fastq";
	$info_ref->{sample_end_2_fastq} = $output_directory."/".$info_ref->{data_type}.".sample.2.fastq";
	$runner->padd("$sample_fastq_script $num_sample_reads 17 < #<1 > #>1", [$info_ref->{reads_end_1_fastq}], [$info_ref->{sample_end_1_fastq}]);
	$runner->padd("$sample_fastq_script $num_sample_reads 17 < #<1 > #>1", [$info_ref->{reads_end_2_fastq}], [$info_ref->{sample_end_2_fastq}]);
}

sub split_fastq_finish
{
	my $info_ref = shift;
	my $jobs_ref = shift;
	
	my @reads_end_1_split_fastqs = readsplitcatalog($info_ref->{reads_end_1_split_catalog});
	my @reads_end_2_split_fastqs = readsplitcatalog($info_ref->{reads_end_2_split_catalog});
	
	scalar @reads_end_1_split_fastqs == scalar @reads_end_2_split_fastqs or die "Error: Different split size between end 1 and 2\n";
	
	foreach my $split_index (0..$#reads_end_1_split_fastqs)
	{
		my $fastq1 = $reads_end_1_split_fastqs[$split_index];
		my $fastq2 = $reads_end_2_split_fastqs[$split_index];
		
		my $prefix1 = $fastq1;
		my $prefix2 = $fastq2;
		
		$prefix1 =~ s/$info_ref->{reads_end_1_split_suffix}$//;
		$prefix2 =~ s/$info_ref->{reads_end_2_split_suffix}$//;
		
		$prefix1 eq $prefix2 or die "Error: Inconsistent split, $prefix1 should equal $prefix2\n";
		
		my %job_info;
		$job_info{prefix} = $prefix1;
		$job_info{name} = basename($prefix1);
		$job_info{fastq1} = $fastq1;
		$job_info{fastq2} = $fastq2;
		
		push @{$jobs_ref}, \%job_info;
	}
}

sub wgss_align_padd
{
	my $info_ref = shift;
	my $jobs_ref = shift;
	
	print "Discordant wgss alignments\n";
	foreach my $job_info (@{$jobs_ref})
	{
		# Names of job products
		$job_info->{spanning_alignments} = $job_info->{prefix}.".spanning.alignments";
		$job_info->{concordant_stats} = $job_info->{prefix}.".concordant.stats";
		$job_info->{concordant_depthsamples} = $job_info->{prefix}.".concordant.depthsamples";
		
		my $job_cmd = $alignjob_dna_script." ";
		$job_cmd .= "-c ".$config_filename." ";
		$job_cmd .= "-j ".$job_info->{name}." ";
		$job_cmd .= "-l ".$joblocal_directory." ";
		$job_cmd .= "-o ".$output_directory." ";
		$job_cmd .= "-n ".$library_name." ";
		$job_cmd .= "-p ".$job_info->{prefix}." ";
		
		my @job_products;
		push @job_products, $job_info->{spanning_alignments};
		push @job_products, $job_info->{concordant_stats};
		push @job_products, $job_info->{concordant_depthsamples};
		
		$runner->padd("$job_cmd", [$job_info->{fastq1}, $job_info->{fastq2}], [@job_products]); 
	}
}

sub wgss_sample_align
{
	my $info_ref = shift;
	
	$info_ref->{sample_sam} = $output_directory."/".$info_ref->{data_type}.".sample.sam";
	$runner->run("$bowtie2_bin --no-mixed --no-discordant --very-sensitive -X $dna_max_fragment_length $bowtie2_options -x $genome_fasta -1 #<1 -2 #<2 > #>1", [$info_ref->{sample_end_1_fastq},$info_ref->{sample_end_2_fastq}], [$info_ref->{sample_sam}]);
	
	$info_ref->{sample_align_true} = $output_directory."/".$info_ref->{data_type}.".sample.align.true";
	$runner->run("$aligntrue_bin -g $gap_score -x $mismatch_score -m $match_score -r $genome_fasta -a #<1 > #>1",  [$info_ref->{sample_sam}], [$info_ref->{sample_align_true}]);
	
	$info_ref->{score_stats} = $output_directory."/".$info_ref->{data_type}.".score.stats";
	$runner->run("$score_stats_rscript #<1 $match_score #>1", [$info_ref->{sample_align_true}], [$info_ref->{score_stats}]);
}

sub wgss_merge_cluster
{
	my $info_ref = shift;
	my $jobs_ref = shift;
	
	my @job_spanning_alignments;
	my @job_concordant_stats;
	my @job_concordant_depthsamples;
	foreach my $job_info (@{$jobs_ref})
	{
		push @job_spanning_alignments, $job_info->{spanning_alignments};
		push @job_concordant_stats, $job_info->{concordant_stats};
		push @job_concordant_depthsamples, $job_info->{concordant_depthsamples};
	}
	
	# Merge products of the alignment process
	$info_ref->{spanning_alignments} = $info_ref->{prefix}.".spanning.alignments";
	$info_ref->{concordant_stats} = $info_ref->{prefix}.".concordant.stats";
	$info_ref->{concordant_depthsamples} = $info_ref->{prefix}.".concordant.depthsamples";
	$runner->padd("cat #<A > #>1", [@job_spanning_alignments], [$info_ref->{spanning_alignments}]);
	$runner->padd("$merge_read_stats_script #<A > #>1", [@job_concordant_stats], [$info_ref->{concordant_stats}]);
	$runner->padd("$merge_depthsamples_script #<A > #>1", [@job_concordant_depthsamples], [$info_ref->{concordant_depthsamples}]);
	$runner->prun();
	
	# Read in the read stats
	my %read_stat_values;
	get_stats($info_ref->{concordant_stats}, \%read_stat_values);
	
	$info_ref->{read_length_min} = $read_stat_values{"readlength_min"};
	$info_ref->{read_length_max} = $read_stat_values{"readlength_max"};
	$info_ref->{readlengths_list} = $read_stat_values{"readlengths_list"};
	$info_ref->{fragment_mean} = $read_stat_values{"fraglength_mean"};
	$info_ref->{fragment_stddev} = $read_stat_values{"fraglength_stddev"};
	
	print "WGSS Read Stats\n";
	print "\tFragment mean $info_ref->{fragment_mean} stddev $info_ref->{fragment_stddev}\n";
	print "\tRead length min $info_ref->{read_length_min} max $info_ref->{read_length_max}\n";
	
	print "Generating WGSS discordant alignment clusters\n";
	$info_ref->{clusters_all} = $info_ref->{prefix}.".clusters.all";
	$runner->run("cat #<A | $clustermatepairs_bin -m $dna_min_spanning_reads -u $info_ref->{fragment_mean} -d $info_ref->{fragment_stddev} -a - -o #>1", [@job_spanning_alignments], [$info_ref->{clusters_all}]);
	
	print "Remove mitochondrial-genomic clusters\n";
	$info_ref->{clusters_nomt} = $info_ref->{prefix}.".clusters.nomt";
	$runner->run("$segregate_mitochondrial_script $gene_models $mt_chromosome < #<1 > #>1", [$info_ref->{clusters_all}], [$info_ref->{clusters_nomt}]);
	
	print "Filter pcr duplicates\n";
	$info_ref->{clusters_nodup} = $info_ref->{prefix}.".clusters.nodup";
	$runner->run("$remove_duplicates_script $dna_min_spanning_reads < #<1 > #>1", [$info_ref->{clusters_nomt}], [$info_ref->{clusters_nodup}]);
	
	print "Pre-setcover for clusters\n";
	$info_ref->{clusters_raw} = $info_ref->{prefix}.".clusters.raw";
	$runner->run("$presetcover_bin -c #<1 -o #>1", [$info_ref->{clusters_nodup}], [$info_ref->{clusters_raw}]);
	
	print "Ranking dna clusters\n";
	$info_ref->{clusters_raw_read_counts} = $info_ref->{prefix}.".clusters.raw.readcounts";
	$info_ref->{clusters_raw_prob_step1} = $info_ref->{prefix}.".clusters.raw.prob.step1";
	$info_ref->{clusters_raw_read_counts_prob} = $info_ref->{prefix}.".clusters.raw.readcounts.prob";
	$info_ref->{clusters_raw_prob_step2} = $info_ref->{prefix}.".clusters.raw.prob.step2";
	$runner->run("$count_cluster_reads_script < #<1 > #>1", [$info_ref->{clusters_raw}], [$info_ref->{clusters_raw_read_counts}]);
	$runner->run("$rankclusters_bin -c #<1 > #>1", [$info_ref->{clusters_raw}], [$info_ref->{clusters_raw_prob_step1}]);
	$runner->run("$cluster_size_prob_rscript #<1 #<2 #<3 #>1", [$info_ref->{concordant_depthsamples},$info_ref->{clusters_raw_read_counts},$info_ref->{clusters_raw_prob_step1}], [$info_ref->{clusters_raw_read_counts_prob}]);
	$runner->run("$rankclusters_bin -c #<1 -d #<2 > #>1", [$info_ref->{clusters_raw},$info_ref->{clusters_raw_read_counts_prob}], [$info_ref->{clusters_raw_prob_step2}]);
	
	print "Filtering dna clusters\n";
	$info_ref->{clusters} = $info_ref->{prefix}.".clusters";
	$info_ref->{clusters_prob} = $info_ref->{prefix}.".clusters.prob";
	$runner->run("$filter_clusters_script #<1 #<2 #>1 #>2 $cluster_prob_threshold", [$info_ref->{clusters_raw},$info_ref->{clusters_raw_prob_step2}], [$info_ref->{clusters},$info_ref->{clusters_prob}]); 
}

sub rnaseq_align_padd
{
	my $info_ref = shift;
	my $jobs_ref = shift;
	
	print "Discordant rnaseq alignments\n";
	foreach my $job_info (@{$jobs_ref})
	{
		# Names of job products
		$job_info->{read_stats} = $job_info->{prefix}.".concordant.stats";
		$job_info->{spanlength_samples} = $job_info->{prefix}.".spanlength.samples";
		$job_info->{splitpos_samples} = $job_info->{prefix}.".splitpos.samples";
		$job_info->{splitmin_samples} = $job_info->{prefix}.".splitmin.samples";
		$job_info->{improper_alignments} = $job_info->{prefix}.".improper.alignments";
		$job_info->{spanning_alignments} = $job_info->{prefix}.".spanning.alignments";
		
		my $job_cmd = $alignjob_rna_script." ";
		$job_cmd .= "-c ".$config_filename." ";
		$job_cmd .= "-j ".$job_info->{name}." ";
		$job_cmd .= "-l ".$joblocal_directory." ";
		$job_cmd .= "-o ".$output_directory." ";
		$job_cmd .= "-n ".$library_name." ";
		$job_cmd .= "-p ".$job_info->{prefix}." ";
		
		my @job_products;
		push @job_products, $job_info->{read_stats};
		push @job_products, $job_info->{spanlength_samples};
		push @job_products, $job_info->{splitpos_samples};
		push @job_products, $job_info->{splitmin_samples};
		push @job_products, $job_info->{improper_alignments};
		push @job_products, $job_info->{spanning_alignments};
		
		$runner->padd("$job_cmd", [$job_info->{fastq1}, $job_info->{fastq2}], [@job_products]); 
	}
}

sub rnaseq_merge_cluster
{	
	my $info_ref = shift;
	my $jobs_ref = shift;
	
	my @job_read_stats;
	my @job_spanlength_samples;
	my @job_splitpos_samples;
	my @job_splitmin_samples;
	my @job_spanning_alignments;
	foreach my $job_info (@{$jobs_ref})
	{
		push @job_read_stats, $job_info->{read_stats};
		push @job_spanlength_samples, $job_info->{spanlength_samples};
		push @job_splitpos_samples, $job_info->{splitpos_samples};
		push @job_splitmin_samples, $job_info->{splitmin_samples};
		push @job_spanning_alignments, $job_info->{spanning_alignments};
	}
	
	$info_ref->{read_stats} = $info_ref->{prefix}.".concordant.stats";
	$info_ref->{spanlength_cov} = $info_ref->{prefix}.".spanlength.cov";
	$info_ref->{splitpos_cov} = $info_ref->{prefix}.".splitpos.cov";
	$info_ref->{splitmin_cov} = $info_ref->{prefix}.".splitmin.cov";
	$info_ref->{spanning_alignments} = $info_ref->{prefix}.".spanning.alignments";
	$runner->padd("$merge_read_stats_script #<A > #>1", [@job_read_stats], [$info_ref->{read_stats}]);
	$runner->padd("$merge_cov_samples_script #<A > #>1", [@job_spanlength_samples], [$info_ref->{spanlength_cov}]);
	$runner->padd("$merge_cov_samples_script #<A > #>1", [@job_splitpos_samples], [$info_ref->{splitpos_cov}]);
	$runner->padd("$merge_cov_samples_script #<A > #>1", [@job_splitmin_samples], [$info_ref->{splitmin_cov}]);
	$runner->padd("cat #<A > #>1", [@job_spanning_alignments], [$info_ref->{spanning_alignments}]);
	$runner->prun();
	
	# Read in the read stats
	my %read_stat_values;
	get_stats($info_ref->{read_stats}, \%read_stat_values);
	
	$info_ref->{read_length_min} = $read_stat_values{"readlength_min"};
	$info_ref->{read_length_max} = $read_stat_values{"readlength_max"};
	$info_ref->{fragment_mean} = $read_stat_values{"fraglength_mean"};
	$info_ref->{fragment_stddev} = $read_stat_values{"fraglength_stddev"};
	$info_ref->{fragment_max} = int($info_ref->{fragment_mean} + 3 * $info_ref->{fragment_stddev});
	
	print "RNA-Seq Read Stats\n";
	print "\tFragment mean $info_ref->{fragment_mean} stddev $info_ref->{fragment_stddev}\n";
	print "\tRead length min $info_ref->{read_length_min} max $info_ref->{read_length_max}\n";
	
	print "Generating RNA-Seq discordant alignment clusters\n";
	$info_ref->{clusters_all} = $info_ref->{prefix}.".clusters.all";
	$runner->run("cat #<A | $clustermatepairs_bin -m $rna_min_spanning_reads -u $info_ref->{fragment_mean} -d $info_ref->{fragment_stddev} -a - -o #>1", [@job_spanning_alignments], [$info_ref->{clusters_all}]);
	
	print "Remove mitochondrial-genomic clusters\n";
	$info_ref->{clusters_nomt} = $info_ref->{prefix}.".clusters.nomt";
	$runner->run("$segregate_mitochondrial_script $gene_models $mt_chromosome < #<1 > #>1", [$info_ref->{clusters_all}], [$info_ref->{clusters_nomt}]);
	
	print "Filter pcr duplicates\n";
	$info_ref->{clusters_nodup} = $info_ref->{prefix}.".clusters.nodup";
	$runner->run("$remove_duplicates_script $rna_min_spanning_reads < #<1 > #>1", [$info_ref->{clusters_nomt}], [$info_ref->{clusters_nodup}]);
	
	print "Pre-setcover for clusters\n";
	$info_ref->{clusters_raw} = $info_ref->{prefix}.".clusters.raw";
	$runner->run("$presetcover_bin -c #<1 -o #>1", [$info_ref->{clusters_nodup}], [$info_ref->{clusters_raw}]);
	
	print "Pre-filter RNA-Seq clusters\n";
	$info_ref->{clusters_norrna} = $info_ref->{prefix}.".clusters.norrna";
	$runner->run("$filter_repeat_clusters_script $repeats_regions rRNA 0.5 1 < #<1 > #>1", [$info_ref->{clusters_raw}], [$info_ref->{clusters_norrna}]);
	$info_ref->{clusters_local_seq} = $info_ref->{prefix}.".clusters.local.seq";
	$runner->run("$prep_local_alignment_seqs_script -r $genome_cdna_fasta -g $gene_models -c #<1 -s $rna_concordant_length > #>1", [$info_ref->{clusters_norrna}], [$info_ref->{clusters_local_seq}]);
	$info_ref->{clusters_local_align} = $info_ref->{prefix}.".clusters.local.align";
	$runner->run("$localalign_bin -m 10 -x -5 -g -5 -t 0.9 < #<1 > #>1", [$info_ref->{clusters_local_seq}], [$info_ref->{clusters_local_align}]);
	$info_ref->{clusters} = $info_ref->{prefix}.".clusters";
	$runner->run("cat #<1 | $filter_column_script #<2 0 1 > #>1", [$info_ref->{clusters_norrna},$info_ref->{clusters_local_align}], [$info_ref->{clusters}]);
	$info_ref->{clusters_fusions} = $info_ref->{prefix}.".clusters.fusions";
	$runner->run("$filter_readthrough_clusters_script $gene_models #<1 $max_intron_length > #>1", [$info_ref->{clusters}], [$info_ref->{clusters_fusions}]);
	
	print "Generate rna cluster regions\n";
	$info_ref->{clusters_fusions_regions} = $info_ref->{prefix}.".clusters.fusions.regions";
	$runner->run("$calc_align_regions_script < #<1 > #>1", [$info_ref->{clusters_fusions}], [$info_ref->{clusters_fusions_regions}]);
	
	print "Remap rna cluster regions to genome\n";
	$info_ref->{clusters_fusions_regions_remap} = $info_ref->{prefix}.".clusters.fusions.regions.remap";
	$runner->run("$remap_regions_to_genome_script $gene_models $remap_end_adjust < #<1 > #>1", [$info_ref->{clusters_fusions_regions}], [$info_ref->{clusters_fusions_regions_remap}]);
	
	print "Identifying read throughs\n";
	$info_ref->{readthroughs} = $info_ref->{prefix}.".readthroughs";
	$runner->run("$identify_readthroughs_script $gene_models $max_intron_length < #<1 > #>1", [$info_ref->{clusters}], [$info_ref->{readthroughs}]);	
}

sub rnaseq_split_alignment
{
	my $info_ref = shift;
	my $jobs_ref = shift;
	
	print "Generating spanning alignment regions file\n";
	$info_ref->{clusters_sc_regions} = $info_ref->{prefix}.".clusters.sc.regions";
	$runner->run("$get_align_regions_script < #<1 > #>1", [$info_ref->{clusters_sc}], [$info_ref->{clusters_sc_regions}]);
	
	print "Initializing split read alignments\n";
	$info_ref->{splitreads_refseqs} = $info_ref->{prefix}.".splitreads.refseqs";
	$info_ref->{splitreads_materegions} = $info_ref->{prefix}.".splitreads.materegions";
	$runner->run("$initsplitalign_bin -i #<1 -r #>1 -m #>2 -n $info_ref->{read_length_min} -x $info_ref->{read_length_max} -u $info_ref->{fragment_mean} -s $info_ref->{fragment_stddev} -e $cdna_regions -f $genome_cdna_fasta", [$info_ref->{clusters_sc_regions}], [$info_ref->{splitreads_refseqs},$info_ref->{splitreads_materegions}]);
	
	print "Calculating split read alignments\n";
	my @job_splitreads_alignments;
	foreach my $job_info (@{$jobs_ref})
	{
		$job_info->{splitalign} = $job_info->{prefix}.".splitreads.alignments";
		$runner->padd("$dosplitalign_bin -1 #<1 -2 #<2 -r #<3 -m #<4 -a #<5 -s #>1", [$job_info->{fastq1},$job_info->{fastq2},$info_ref->{splitreads_refseqs},$info_ref->{splitreads_materegions},$job_info->{improper_alignments}], [$job_info->{splitalign}]);
		push @job_splitreads_alignments, $job_info->{splitalign};
	}
	$runner->prun();
	$info_ref->{splitreads_alignments} = $info_ref->{prefix}.".splitreads.alignments";
	$runner->run("cat #<A > #>1", [@job_splitreads_alignments], [$info_ref->{splitreads_alignments}]);
	
	print "Evaluating split reads\n";
	$info_ref->{splitreads_break} = $info_ref->{prefix}.".splitreads.break";
	$info_ref->{splitreads_seq} = $info_ref->{prefix}.".splitreads.seq";
	$runner->run("$evalsplitalign_bin -r #<1 -a #<2 -b #>1 -q #>2", [$info_ref->{splitreads_refseqs},$info_ref->{splitreads_alignments}], [$info_ref->{splitreads_break},$info_ref->{splitreads_seq}]);
	
	print "Calculating spanning stats\n";
	$info_ref->{splitreads_span_stats} = $info_ref->{prefix}.".splitreads.span.stats";
	$runner->padd("$calc_span_stats_script -c #<1 -b #<2 -s #<3 > #>1", [$info_ref->{clusters_sc},$info_ref->{splitreads_break},$info_ref->{splitreads_seq}], [$info_ref->{splitreads_span_stats}]);
	$runner->prun();
	
	print "Calculating spanning p-values\n";
	$info_ref->{splitreads_span_pval} = $info_ref->{prefix}.".splitreads.span.pval";
	$runner->padd("$evaluate_fraglength_rscript #<1 #<2 $rna_seed_length #<3 #>1", [$info_ref->{read_stats},$info_ref->{spanlength_cov},$info_ref->{splitreads_span_stats}], [$info_ref->{splitreads_span_pval}]);
	$runner->prun();
	
	print "Calculating split read pvalues\n";
	$info_ref->{splitreads_split_pval} = $info_ref->{prefix}.".splitreads.split.pval";
	$runner->run("$evaluate_split_rscript #<1 #<2 #<3 #>1", [$info_ref->{splitpos_cov},$info_ref->{splitmin_cov},$info_ref->{splitreads_seq}], [$info_ref->{splitreads_split_pval}]);
}





