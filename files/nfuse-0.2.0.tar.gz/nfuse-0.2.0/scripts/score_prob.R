args = commandArgs(TRUE)

all_true_scores = read.table(args[1], col.names=c("length","score"), colClasses=c("integer","integer"))
all_null_scores = read.table(args[2], col.names=c("length","score"), colClasses=c("integer","integer"))

models = data.frame(length=c(), intercept=c(), slope=c())

for (length in unique(all_true_scores$length)) {
	true_scores = sample(all_true_scores$score[all_true_scores$length == length], 100000, replace=T)
	null_scores = sample(all_null_scores$score[all_null_scores$length == length], 100000, replace=T)
	
	alls = c(null_scores,true_scores)
	allv = c(rep(0,length(null_scores)),rep(1,length(true_scores)))
	
	logr = glm(allv ~ alls, family=binomial("logit"))
	
	models = rbind(models, data.frame(length=c(length), intercept=c(logr$coefficients[[1]]), slope=c(logr$coefficients[[2]])))
}

write.table(models, file=args[3], quote=F, sep="\t", eol="\n", row.names=F, col.names=F)


