/*
 *  AlignmentProbability.cpp
 *
 */

#include "AlignmentProbability.h"
#include "Parsers.h"
#include "Common.h"

#include <fstream>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/math/distributions/negative_binomial.hpp>

using namespace boost;
using namespace std;


void AlignmentProbability::ReadDistributions(const string& filename)
{
	ifstream distFile(filename.c_str());
	
	if (!distFile.good())
	{
		cerr << "Error: Unable to open file " << filename << endl;
		exit(1);
	}
	
	StringVec fields;
	while (ReadTSV(distFile, fields))
	{
		int alignedLength = lexical_cast<int>(fields[0]);
		
		mNBSize[alignedLength] = lexical_cast<double>(fields[1]);
		mNBProb[alignedLength] = lexical_cast<double>(fields[2]);
	}
}

double AlignmentProbability::Probability(int alignedLength, int score) const
{
	return pdf(math::negative_binomial(mNBSize.find(alignedLength)->second, mNBProb.find(alignedLength)->second), mMatchScore * alignedLength - score);
}

void AlignmentPosterior::Initialize(const AlignmentProbability* alignmentProbability, int alignedLength)
{
	mAlignmentProbability = alignmentProbability;
	mAlignedLength = alignedLength;
	mSumProbTrue = 0.0;
	mMaxScore = 0;
}

void AlignmentPosterior::AddAlignment(int score)
{
	double probTrue = mAlignmentProbability->Probability(mAlignedLength, score);
	
	mSumProbTrue += probTrue;
	mMaxScore = max(mMaxScore, score);
}

double AlignmentPosterior::MaxPosterior()
{
	double probTrue = mAlignmentProbability->Probability(mAlignedLength, mMaxScore);
	
	return probTrue / mSumProbTrue;
}

double AlignmentPosterior::Posterior(int score)
{
	double probTrue = mAlignmentProbability->Probability(mAlignedLength, score);
	
	return probTrue / mSumProbTrue;
}

