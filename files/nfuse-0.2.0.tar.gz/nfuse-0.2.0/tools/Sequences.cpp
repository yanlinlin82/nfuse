/*
 *  Sequences.cpp
 *
 *  Created by Andrew McPherson on 07/16/11.
 *
 */

#include "Sequences.h"
#include "DebugCheck.h"

#include <fstream>
#include <algorithm>
#include <boost/unordered_map.hpp>

using namespace std;
using namespace boost;

void Sequences::Read(const string& fastaFilename)
{
	ifstream fastaFile(fastaFilename.c_str());
	if (!fastaFile.good())
	{
		cerr << "Error: unable to open file " << fastaFilename << endl;
		exit(1);
	}
	
	string id;
	string sequence;
	
	string line;
	while (getline(fastaFile, line))
	{
		if (line.size() == 0)
		{
			continue;
		}
		
		if (line[0] == '>')
		{
			if (!id.empty())
			{
				sequence.append(string(mPadding,'N'));
				mSequences[id] = sequence;
				mNames.push_back(id);
			}
			
			id = line.substr(1);
			sequence = string(mPadding,'N');
		}
		else
		{
			sequence.append(line);
		}
	}
	
	if (!id.empty())
	{
		sequence.append(string(mPadding,'N'));
		mSequences[id] = sequence;
		mNames.push_back(id);
	}
	
	mConcatSize = 0;
	for (unordered_map<string,string>::const_iterator seqIter = mSequences.begin(); seqIter != mSequences.end(); seqIter++)
	{
		mConcatSize += seqIter->second.size();
	}
}

void Sequences::Get(const string& id, int start, int end, string& sequence) const
{
	if (mSequences.find(id) == mSequences.end())
	{
		cerr << "Error: Unable to find sequence " << id << endl;
		exit(1);
	}
	
	const string& fullSequence = mSequences.find(id)->second;
	int length = end - start + 1;
	
	sequence = fullSequence.substr(start - 1 + mPadding, length);
}

const char* Sequences::Get(const string& id, int pos) const
{
	if (mSequences.find(id) == mSequences.end())
	{
		cerr << "Error: Unable to find sequence " << id << endl;
		exit(1);
	}
	
	const string& fullSequence = mSequences.find(id)->second;
	
	return fullSequence.c_str() + pos - 1 + mPadding;
}

void Sequences::Get(const string& id, int strand, int& start, int& length, string& sequence) const
{
	if (mSequences.find(id) == mSequences.end())
	{
		cerr << "Error: Unable to find sequence " << id << endl;
		exit(1);
	}
	
	const string& fullSequence = mSequences.find(id)->second;
	
	int fullSequenceLength = fullSequence.length() - 2 * mPadding;
	
	int end = start + length - 1;
	
	start = max(1, start);
	end = min(fullSequenceLength, end);
	length = max(0, end - start + 1);
	
	sequence = fullSequence.substr(start - 1 + mPadding, length);
	
	if (strand == MinusStrand)
	{
		ReverseComplement(sequence);
	}
}

void Sequences::GetRandomSequence(int length, string& sequence, string& id, int& strand, int& start, int& end) const
{
	while (true)
	{
		int concatPositon = rand() % mConcatSize;
		
		int accumConcatSize = 0;
		unordered_map<string,string>::const_iterator seqIter;
		for (seqIter = mSequences.begin(); seqIter != mSequences.end(); seqIter++)
		{
			accumConcatSize += seqIter->second.size();
			if (concatPositon < accumConcatSize)
			{
				id = seqIter->first;
				start = concatPositon - (accumConcatSize - seqIter->second.size());
				break;
			}
		}
		
		if (seqIter == mSequences.end())
		{
			continue;
		}
		
		strand = rand() % 2;
		
		sequence = mSequences.find(id)->second.substr(start, length);
		
		if (sequence.size() < length)
		{
			continue;
		}
		
		if (sequence.find_first_of("Nn") != string::npos)
		{
			continue;
		}
		
		if (strand == 1)
		{
			ReverseComplement(sequence);
		}
		
		start = start + 1;
		end = start + length - 1;
		
		break;
	}
}

void Sequences::GetRandomSequence(int length, string& sequence) const
{
	string id;
	int strand;
	int start;
	int end;
	GetRandomSequence(length, sequence, id, strand, start, end);
}

