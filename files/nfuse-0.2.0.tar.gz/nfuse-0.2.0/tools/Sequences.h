/*
 *  Sequences.h
 *
 *  Created by Andrew McPherson on 07/16/11.
 *
 */

#ifndef SEQUENCES_H_
#define SEQUENCES_H_

#include "Common.h"

#include <map>
#include <string>
#include <iostream>

using namespace std;
using namespace boost;

class Sequences
{
public:
	explicit Sequences(int padding = 0) : mPadding(padding), mConcatSize(0) {}
	void Read(const string& fastaFilename);
	void Get(const string& id, int start, int end, string& sequence) const;
	const char* Get(const string& id, int pos) const;
	void Get(const string& id, int strand, int& start, int& length, string& sequence) const;
	
	void GetRandomSequence(int length, string& sequence) const;
	void GetRandomSequence(int length, string& sequence, string& id, int& strand, int& start, int& end) const;

private:
	int mPadding;
	vector<string> mNames;
	unordered_map<string,string> mSequences;
	int mConcatSize;
};

#endif
