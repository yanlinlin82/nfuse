/*
 *  bamsamplefastq.cpp
 *
 *  Created by Andrew McPherson on 28/09/09.
 *
 */

#include "DebugCheck.h"
#include "Indexer.h"
#include "AlignmentStream.h"
#include "RegionDB.h"
#include "api/BamReader.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/accumulators/accumulators.hpp>
#include <boost/accumulators/statistics/stats.hpp>
#include <boost/accumulators/statistics/min.hpp>
#include <boost/accumulators/statistics/max.hpp>
#include <boost/accumulators/statistics/mean.hpp>
#include <boost/accumulators/statistics/variance.hpp>

using namespace boost;
using namespace std;

using namespace BamTools;


bool IsInSample(int previousReadCount, int numSamples, int& sampleIndex)
{
	if (previousReadCount < numSamples)
	{
		sampleIndex = previousReadCount;
		
		return true;
	}
	
	sampleIndex = rand() % previousReadCount;
	
	if (sampleIndex < numSamples)
	{
		return true;
	}
	
	return false;
}

inline string GetSequence(const BamAlignment& alignment)
{
	string sequence = alignment.QueryBases;
	if (alignment.IsReverseStrand())
	{
		ReverseComplement(sequence);
	}
	return sequence;
}

inline string GetQualities(const BamAlignment& alignment)
{
	string qualities = alignment.Qualities;
	if (alignment.IsReverseStrand())
	{
		reverse(qualities.begin(), qualities.end());
	}
	return qualities;
}

class ReadData
{
public:
	ReadData()
	{
	}
	
	explicit ReadData(const BamAlignment& alignment)
	{
		assert(!alignment.Name.empty());
		
		int readEnd = alignment.IsFirstMate() ? 0 : 1;
		
		mName = alignment.Name;
		mComment = alignment.Name;
		mSequence[readEnd] = GetSequence(alignment);
		mQualities[readEnd] = GetQualities(alignment);
	}
	
	bool Match(const BamAlignment& alignment)
	{
		assert(!alignment.Name.empty());
		
		if (alignment.Name != mName)
		{
			return false;
		}
		
		int readEnd = alignment.IsFirstMate() ? 0 : 1;
		
		assert(mSequence[readEnd].empty());
		assert(mQualities[readEnd].empty());
		
		mSequence[readEnd] = GetSequence(alignment);
		mQualities[readEnd] = GetQualities(alignment);
		
		return true;
	}
	
	bool Matched() const
	{
		return !mSequence[0].empty() && !mSequence[1].empty();
	}
	
	void WriteFirstMate(ostream& fastq) const
	{
		WriteFastq(0, fastq);
	}
	
	void WriteSecondMate(ostream& fastq) const
	{
		WriteFastq(1, fastq);
	}
	
	void WriteFastq(int readEnd, ostream& fastq) const
	{
		fastq << "@" << mName << "/" << readEnd + 1 << endl;
		fastq << mSequence[readEnd] << endl;
		fastq << "+" << mComment << endl;
		fastq << mQualities[readEnd] << endl;
	}
	
	void SetName(const string& name)
	{
		mName = name;
	}
	
private:
	string mName;
	string mComment;
	string mSequence[2];
	string mQualities[2];
};

struct RefPos
{
	RefPos(int refID, int pos) : refID(refID), pos(pos) {}
	
	bool operator<(const RefPos& other) const
	{
		if (refID < other.refID)
		{
			return true;
		}
		else if (refID > other.refID)
		{
			return false;
		}
		else
		{
			return pos < other.pos;
		}
	}
	
	bool operator==(const RefPos& other) const
	{
		return refID == other.refID && pos == other.pos;
	}
	
	int refID;
	int pos;
};

bool IsFirstOfPair(const BamAlignment& alignment)
{
	if (alignment.RefID < alignment.MateRefID)
	{
		return true;
	}
	else if (alignment.RefID > alignment.MateRefID)
	{
		return false;
	}
	else
	{
		return alignment.Position < alignment.MatePosition;
	}
}

int main(int argc, char* argv[])
{
	string bamFilename;
	string fastq1Filename;
	string fastq2Filename;
	int numSamples;
	bool rename;
	
	try
	{
		TCLAP::CmdLine cmd("Bam to Fastq Tool");
		TCLAP::ValueArg<string> bamFilenameArg("b","bam","Bam Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> fastq1FilenameArg("1","fastq1","Sample Fastq End 1 Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> fastq2FilenameArg("2","fastq2","Sample Fastq End 2 Filename",true,"","string",cmd);
		TCLAP::ValueArg<int> numSamplesArg("n","num","Number of Samples",true,0,"integer",cmd);
		TCLAP::SwitchArg renameArg("r","rename","Rename With Integer IDs",cmd);
		cmd.parse(argc,argv);
		
		bamFilename = bamFilenameArg.getValue();
		fastq1Filename = fastq1FilenameArg.getValue();
		fastq2Filename = fastq2FilenameArg.getValue();
		numSamples = numSamplesArg.getValue();
		rename = renameArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	srand(11);
	
	vector<ReadData> sampleData(numSamples);
	
	BamReader bamReader;
	if (!bamReader.Open(bamFilename))
	{
		cerr << "Error: Unable to open bam file " << bamFilename << endl;
		exit(1);
	}
	
	multimap<RefPos,int> mateSample;
	
	int readCount = 0;
	
	BamAlignment alignment;
	BamAlignment previousAlignment;
	bool previousAlignmentValid = false;
	while (bamReader.GetNextAlignmentCore(alignment))
	{
		if (alignment.IsMapped() && alignment.IsMateMapped())
		{
			if (IsFirstOfPair(alignment))
			{
				int sampleIndex;
				if (IsInSample(readCount, numSamples, sampleIndex))
				{
					alignment.BuildCharData();
					
					sampleData[sampleIndex] = ReadData(alignment);
					
					mateSample.insert(make_pair(RefPos(alignment.MateRefID, alignment.MatePosition), sampleIndex));
				}
				
				readCount++;
			}
			else
			{
				RefPos alignmentRefPos(alignment.RefID, alignment.Position);
				
				while (!mateSample.empty() && mateSample.begin()->first < alignmentRefPos)
				{
					mateSample.erase(mateSample.begin());
				}
				
				if (!mateSample.empty() && mateSample.begin()->first == alignmentRefPos)
				{
					alignment.BuildCharData();
					
					multimap<RefPos,int>::iterator mateIter = mateSample.begin();
					while (mateIter != mateSample.end() && mateIter->first == alignmentRefPos)
					{
						if (sampleData[mateIter->second].Match(alignment))
						{
							mateSample.erase(mateIter);
							break;
						}
						
						mateIter++;
					}
				}
			}
		}
		else if (alignment.IsFirstMate())
		{
			int sampleIndex;
			if (IsInSample(readCount, numSamples, sampleIndex))
			{
				alignment.BuildCharData();
				
				sampleData[sampleIndex] = ReadData(alignment);
				
				bool matched = previousAlignmentValid && sampleData[sampleIndex].Match(previousAlignment);
				
				if (!matched)
				{
					previousAlignment = alignment;
					matched = bamReader.GetNextAlignment(alignment) && sampleData[sampleIndex].Match(alignment);
				}
				
				if (!matched)
				{
					cerr << "Warning: Expected adjacent entries for unmapped read " << previousAlignment.Name << endl;
				}
			}
			
			readCount++;
		}
		
		previousAlignment = alignment;
		previousAlignmentValid = true;
	}
	
	ofstream fastq1File(fastq1Filename.c_str());
	ofstream fastq2File(fastq2Filename.c_str());
	
	CheckFile(fastq1File, fastq1Filename);
	CheckFile(fastq2File, fastq2Filename);
	
	int fragmentIndex = 0;
	for (vector<ReadData>::iterator readIter = sampleData.begin(); readIter != sampleData.end(); readIter++)
	{
		if (rename)
		{
			stringstream fragmentStream;
			fragmentStream << fragmentIndex;
			readIter->SetName(fragmentStream.str());
		}
		
		readIter->WriteFirstMate(fastq1File);
		readIter->WriteSecondMate(fastq2File);
		
		fragmentIndex++;
	}
}

