/*
 *  rankclusters.cpp
 *
 *  Created by Andrew McPherson
 *
 */

#include "Common.h"
#include "DebugCheck.h"
#include "Sequences.h"
#include "Parsers.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/math/distributions/lognormal.hpp>
#include <boost/math/distributions/negative_binomial.hpp>

using namespace boost;
using namespace boost::math;
using namespace std;


class MapWithDefault
{
public:
	MapWithDefault(double defaultValue, DoubleMap& map) : mDefaultValue(defaultValue), mMap(map) {}
	MapWithDefault(double defaultValue) : mDefaultValue(defaultValue) {}
	
	double operator [](int key) const
	{
		DoubleMapConstIter mapIter = mMap.find(key);
		if (mapIter == mMap.end())
		{
			return mDefaultValue;
		}
		else
		{
			return mapIter->second;
		}
	}
	
private:
	double mDefaultValue;
	DoubleMap mMap;
};

double CalculateClusterProbability(const DoubleVec& fragmentProbabilities, const MapWithDefault& depthProbabilities)
{
	DoubleVec previousRow;
	previousRow.push_back(1.0 - fragmentProbabilities[0]);
	previousRow.push_back(fragmentProbabilities[0]);
	
	for (int l = 1; l < fragmentProbabilities.size(); l++)
	{
		DoubleVec nextRow;
		
		double prob0 = previousRow[0] * (1.0 - fragmentProbabilities[l]);
		nextRow.push_back(prob0);
		
		for (int k = 1; k <= l; k++)
		{
			double prob = previousRow[k-1] * fragmentProbabilities[l] + previousRow[k] * (1.0 - fragmentProbabilities[l]);
			nextRow.push_back(prob);
		}
		
		double prob = previousRow[l] * fragmentProbabilities[l];
		nextRow.push_back(prob);
		
		swap(nextRow, previousRow);
	}
	
	double clusterProb = 0.0;
	for (int n = 1; n <= fragmentProbabilities.size(); n++)
	{
		clusterProb += previousRow[n] * depthProbabilities[n];
	}
	
	return clusterProb;
}

void OutputClusterProbabilities(const string& clustersFilename, const MapWithDefault& depthProbabilities)
{
	ifstream clustersFile(clustersFilename.c_str());
	CheckFile(clustersFile, clustersFilename);
	
	ClusterReader clusterReader(clustersFile);
	
	while (clusterReader.Next())
	{
		int clusterID = clusterReader.FetchClusterID();
		DoubleVec fragmentProbabilities = clusterReader.FetchFragmentProbabilities();
		
		double clusterProbability = CalculateClusterProbability(fragmentProbabilities, depthProbabilities);
		
		cout << clusterID << "\t" << clusterProbability << endl;
	}
}

int main(int argc, char* argv[])
{
	string clustersFilename;
	string depthProbFilename;
	
	try
	{
		TCLAP::CmdLine cmd("Cluster ranking tool");
		TCLAP::ValueArg<string> clustersFilenameArg("c","clusters","Clusters Filename",true,"","string",cmd);
		TCLAP::ValueArg<string> depthProbFilenameArg("d","depthprob","Depth Probability Filename",false,"","string",cmd);
		cmd.parse(argc,argv);
		
		clustersFilename = clustersFilenameArg.getValue();
		depthProbFilename = depthProbFilenameArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	cerr << "Calculating cluster probabilities" << endl;
	
	if (depthProbFilename.empty())
	{
		OutputClusterProbabilities(clustersFilename, MapWithDefault(1.0));
	}
	else
	{
		DoubleMap depthProbability;
		ReadDoubleMap(depthProbFilename, depthProbability);
		OutputClusterProbabilities(clustersFilename, MapWithDefault(1.0,depthProbability));
	}
}

