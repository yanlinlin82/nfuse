/*
 *  realign.cpp
 *
 *  Created by Andrew McPherson on 28/09/09.
 *
 */

#include "Common.h"
#include "DebugCheck.h"
#include "Indexer.h"
#include "ReadStream.h"
#include "AlignmentStream.h"
#include "Sequences.h"
#include "SimpleAligner.h"
#include "AlignRead.h"

#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <tclap/CmdLine.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

using namespace boost;
using namespace std;


int BestSplitAlignment(const short int* scores1Fwd, int scores1FwdLength, const short int* scores2Rev, int scores2RevLength, int breakInsertScore, IntegerVec& seq1Lengths, IntegerVec& seq2Lengths)
{
	IntegerVec scores1FwdBreakInsert(scores1FwdLength);
	IntegerVec scores1FwdPrevMax(scores1FwdLength);
	
	scores1FwdBreakInsert[0] = scores1Fwd[0];
	scores1FwdPrevMax[0] = 0;
	for (int idx = 1; idx < scores1FwdLength; idx++)
	{
		if (scores1FwdBreakInsert[idx-1] + breakInsertScore >= scores1Fwd[idx])
		{
			scores1FwdBreakInsert[idx] = scores1FwdBreakInsert[idx-1] + breakInsertScore;
			scores1FwdPrevMax[idx] = scores1FwdPrevMax[idx-1];
		}
		else
		{
			scores1FwdBreakInsert[idx] = scores1Fwd[idx];
			scores1FwdPrevMax[idx] = idx;
		}
	}
	
	IntegerVec seq1LengthMax;
	
	int score = numeric_limits<int>::min();
	for (int seq1Length = 0; seq1Length < scores1FwdLength; seq1Length++)
	{
		int seq2Length = scores2RevLength - seq1Length - 1;
		
		if (scores1FwdBreakInsert[seq1Length] + scores2Rev[seq2Length] > score)
		{
			score = scores1FwdBreakInsert[seq1Length] + scores2Rev[seq2Length];
			seq1LengthMax.clear();
		}
		
		if (scores1FwdBreakInsert[seq1Length] + scores2Rev[seq2Length] >= score)
		{
			seq1LengthMax.push_back(seq1Length);
		}
	}
	
	for (int idx = 0; idx < seq1LengthMax.size(); idx++)
	{
		int seq1Length = seq1LengthMax[idx];
		int seq2Length = scores2RevLength - seq1Length - 1;
		
		if (scores1FwdBreakInsert[seq1Length] == scores1Fwd[seq1Length])
		{
			seq1Lengths.push_back(seq1Length);
			seq2Lengths.push_back(seq2Length);
		}
		
		if (scores1FwdPrevMax[seq1Length] != seq1Length)
		{
			seq1Lengths.push_back(scores1FwdPrevMax[seq1Length]);
			seq2Lengths.push_back(seq2Length);
		}
	}
	
	return score;
}

int main(int argc, char* argv[])
{
	int matchScore;
	int misMatchScore;
	int gapScore;
	int maxPaired;
	int maxUnpaired;
	string referenceFasta;
	string readSeqsFilename;
	string alignmentsFilename;
	string spanningFilename;
	string splitsFilename;
	string mateScoreFilename;
	
	try
	{
		TCLAP::CmdLine cmd("Mate Realignment Tool");
		TCLAP::ValueArg<int> matchScoreArg("m","match","Match Score",true,0,"int",cmd);
		TCLAP::ValueArg<int> misMatchScoreArg("x","mismatch","Mismatch Score",true,0,"int",cmd);
		TCLAP::ValueArg<int> gapScoreArg("g","gap","Gap Score",true,0,"int",cmd);
		TCLAP::ValueArg<int> maxPairedArg("p","pairedmax","Max Paired Alignments",true,0,"int",cmd);
		TCLAP::ValueArg<int> maxUnpairedArg("u","unpairedmax","Max Unpaired Alignments",true,0,"int",cmd);
		TCLAP::ValueArg<string> referenceFastaArg("r","reference","Reference Sequences Fasta",true,"","string",cmd);
		TCLAP::ValueArg<string> readSeqsFilenameArg("s","seqs","Read Sequences Fastq",true,"","string",cmd);
		TCLAP::ValueArg<string> alignmentsFilenameArg("a","align","Sam Alignments",true,"","string",cmd);
		TCLAP::ValueArg<string> spanningFilenameArg("n","span","Output Spanning Alignments",true,"","string",cmd);
		TCLAP::ValueArg<string> splitsFilenameArg("t","split","Output Split Alignments",true,"","string",cmd);
		TCLAP::ValueArg<string> mateScoreFilenameArg("b","bestmate","Output Best Mate Scores",true,"","string",cmd);
		cmd.parse(argc,argv);
		
		matchScore = matchScoreArg.getValue();
		misMatchScore = misMatchScoreArg.getValue();
		gapScore = gapScoreArg.getValue();
		maxPaired = maxPairedArg.getValue();
		maxUnpaired = maxUnpairedArg.getValue();
		referenceFasta = referenceFastaArg.getValue();
		readSeqsFilename = readSeqsFilenameArg.getValue();
		alignmentsFilename = alignmentsFilenameArg.getValue();
		spanningFilename = spanningFilenameArg.getValue();
		splitsFilename = splitsFilenameArg.getValue();
		mateScoreFilename = mateScoreFilenameArg.getValue();
	}
	catch (TCLAP::ArgException &e)
	{
		cerr << "error: " << e.error() << " for arg " << e.argId() << endl;
		exit(1);
	}
	
	int cMateSearchLength = 1000;
	int cSeedScoreThreshold = 24;
	int cMaxBreakpointHomology = 10;
	double cMatePercentScoreThreshold = 0.8;
	int cMinAnchor = 8;
	
	cerr << "Reading reference fasta" << endl;
	
	Sequences referenceSequences(1000);
	referenceSequences.Read(referenceFasta);
	
	cerr << "Reading fastq sequences" << endl;

	ifstream readSeqsFile(readSeqsFilename.c_str());
	CheckFile(readSeqsFile, readSeqsFilename);
	
	FastqReadStream readSeqsStream(readSeqsFile);
	
	PreppedReads preppedReads;
	preppedReads.Prep(readSeqsStream);
	
	cerr << "Realigning" << endl;
	
	ofstream spanningFile(spanningFilename.c_str());
	CheckFile(spanningFile, spanningFilename);
	
	ofstream splitsFile(splitsFilename.c_str());
	CheckFile(splitsFile, splitsFilename);
	
	ofstream mateScoreFile(mateScoreFilename.c_str());
	CheckFile(mateScoreFile, mateScoreFilename);
	
	SimpleAligner aligner(matchScore, misMatchScore, gapScore);
	
	SamAlignmentStream alignmentStream(alignmentsFilename);
	FragmentAlignmentStream fragmentAlignmentStream(&alignmentStream);
	
	RawAlignmentVec alignments;
	while (fragmentAlignmentStream.GetNextAlignments(alignments))
	{
		const string& fragment = alignments.front().fragment;
		
		preppedReads.SetCurrentRead(lexical_cast<int>(fragment));
		
		map<int,IntegerVec> alignmentScores[2];
		
		for (int alignmentIndex = 0; alignmentIndex < alignments.size(); alignmentIndex++)
		{
			const RawAlignment& alignment = alignments[alignmentIndex];
			
			int score = AlignSelfScoreSSE(aligner, alignment, referenceSequences, preppedReads);
			
			alignmentScores[alignment.readEnd][score].push_back(alignmentIndex);
		}
		
		IntegerVec alignedEnds;
		if (alignmentScores[0].size() == 0)
		{
			if (alignmentScores[1].rbegin()->second.size() > maxUnpaired)
			{
				continue;
			}
			
			alignedEnds.push_back(1);
		}
		else if (alignmentScores[1].size() == 0)
		{
			if (alignmentScores[0].rbegin()->second.size() > maxUnpaired)
			{
				continue;
			}
			
			alignedEnds.push_back(0);
		}
		else
		{
			if (alignmentScores[0].rbegin()->second.size() * alignmentScores[1].rbegin()->second.size() > maxPaired)
			{
				continue;
			}
			
			alignedEnds.push_back(0);
			alignedEnds.push_back(1);
		}
		
		bool concordant = false;
		if (alignedEnds.size() == 2)
		{
			const IntegerVec& end1TopScoring = alignmentScores[0].rbegin()->second;
			const IntegerVec& end2TopScoring = alignmentScores[1].rbegin()->second;
			
			for (IntegerVecConstIter end1AlignIter = end1TopScoring.begin(); end1AlignIter != end1TopScoring.end(); end1AlignIter++)
			{
				const RawAlignment& alignment1 = alignments[*end1AlignIter];
				
				for (IntegerVecConstIter end2AlignIter = end2TopScoring.begin(); end2AlignIter != end2TopScoring.end(); end2AlignIter++)
				{
					const RawAlignment& alignment2 = alignments[*end2AlignIter];
					
					if (alignment1.reference != alignment1.reference)
					{
						continue;
					}
					
					if (alignment1.strand == alignment2.strand)
					{
						continue;
					}
					
					if ((alignment1.strand == PlusStrand && alignment2.region.start >= alignment1.region.start && alignment2.region.start <= alignment1.region.start + cMateSearchLength) ||
						(alignment2.strand == PlusStrand && alignment1.region.start >= alignment2.region.start && alignment1.region.start <= alignment2.region.start + cMateSearchLength))
					{
						concordant = true;
						break;
					}
				}
				
				if (concordant)
				{
					break;
				}
			}
		}
		
		if (concordant)
		{
			continue;
		}
		
		unordered_map<int,AlignInfo> mateAlignInfos;
		int bestMateAlignScores[2] = {numeric_limits<int>::min(), numeric_limits<int>::min()};
		
		for (IntegerVecConstIter readEndIter = alignedEnds.begin(); readEndIter != alignedEnds.end(); readEndIter++)
		{
			int readEnd = *readEndIter;
			const IntegerVec& topScoring = alignmentScores[readEnd].rbegin()->second;
			for (IntegerVecConstIter alignIter = topScoring.begin(); alignIter != topScoring.end(); alignIter++)
			{
				const RawAlignment& alignment = alignments[*alignIter];
				
				int mateEnd = OtherReadEnd(alignment.readEnd);
				
				int seedScore;
				int seedPosition;
				AlignMate3PrimeSeed16SSE(aligner, alignment, referenceSequences, preppedReads, cMateSearchLength, seedScore, seedPosition);
				
				if (seedScore >= cSeedScoreThreshold)
				{
					AlignInfo mateAlignInfo = AlignMateFullSSE(aligner, alignment, referenceSequences, preppedReads, seedPosition);
					
					int score = mateAlignInfo.SeqScores()[preppedReads.ReadLength(mateEnd)];
					
					if (score >= (double)preppedReads.ReadLength(mateEnd) * cMatePercentScoreThreshold * (double)matchScore)
					{
						concordant = true;
						break;
					}
					
					mateAlignInfos[*alignIter] = mateAlignInfo;
					bestMateAlignScores[mateEnd] = max(bestMateAlignScores[mateEnd], score);
				}
			}
			
			if (concordant)
			{
				break;
			}
		}
		
		if (concordant)
		{
			continue;
		}
		
		unordered_map<int,AlignInfo> selfAlignInfos;
		
		for (IntegerVecConstIter readEndIter = alignedEnds.begin(); readEndIter != alignedEnds.end(); readEndIter++)
		{
			int readEnd = *readEndIter;
			const IntegerVec& topScoring = alignmentScores[readEnd].rbegin()->second;
			for (IntegerVecConstIter alignIter = topScoring.begin(); alignIter != topScoring.end(); alignIter++)
			{
				const RawAlignment& alignment = alignments[*alignIter];
				
				AlignInfo alignInfo = AlignSelfFullSSE(aligner, alignment, referenceSequences, preppedReads);
				
				int seqLength = alignInfo.BestPartialSeqLength();
				int score = alignInfo.SeqScores()[seqLength];
				
				DebugCheck(alignment.readEnd == readEnd);
				//DebugCheck(topScore == score);
				
				spanningFile << fragment << "\t";
				spanningFile << alignment.readEnd << "\t";
				spanningFile << alignment.reference << "\t";
				spanningFile << ((alignment.strand == PlusStrand) ? "+" : "-") << "\t";
				spanningFile << alignInfo.AlignmentStart(seqLength) << "\t";
				spanningFile << alignInfo.AlignmentEnd(seqLength) << "\t";
				spanningFile << preppedReads.ReadLength(alignment.readEnd) << "\t";
				spanningFile << seqLength << "\t";
				spanningFile << score << endl;
				
				selfAlignInfos[*alignIter] = alignInfo;
			}
		}
		
		if (alignedEnds.size() != 2)
		{
			continue;
		}
		
		const IntegerVec& end1TopScoring = alignmentScores[0].rbegin()->second;
		const IntegerVec& end2TopScoring = alignmentScores[1].rbegin()->second;
		
		int alignIndex[2];
		for (IntegerVecConstIter end1AlignIter = end1TopScoring.begin(); end1AlignIter != end1TopScoring.end(); end1AlignIter++)
		{
			alignIndex[0] = *end1AlignIter;
			
			for (IntegerVecConstIter end2AlignIter = end2TopScoring.begin(); end2AlignIter != end2TopScoring.end(); end2AlignIter++)
			{
				alignIndex[1] = *end2AlignIter;
				
				for (int readEnd = 0; readEnd <= 1; readEnd++)
				{
					int mateEnd = OtherReadEnd(readEnd);
					
					unordered_map<int,AlignInfo>::const_iterator selfAlignInfoIter = selfAlignInfos.find(alignIndex[readEnd]);
					
					if (selfAlignInfoIter == selfAlignInfos.end())
					{
						continue;
					}
					
					unordered_map<int,AlignInfo>::const_iterator mateAlignInfoIter = mateAlignInfos.find(alignIndex[mateEnd]);
					
					if (mateAlignInfoIter == mateAlignInfos.end())
					{
						continue;
					}
					
					const AlignInfo& selfAlignInfo = selfAlignInfoIter->second;
					const AlignInfo& mateAlignInfo = mateAlignInfoIter->second;
					
					const RawAlignment& selfAlignment = alignments[alignIndex[readEnd]];
					const RawAlignment& mateAlignment = alignments[alignIndex[mateEnd]];
					
					IntegerVec seq1Length;
					IntegerVec seq2Length;
					int score = BestSplitAlignment(selfAlignInfo.SeqScores(), selfAlignInfo.SeqScoresLength(), mateAlignInfo.SeqScores(), mateAlignInfo.SeqScoresLength(), -1, seq1Length, seq2Length);
					
					if (seq1Length.size() > cMaxBreakpointHomology)
					{
						continue;
					}
					
					string readSeq = preppedReads.Sequence(readEnd);
					
					for (int i = 0; i < seq1Length.size(); i++)
					{
						if (seq1Length[i] < cMinAnchor || seq2Length[i] < cMinAnchor)
						{
							continue;
						}
						
						splitsFile << fragment << "\t";
						splitsFile << selfAlignment.readEnd << "\t";
						splitsFile << selfAlignment.reference << "\t";
						splitsFile << ((selfAlignment.strand == PlusStrand) ? "+" : "-") << "\t";
						splitsFile << selfAlignInfo.BreakPosition(seq1Length[i]) << "\t";
						splitsFile << mateAlignment.reference << "\t";
						splitsFile << ((mateAlignment.strand == PlusStrand) ? "+" : "-") << "\t";
						splitsFile << mateAlignInfo.BreakPosition(seq2Length[i]) << "\t";
						splitsFile << readSeq.substr(seq1Length[i], readSeq.size() - seq2Length[i] - seq1Length[i]) << "\t";
						splitsFile << seq1Length[i] << "\t";
						splitsFile << seq2Length[i] << "\t";
						splitsFile << selfAlignInfo.SeqScores()[seq1Length[i]] << "\t";
						splitsFile << mateAlignInfo.SeqScores()[seq2Length[i]] << "\t";
						splitsFile << score << endl;
					}
				}
			}
		}
		
		for (int mateEnd = 0; mateEnd <= 1; mateEnd++)
		{
			if (bestMateAlignScores[mateEnd] != numeric_limits<int>::min())
			{
				mateScoreFile << fragment << "\t";
				mateScoreFile << mateEnd << "\t";
				mateScoreFile << preppedReads.ReadLength(mateEnd) << "\t";
				mateScoreFile << bestMateAlignScores[mateEnd] << endl;
			}
		}
	}
}




