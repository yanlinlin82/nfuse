import sys
import csv

genefam_filename = sys.argv[1]

genefam = dict()
genefam_reader = csv.reader(open(genefam_filename, 'r'), delimiter='\t')
genefam_header = next(genefam_reader)
for row in genefam_reader:
	genefam[row[3]] = row[1]

reader = csv.reader(sys.stdin, delimiter='\t')
header = next(reader)

print '\t'.join(header + ['gene1_fam', 'gene2_fam', 'same_gene_fam'])

for row in reader:
	fields = dict(zip(header, row))
	gene1_fam = genefam.get(fields['gene_name1'], '-')
	gene2_fam = genefam.get(fields['gene_name2'], '-')
	same_gene_fam = ('N', 'Y')[gene1_fam == gene2_fam and gene2_fam != '-']
	print '\t'.join(row + [gene1_fam, gene2_fam, same_gene_fam])
	
