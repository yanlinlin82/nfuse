import sys
import csv

paralog_filename = sys.argv[1]

paralogs = set()
paralog_reader = csv.reader(open(paralog_filename, 'r'), delimiter='\t')
paralog_header = next(paralog_reader)
for row in paralog_reader:
	paralogs.add((row[0], row[1]))
	paralogs.add((row[1], row[0]))

reader = csv.reader(sys.stdin, delimiter='\t')
header = next(reader)

print '\t'.join(header + ['paralog'])

for row in reader:
	fields = dict(zip(header, row))
	paralog = ('N', 'Y')[(fields['gene1'], fields['gene2']) in paralogs]
	print '\t'.join(row + [paralog])
	
