import sys
import csv

column = sys.argv[1]
threshold = float(sys.argv[2])

reader = csv.reader(sys.stdin, delimiter='\t')
header = next(reader)
print '\t'.join(header)
for row in reader:
	fields = dict(zip(header, row))
	if float(fields[column]) >= threshold:
		print '\t'.join(row)
	