import sys
import csv
import os

validated_fasta = sys.argv[1]
results_filename = sys.argv[2]

temp_fasta_filename = 'temp.fa'
temp_fasta_file = open(temp_fasta_filename, 'w')

reader = csv.reader(open(results_filename, 'r'), delimiter='\t')
header = next(reader)
results_data = dict()
for row in reader:
	fields = dict(zip(header, row))
	temp_fasta_file.write('>' + fields['cluster_id'] + '\n' + fields['sequence'] + '\n')
	results_data[fields['cluster_id']] = row

temp_fasta_file.close()

try:
	os.remove('temp1.psl')
except:
	pass
try:
	os.remove('temp2.psl')
except:
	pass
os.system('blat -noHead ' + validated_fasta + ' ' + temp_fasta_filename + ' temp1.psl > /dev/null')
os.system('blat -noHead ' + temp_fasta_filename + ' ' + validated_fasta + ' temp2.psl > /dev/null')

all_fusions = set()
found_fusions = set()
validated = set()
for row in csv.reader(open('temp1.psl', 'r'), delimiter='\t'):
	num_matches = float(row[0])
	query_length = float(row[10])
	cluster_id = row[9]
	fusion = row[13]
	all_fusions.add(fusion)
	if num_matches > 0.95 * query_length:
		found_fusions.add(fusion)
		validated.add(cluster_id)
	
for row in csv.reader(open('temp2.psl', 'r'), delimiter='\t'):
	num_matches = int(row[0])
	query_length = int(row[10])
	cluster_id = row[13]
	fusion = row[9]
	all_fusions.add(fusion)
	if num_matches > 0.95 * query_length:
		found_fusions.add(fusion)
		validated.add(cluster_id)

for fusion in all_fusions - found_fusions:
	sys.stderr.write(fusion + " not found\n")

print '\t'.join(header + ['validated'])
for cluster_id in validated:
	print '\t'.join(results_data[cluster_id] + ['Y'])
