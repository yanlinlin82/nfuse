import sys
import csv

allfields = set()
rowdata = list()

for filename in sys.argv[1:]:
	reader = csv.reader(open(filename, 'r'), delimiter='\t')
	header = next(reader)
	allfields.update(header)
	for row in reader:
		fields = dict(zip(header, row))
		rowdata.append(fields)
try:
	allfields.remove('')
except KeyError:
	pass
print '\t'.join(sorted(allfields))
for row in rowdata:
	print '\t'.join([row.get(field, '-') for field in sorted(allfields)])
	
