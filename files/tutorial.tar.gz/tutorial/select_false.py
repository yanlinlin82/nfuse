import sys
import csv
import random

numsampled = int(sys.argv[1])

reader = csv.reader(sys.stdin, delimiter='\t')
header = next(reader)

print '\t'.join(header + ['validated'])

invalidated_rows = list()
for row in reader:
	fields = dict(zip(header, row))
	if fields['paralog'] == 'Y' or fields['same_gene_fam'] == 'Y':
		invalidated_rows.append(row + ['N'])

for row in random.sample(invalidated_rows, numsampled):
	print '\t'.join(row)
